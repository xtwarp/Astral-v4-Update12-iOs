import SwiftUI

/// Pantallas de bienvenida del primer inicio: bienvenida, privacidad y qué se puede hacer.
/// Los textos y colores siguen el idioma y el tema activos.
struct OnboardingView: View {
    let onFinish: () -> Void

    @ObservedObject private var themeStore = ThemeStore.shared
    @ObservedObject private var languageStore = AppLanguageStore.shared
    @State private var page = 0
    @State private var showPolicy = false
    @State private var glow = false

    private let pageCount = 3

    var body: some View {
        ZStack {
            NeonBackground().ignoresSafeArea()

            VStack(spacing: 0) {
                TabView(selection: $page) {
                    welcomePage.tag(0)
                    privacyPage.tag(1)
                    featuresPage.tag(2)
                }
                .tabViewStyle(.page(indexDisplayMode: .never))

                pageDots
                    .padding(.top, 10)
                    .padding(.bottom, 28)

                nextButton
                    .padding(.horizontal, 24)
                    .padding(.bottom, 28)
            }
        }
        .preferredColorScheme(themeStore.theme.palette.scheme)
        .sheet(isPresented: $showPolicy) { PrivacyPolicyView() }
        .onAppear {
            withAnimation(.easeInOut(duration: 2.6).repeatForever(autoreverses: true)) { glow = true }
        }
    }

    // MARK: - Páginas

    private var welcomePage: some View {
        pageLayout {
            Image("Logo")
                .resizable()
                .scaledToFit()
                .frame(width: 150, height: 150)
                .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(Theme.ink(0.12), lineWidth: 1))
                .shadow(color: LocalStyle.cyan.opacity(glow ? 0.5 : 0.25), radius: glow ? 34 : 22)
        } title: {
            titleBlock(eyebrow: tr("Te damos la bienvenida a", "Welcome to"), title: "Astral", large: true)
        } content: {
            paragraphCard(tr(
                "Astral mejora tus videos y fotos directamente en tu iPhone. Aumenta la resolución, suaviza el movimiento con más fps, quita fondos y ajusta el color, todo con inteligencia artificial que funciona sin conexión.",
                "Astral enhances your videos and photos right on your iPhone. Increase the resolution, smooth the motion with more fps, remove backgrounds and adjust the color, all with artificial intelligence that works offline."
            ))
        }
    }

    private var privacyPage: some View {
        pageLayout {
            symbolBox("cpu", badge: "lock.fill")
        } title: {
            titleBlock(eyebrow: tr("Privacidad", "Privacy"), title: tr("Todo se procesa en tu dispositivo", "Everything is processed on your device"), large: false)
        } content: {
            VStack(spacing: 12) {
                paragraphCard(tr(
                    "Tus videos y fotos nunca salen de tu iPhone. Los modelos de IA vienen dentro de la app y trabajan en tu dispositivo: no se sube nada a internet, no necesitas crear una cuenta y Astral no recopila datos personales ni usa analíticas ni anuncios.\n\nPara guardar un resultado en Fotos, iOS te pedirá permiso solo para añadir. Los resultados quedan donde tú decidas.",
                    "Your videos and photos never leave your iPhone. The AI models come inside the app and run on your device: nothing is uploaded to the internet, you don't need an account, and Astral doesn't collect personal data or use analytics or ads.\n\nTo save a result to Photos, iOS will ask for permission to add only. Results stay wherever you decide."
                ))
                Button { showPolicy = true } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "doc.text").font(.system(size: 13, weight: .semibold))
                        Text(tr("Leer la política de privacidad", "Read the privacy policy"))
                            .font(.system(size: 14, weight: .semibold, design: .rounded))
                    }
                    .foregroundStyle(LocalStyle.mint)
                    .padding(.vertical, 6)
                }
            }
        }
    }

    private var featuresPage: some View {
        pageLayout {
            symbolBox("wand.and.stars", badge: nil)
        } title: {
            titleBlock(eyebrow: tr("Qué puedes hacer", "What you can do"), title: tr("Todo en un solo lugar", "Everything in one place"), large: false)
        } content: {
            VStack(alignment: .leading, spacing: 14) {
                featureRow("film.stack", tr("Mejoras de video", "Video enhancements"),
                           tr("Mejora la calidad, aumenta los fps y añade cámara lenta.", "Improve the quality, increase the fps and add slow motion."))
                featureRow("photo", tr("Imagen", "Image"),
                           tr("Mejora la calidad de tus fotos.", "Improve the quality of your photos."))
                featureRow("person.crop.rectangle", tr("Eliminación de fondo", "Background removal"),
                           tr("Recorta personas y objetos al instante.", "Cut out people and objects instantly."))
                featureRow("slider.horizontal.below.rectangle", tr("Color", "Color"),
                           tr("Ajusta luz y color en fotos y videos.", "Adjust light and color in photos and videos."))
            }
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Theme.fill(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Theme.ink(0.08), lineWidth: 1))
        }
    }

    // MARK: - Piezas

    /// Misma estructura en todas las páginas: imagen, título y contenido, centrados y un poco más arriba del centro.
    private func pageLayout<Hero: View, Title: View, Content: View>(
        @ViewBuilder hero: () -> Hero,
        @ViewBuilder title: () -> Title,
        @ViewBuilder content: () -> Content
    ) -> some View {
        // Se evalúan aquí, fuera del GeometryReader: sus cierres internos escapan y no pueden capturar
        // los parámetros (que no escapan).
        let heroView = hero()
        let titleView = title()
        let contentView = content()
        return GeometryReader { proxy in
            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: 0) {
                    heroView
                    Spacer().frame(height: 28)
                    titleView
                    Spacer().frame(height: 20)
                    contentView
                }
                .padding(.horizontal, 26)
                .padding(.bottom, 40)
                .frame(maxWidth: .infinity)
                .frame(minHeight: proxy.size.height)
            }
            .scrollBounceBehavior(.basedOnSize)
        }
    }

    private func titleBlock(eyebrow: String, title: String, large: Bool) -> some View {
        VStack(spacing: large ? 2 : 6) {
            Text(eyebrow)
                .font(.system(size: large ? 22 : 14, weight: .semibold, design: .rounded))
                .tracking(large ? 0 : 1.2)
                .textCase(large ? nil : .uppercase)
                .foregroundStyle(Theme.ink(0.6))
            Text(title)
                .font(.system(size: large ? 52 : 30, weight: .heavy, design: .rounded))
                .foregroundStyle(LocalStyle.gradient)
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .minimumScaleFactor(0.6)
        }
        .frame(maxWidth: .infinity)
    }

    /// Texto de la página dentro de un recuadro, para distinguirlo del título.
    private func paragraphCard(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 15.5, weight: .regular, design: .rounded))
            .foregroundStyle(Theme.ink(0.78))
            .multilineTextAlignment(.center)
            .lineSpacing(3)
            .fixedSize(horizontal: false, vertical: true)
            .padding(18)
            .frame(maxWidth: .infinity)
            .background(Theme.fill(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Theme.ink(0.08), lineWidth: 1))
    }

    /// Recuadro con un símbolo grande (chip, varita…) y una insignia opcional.
    private func symbolBox(_ symbol: String, badge: String?) -> some View {
        ZStack(alignment: .bottomTrailing) {
            ZStack {
                RoundedRectangle(cornerRadius: 34, style: .continuous)
                    .fill(Theme.fill(0.07))
                RoundedRectangle(cornerRadius: 34, style: .continuous)
                    .stroke(LocalStyle.gradient, lineWidth: 2)
                Image(systemName: symbol)
                    .font(.system(size: 70, weight: .light))
                    .foregroundStyle(LocalStyle.gradient)
            }
            .frame(width: 150, height: 150)
            .shadow(color: LocalStyle.cyan.opacity(glow ? 0.5 : 0.25), radius: glow ? 34 : 22)

            if let badge {
                Image(systemName: badge)
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(Theme.onAccent)
                    .frame(width: 40, height: 40)
                    .background(LocalStyle.gradient, in: Circle())
                    .overlay(Circle().stroke(Theme.palette.base, lineWidth: 3))
                    .offset(x: 8, y: 8)
            }
        }
    }

    private func featureRow(_ icon: String, _ title: String, _ detail: String) -> some View {
        HStack(alignment: .top, spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(LocalStyle.mint)
                .frame(width: 30, height: 30)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(Theme.ink())
                Text(detail)
                    .font(.system(size: 13, weight: .regular, design: .rounded))
                    .foregroundStyle(Theme.ink(0.62))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var pageDots: some View {
        HStack(spacing: 10) {
            ForEach(0..<pageCount, id: \.self) { index in
                Circle()
                    .fill(index == page ? Theme.ink() : Theme.ink(0.22))
                    .frame(width: 8, height: 8)
                    .scaleEffect(index == page ? 1.25 : 1)
                    .shadow(color: index == page ? Theme.ink(0.55) : Color.clear, radius: 5)
                    .animation(.easeInOut(duration: 0.2), value: page)
            }
        }
    }

    private var nextButton: some View {
        Button { advance() } label: {
            HStack(spacing: 8) {
                Text(page == pageCount - 1 ? tr("Empezar", "Get started") : tr("Siguiente", "Next"))
                    .font(.system(size: 17, weight: .bold, design: .rounded))
                Image(systemName: "arrow.right").font(.system(size: 16, weight: .bold))
            }
            .foregroundStyle(Theme.onAccent)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(LocalStyle.gradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .shadow(color: LocalStyle.mint.opacity(0.35), radius: 14, y: 4)
        }
    }

    private func advance() {
        if page < pageCount - 1 {
            withAnimation(.easeInOut(duration: 0.3)) { page += 1 }
        } else {
            onFinish()
        }
    }
}
