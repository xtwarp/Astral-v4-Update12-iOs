import Foundation
import SwiftUI

/// Elige el texto según el idioma guardado. Es seguro llamarla desde cualquier hilo
/// (los procesadores de vídeo la usan para sus mensajes de progreso).
/// Español e inglés van en la propia llamada; el resto de idiomas se buscan en `Translations`
/// usando el texto en inglés (si no hay traducción, se muestra el inglés).
func tr(_ es: String, _ en: String) -> String {
    switch AppLanguage.current {
    case .es: return es
    case .en: return en
    case let other: return Translations.translate(en, to: other.rawValue)
    }
}

/// ¿`text` es ese mismo mensaje (es/en) en cualquiera de los idiomas de la app?
/// Sirve para reconocer los mensajes de estado "de reposo" al cambiar de idioma.
func isTr(_ text: String, _ es: String, _ en: String) -> Bool {
    if text == es || text == en { return true }
    return AppLanguage.allCases.contains { lang in
        lang != .es && lang != .en && Translations.translate(en, to: lang.rawValue) == text
    }
}

enum AppLanguage: String, CaseIterable, Identifiable {
    case es, en, pt, fr, de, it
    var id: String { rawValue }

    /// Nombre del idioma en su propio idioma (así se reconoce aunque la app esté en otro).
    var displayName: String {
        switch self {
        case .es: return "Español"
        case .en: return "English"
        case .pt: return "Português"
        case .fr: return "Français"
        case .de: return "Deutsch"
        case .it: return "Italiano"
        }
    }

    /// Idioma del iPhone si la app lo tiene; si no, español.
    static var systemDefault: AppLanguage {
        for preferred in Locale.preferredLanguages {
            let code = String(preferred.prefix(2)).lowercased()
            if let match = AppLanguage(rawValue: code) { return match }
        }
        return .es
    }

    /// Idioma activo (guardado o, si aún no se eligió, el del sistema).
    static var current: AppLanguage {
        if let raw = UserDefaults.standard.string(forKey: "astral.language"), let saved = AppLanguage(rawValue: raw) {
            return saved
        }
        return systemDefault
    }
}

/// Guarda el idioma elegido y lo recuerda entre sesiones. No reinicia la app:
/// las vistas que observan `AppLanguageStore.shared` se redibujan solas al cambiarlo.
@MainActor
final class AppLanguageStore: ObservableObject {
    static let shared = AppLanguageStore()
    @Published var language: AppLanguage {
        didSet { UserDefaults.standard.set(language.rawValue, forKey: "astral.language") }
    }
    private init() {
        language = AppLanguage.current
    }
}

/// Textos fijos de la interfaz (pestañas, botones, títulos de sección, ajustes): español e inglés aquí y
/// el resto de idiomas en `Translations`. Los mensajes de estado y de error se traducen con `tr(es, en)`.
enum L: String {
    case tabVideo, tabImage, tabInterpolate, tabBackground, tabColor, onDevice
    case settingsTitle, settingsLanguage
    case cacheTitle, cacheButton, resultsTitle, resultsButton, cacheFootnote
    case deleteResultsTitle, deleteResultsMessage, deleteButton, cancelButton
    case selectVideo, selectImage
    case startButton, startButtonCombined, interpolateButton, interpolateButtonCombined
    case modelSectionTitle
    case interpolateFactorTitle, interpolateFactorFast, interpolateFactorSmooth
    case precisionTitle, precisionFast, precisionHigh
    case alsoInterpolateTitle, alsoInterpolateSubtitle
    case alsoUpscaleTitle, alsoUpscaleSubtitle
    case beforeAfterTitle, saveToFiles, shareExport
    case selectVideoPlaceholderTitle, selectVideoPlaceholderSubtitle
    case selectImagePlaceholderTitle
    case interpolatePlaceholderTitle, interpolatePlaceholderSubtitle
    case tryAnyway
    case deviceOnlyNote
    case beforeLabel, afterLabel

    private static let table: [L: (es: String, en: String)] = [
        .tabVideo: ("VIDEO", "VIDEO"),
        .tabImage: ("IMAGEN", "IMAGE"),
        .tabInterpolate: ("INTERPOLAR", "INTERPOLATE"),
        .tabBackground: ("ELIMINACIÓN DE FONDO", "BACKGROUND REMOVAL"),
        .tabColor: ("COLOR", "COLOR"),
        .onDevice: ("ON-DEVICE", "ON-DEVICE"),
        .settingsTitle: ("AJUSTES", "SETTINGS"),
        .settingsLanguage: ("IDIOMA", "LANGUAGE"),
        .cacheTitle: ("CACHÉ TEMPORAL", "TEMPORARY CACHE"),
        .cacheButton: ("Borrar caché", "Clear cache"),
        .resultsTitle: ("RESULTADOS GUARDADOS EN LA APP", "RESULTS SAVED IN THE APP"),
        .resultsButton: ("Borrar resultados", "Delete results"),
        .cacheFootnote: (
            "Los resultados no se guardan solos: expórtalos antes de borrar la caché. Los archivos que estás usando ahora se conservan. Todo se procesa solo en tu dispositivo.",
            "Results aren't saved automatically: export them before clearing the cache. Files you're currently using are kept. Everything is processed only on your device."
        ),
        .deleteResultsTitle: ("¿Borrar resultados guardados?", "Delete saved results?"),
        .deleteResultsMessage: (
            "Se eliminarán los videos de la carpeta «Astral Results» (Archivos › En mi iPhone › Astral). Los que exportaste a otra ubicación no se tocan.",
            "This deletes the videos in the “Astral Results” folder (Files › On My iPhone › Astral). Anything you already exported elsewhere is untouched."
        ),
        .deleteButton: ("Borrar", "Delete"),
        .cancelButton: ("Cancelar", "Cancel"),
        .selectVideo: ("Seleccionar video", "Select video"),
        .selectImage: ("Seleccionar imagen", "Select image"),
        .startButton: ("Comenzar", "Start"),
        .startButtonCombined: ("Escalar + interpolar", "Upscale + interpolate"),
        .interpolateButton: ("Interpolar", "Interpolate"),
        .interpolateButtonCombined: ("Interpolar + escalar", "Interpolate + upscale"),
        .modelSectionTitle: ("MODELO", "MODEL"),
        .interpolateFactorTitle: ("FACTOR DE INTERPOLACIÓN", "INTERPOLATION FACTOR"),
        .interpolateFactorFast: ("más rápido", "faster"),
        .interpolateFactorSmooth: ("más fluido", "smoother"),
        .precisionTitle: ("PRECISIÓN", "PRECISION"),
        .precisionFast: ("Rápida", "Fast"),
        .precisionHigh: ("Alta", "High"),
        .alsoInterpolateTitle: ("Interpolar también", "Also interpolate"),
        .alsoInterpolateSubtitle: (
            "Escala y, frame a frame, genera frames intermedios con RIFE después",
            "Upscales and, frame by frame, generates in-between frames with RIFE afterwards"
        ),
        .alsoUpscaleTitle: ("Escalar también", "Also upscale"),
        .alsoUpscaleSubtitle: (
            "Interpola y, frame a frame, aplica Real-ESRGAN después",
            "Interpolates and, frame by frame, applies Real-ESRGAN afterwards"
        ),
        .beforeAfterTitle: ("ANTES / DESPUÉS", "BEFORE / AFTER"),
        .saveToFiles: ("Guardar en Archivos", "Save to Files"),
        .shareExport: ("Compartir / Exportar", "Share / Export"),
        .selectVideoPlaceholderTitle: ("Selecciona un video", "Select a video"),
        .selectVideoPlaceholderSubtitle: ("Real-ESRGAN procesa todo en el iPhone", "Real-ESRGAN processes everything on your iPhone"),
        .selectImagePlaceholderTitle: ("Selecciona una imagen", "Select an image"),
        .interpolatePlaceholderTitle: ("Selecciona un video", "Select a video"),
        .interpolatePlaceholderSubtitle: ("RIFE genera frames intermedios en el iPhone", "RIFE generates in-between frames on your iPhone"),
        .tryAnyway: ("Intentar de todos modos", "Try anyway"),
        .deviceOnlyNote: ("Todo se procesa en el dispositivo", "Everything is processed on your device"),
        .beforeLabel: ("ANTES", "BEFORE"),
        .afterLabel: ("DESPUÉS", "AFTER"),
    ]

    @MainActor
    var text: String {
        guard let pair = Self.table[self] else { return rawValue }
        switch AppLanguageStore.shared.language {
        case .es: return pair.es
        case .en: return pair.en
        case let other: return Translations.translate(pair.en, to: other.rawValue)
        }
    }
}
