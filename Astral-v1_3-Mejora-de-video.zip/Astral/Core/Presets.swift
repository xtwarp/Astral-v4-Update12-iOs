import Foundation

/// Ajustes de la pestaña "Mejora de video".
struct EnhanceSection: Codable, Equatable {
    var doUpscale: Bool
    var doInterpolate: Bool
    var modelRaw: String
    var factor: Int
    var precisionRaw: String
    var slowMotion: Bool
    var exportQualityRaw: Int
}

/// Ajustes de la pestaña "Imagen".
struct ImageSection: Codable, Equatable {
    var modelRaw: String
}

/// Un preset guarda la configuración de todas las pestañas a la vez.
/// Una sección en nil (p. ej. un preset antiguo que solo tenía video) no toca esa pestaña al aplicarlo.
struct Preset: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var enhance: EnhanceSection?
    var image: ImageSection?
    var color: ColorSettings?

    var summaryLines: [String] {
        var lines: [String] = []
        if let enhance {
            var parts: [String] = []
            if enhance.doUpscale {
                parts.append(RealESRGAN.Model(rawValue: enhance.modelRaw)?.summaryName ?? enhance.modelRaw)
            }
            if enhance.doInterpolate {
                let precision = RIFEInterpolator.Precision(rawValue: enhance.precisionRaw)?.displayName ?? enhance.precisionRaw
                var fps = "\(enhance.factor)× fps · \(precision)"
                if enhance.slowMotion { fps += " · " + tr("cámara lenta", "slow motion") }
                parts.append(fps)
            }
            if let quality = ExportQuality(rawValue: enhance.exportQualityRaw), quality != .automatic {
                parts.append(quality.label)
            }
            lines.append(tr("Video", "Video") + ": " + parts.joined(separator: " · "))
        }
        if let image {
            let model = RealESRGAN.Model(rawValue: image.modelRaw)?.summaryName ?? image.modelRaw
            lines.append(tr("Imagen", "Image") + ": " + model)
        }
        if let color {
            lines.append("Color: " + (color.isNeutral ? tr("sin ajustes", "no adjustments") : tr("ajustado", "adjusted")))
        }
        return lines
    }
}

/// Formato anterior (un preset por pestaña). Solo se usa para migrar los que ya estaban guardados.
private struct LegacyPreset: Codable {
    enum Kind: String, Codable { case video, interpolate, image }

    var id: UUID
    var name: String
    var kind: Kind
    var modelRaw: String
    var includesSecondStep: Bool
    var factor: Int
    var precisionRaw: String
    var slowMotion: Bool?

    func migrated() -> Preset {
        switch kind {
        case .image:
            return Preset(id: id, name: name, enhance: nil, image: ImageSection(modelRaw: modelRaw), color: nil)
        case .video:
            let section = EnhanceSection(doUpscale: true, doInterpolate: includesSecondStep, modelRaw: modelRaw, factor: factor,
                                         precisionRaw: precisionRaw, slowMotion: false, exportQualityRaw: ExportQuality.automatic.rawValue)
            return Preset(id: id, name: name, enhance: section, image: nil, color: nil)
        case .interpolate:
            let section = EnhanceSection(doUpscale: includesSecondStep, doInterpolate: true, modelRaw: modelRaw, factor: factor,
                                         precisionRaw: precisionRaw, slowMotion: slowMotion ?? false, exportQualityRaw: ExportQuality.automatic.rawValue)
            return Preset(id: id, name: name, enhance: section, image: nil, color: nil)
        }
    }
}

@MainActor
final class PresetStore: ObservableObject {
    static let shared = PresetStore()
    private let key = "astral.presets.v2"
    private let legacyKey = "astral.presets"

    @Published private(set) var presets: [Preset] = []

    private init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode([Preset].self, from: data) {
            presets = saved
        } else if let data = UserDefaults.standard.data(forKey: legacyKey),
                  let old = try? JSONDecoder().decode([LegacyPreset].self, from: data) {
            presets = old.map { $0.migrated() }
            persist()
        }
    }

    /// Si ya existe uno con el mismo nombre, lo reemplaza.
    func save(_ preset: Preset) {
        presets.removeAll { $0.name.caseInsensitiveCompare(preset.name) == .orderedSame }
        presets.append(preset)
        persist()
    }

    func delete(_ id: UUID) {
        presets.removeAll { $0.id == id }
        persist()
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(presets) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
