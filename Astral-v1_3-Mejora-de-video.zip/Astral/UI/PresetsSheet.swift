import SwiftUI

/// Un único selector de presets para toda la app: cada preset guarda Mejora de video, Imagen y Color.
struct PresetsSheet: View {
    let current: (String) -> Preset
    let apply: (Preset) -> Void

    @ObservedObject private var store = PresetStore.shared
    @ObservedObject private var language = AppLanguageStore.shared
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""

    private var trimmedName: String { name.trimmingCharacters(in: .whitespacesAndNewlines) }

    var body: some View {
        NavigationStack {
            List {
                Section(tr("Guardar configuración actual", "Save current settings")) {
                    TextField(tr("Nombre del preset", "Preset name"), text: $name)
                    Button(tr("Guardar", "Save")) {
                        store.save(current(trimmedName))
                        name = ""
                    }
                    .disabled(trimmedName.isEmpty)
                }

                Section(tr("Mis presets", "My presets")) {
                    if store.presets.isEmpty {
                        Text(tr("Aún no tienes presets.", "You have no presets yet."))
                            .foregroundStyle(.secondary)
                    }
                    ForEach(store.presets) { preset in
                        Button {
                            apply(preset)
                            dismiss()
                        } label: {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(preset.name).font(.headline)
                                ForEach(preset.summaryLines, id: \.self) { line in
                                    Text(line).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    .onDelete { offsets in
                        let items = store.presets
                        for index in offsets { store.delete(items[index].id) }
                    }
                }

                Section {
                    Text(tr("Cada preset guarda los ajustes de Mejora de video, Imagen y Color. Toca uno para aplicarlo; desliza a la izquierda para borrarlo.",
                            "Each preset saves your Video enhance, Image and Color settings. Tap one to apply it; swipe left to delete it."))
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Presets")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button(tr("Cerrar", "Close")) { dismiss() } }
            }
        }
        .presentationDetents([.medium, .large])
        .preferredColorScheme(.dark)
    }
}

/// Resumen del lote: progreso mientras corre y, al terminar, botón para guardar/compartir todo.
struct BatchSummary: View {
    let isRunning: Bool
    let index: Int
    let total: Int
    let failures: Int
    let results: [URL]

    var body: some View {
        if total > 0 {
            VStack(alignment: .leading, spacing: 8) {
                if isRunning {
                    Text(tr("Lote", "Batch") + " \(index)/\(total)")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(LocalStyle.mint)
                    Text(tr("Mantén la app abierta; la pantalla no se apagará durante el lote.",
                            "Keep the app open; the screen won't sleep during the batch."))
                        .font(.caption).foregroundStyle(.white.opacity(0.5))
                } else {
                    Text(tr("Lote terminado", "Batch finished") + ": \(results.count)/\(total)"
                         + (failures > 0 ? " · \(failures) " + tr("con error", "failed") : ""))
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(LocalStyle.mint)
                    if !results.isEmpty {
                        ResultActionBar(
                            save: { try await PhotoSaver.saveFiles(results) },
                            share: ShareLink(items: results) { ShareBarLabel() }
                        )
                        .id(results)
                        Text(tr("Guárdalos ahora: se borran al limpiar la caché.",
                                "Save them now: they're deleted when you clear the cache."))
                            .font(.caption).foregroundStyle(.white.opacity(0.5))
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12)
            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
        }
    }
}
