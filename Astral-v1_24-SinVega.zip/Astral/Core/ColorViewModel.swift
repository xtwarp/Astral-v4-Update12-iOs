import Foundation
import SwiftUI
import PhotosUI
import AVFoundation
import CoreImage
import UniformTypeIdentifiers

@MainActor
final class ColorViewModel: ObservableObject {
    enum Media { case none, image, video }

    @Published var media: Media = .none
    @Published var settings = ColorSettings() {
        didSet { if settings != oldValue { refresh() } }
    }
    @Published var previewImage: CGImage?
    @Published var player: AVPlayer?
    /// Velocidad de la vista previa del video (no afecta a lo que se exporta).
    @Published var playbackSpeed: Double = 1 {
        didSet { if let player { PlaybackSpeed.apply(playbackSpeed, to: player) } }
    }
    /// Ancho / alto del video elegido (con la rotación aplicada); la vista previa se ajusta a esa forma.
    @Published var videoAspect: CGFloat?
    @Published var isPlaying = false
    @Published var status = tr("Elige una foto o un video", "Choose a photo or a video")
    @Published var isExporting = false
    @Published var progress: Double = 0
    @Published var outputURL: URL?
    @Published var showOriginal = false {
        didSet { if showOriginal != oldValue { refresh() } }
    }

    private(set) var sourceImage: CGImage?
    private var previewBase: CIImage?
    private var inputURL: URL?
    private var endObserver: NSObjectProtocol?
    private let ciContext = CIContext()

    var hasMedia: Bool { media != .none }

    func relocalizeIdleStatus() {
        guard !isExporting else { return }
        if isTr(status, "Elige una foto o un video", "Choose a photo or a video") {
            status = tr("Elige una foto o un video", "Choose a photo or a video")
        }
    }

    // MARK: - Importar

    func importItem(_ item: PhotosPickerItem) async {
        guard !isExporting else { return }
        status = tr("Cargando…", "Loading…")
        player?.pause()
        isPlaying = false
        outputURL = nil

        let isVideo = item.supportedContentTypes.contains { $0.conforms(to: .movie) }
        do {
            if isVideo {
                guard let movie = try await item.loadTransferable(type: ImportedMovie.self) else {
                    status = tr("No se pudo cargar el video", "Could not load the video"); return
                }
                let previous = inputURL
                if previous != movie.url { CacheManager.removeIfTemporary(previous) }
                inputURL = movie.url
                sourceImage = nil
                previewBase = nil
                previewImage = nil
                settings = ColorSettings()
                media = .video
                installPlayer(for: movie.url)
                status = tr("Ajusta el color y exporta", "Adjust the color and export")
            } else {
                guard let data = try await item.loadTransferable(type: Data.self),
                      let image = BackgroundRemover.loadImage(from: data) else {
                    status = tr("No se pudo cargar la imagen", "Could not load the image"); return
                }
                CacheManager.removeIfTemporary(inputURL)
                inputURL = nil
                player = nil
                videoAspect = nil
                sourceImage = image
                previewBase = Self.makePreviewBase(from: image)
                settings = ColorSettings()
                media = .image
                refresh()
                status = tr("Ajusta el color y guarda", "Adjust the color and save")
            }
        } catch {
            status = tr("No se pudo cargar: \(error.localizedDescription)", "Could not load: \(error.localizedDescription)")
        }
    }

    func applyLook(_ look: ColorLook) { settings = look.settings }
    func reset() { settings = ColorSettings() }

    // MARK: - Vista previa

    private static func makePreviewBase(from image: CGImage) -> CIImage {
        let ci = CIImage(cgImage: image)
        let longest = CGFloat(max(image.width, image.height))
        let scale = min(1, 1400 / longest)
        guard scale < 1 else { return ci }
        return ci.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
    }

    private func refresh() {
        switch media {
        case .image:
            guard let base = previewBase else { return }
            let output = showOriginal ? base : settings.apply(to: base)
            previewImage = ciContext.createCGImage(output, from: base.extent)
        case .video:
            updateVideoComposition()
        case .none:
            break
        }
    }

    private func loadVideoAspect(for url: URL) {
        videoAspect = nil
        Task { [weak self] in
            let asset = AVURLAsset(url: url)
            guard let track = try? await asset.loadTracks(withMediaType: .video).first,
                  let size = try? await track.load(.naturalSize),
                  let transform = try? await track.load(.preferredTransform) else { return }
            let rotated = size.applying(transform)
            let width = abs(rotated.width)
            let height = abs(rotated.height)
            guard height > 0 else { return }
            // Esta tarea corre en el actor principal (como el resto de la clase).
            if self?.inputURL == url { self?.videoAspect = width / height }
        }
    }

    private func installPlayer(for url: URL) {
        loadVideoAspect(for: url)
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        let item = AVPlayerItem(url: url)
        let newPlayer = AVPlayer(playerItem: item)
        player = newPlayer
        playbackSpeed = 1   // cada video nuevo empieza a velocidad normal
        endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main
        ) { [weak self] _ in
            newPlayer.seek(to: .zero)
            self?.isPlaying = false
        }
        updateVideoComposition()
    }

    private func updateVideoComposition() {
        guard let item = player?.currentItem else { return }
        if settings.isNeutral || showOriginal {
            item.videoComposition = nil
            return
        }
        let adjust = settings
        item.videoComposition = AVMutableVideoComposition(asset: item.asset) { request in
            request.finish(with: adjust.apply(to: request.sourceImage), context: nil)
        }
    }

    func togglePlay() {
        guard let player else { return }
        if isPlaying { player.pause() } else { player.play() }
        isPlaying.toggle()
    }

    // MARK: - Imagen: render a resolución completa

    nonisolated static func render(source: CGImage, settings: ColorSettings) -> CGImage? {
        let context = CIContext()
        let input = CIImage(cgImage: source)
        let output = settings.apply(to: input)
        return context.createCGImage(output, from: input.extent, format: .RGBA8,
                                     colorSpace: CGColorSpace(name: CGColorSpace.sRGB))
    }

    func renderedImage() async throws -> CGImage {
        guard let source = sourceImage else { throw PhotoSaveError.encodingFailed }
        let adjust = settings
        guard let image = await Task.detached(priority: .userInitiated, operation: {
            Self.render(source: source, settings: adjust)
        }).value else { throw PhotoSaveError.encodingFailed }
        return image
    }

    // MARK: - Vídeo: exportar

    @Published var keepHDR = false

    func exportVideo() {
        guard let url = inputURL, !isExporting else { return }
        isPlaying = false
        player?.pause()
        isExporting = true
        progress = 0
        outputURL = nil
        status = tr("Exportando video…", "Exporting video…")
        let adjust = settings
        let wantsHDR = keepHDR
        Task {
            do {
                let output = try await ColorVideoExporter.export(url: url, settings: adjust, keepHDR: wantsHDR) { value in
                    Task { @MainActor in self.progress = value }
                }
                outputURL = output
                status = tr("Listo — guarda o comparte el resultado", "Done — save or share the result")
                if AutoSave.isOn {
                    do {
                        try await PhotoSaver.saveVideo(at: output)
                        status = tr("Listo — guardado en Fotos", "Done — saved to Photos")
                    } catch {
                        status = error.localizedDescription
                    }
                }
            } catch {
                status = error.localizedDescription
            }
            isExporting = false
        }
    }
}

enum ColorVideoExporter {
    static func export(url: URL, settings: ColorSettings, keepHDR: Bool = false, progress: @escaping @Sendable (Double) -> Void) async throws -> URL {
        let asset = AVURLAsset(url: url)
        let composition = AVMutableVideoComposition(asset: asset) { request in
            request.finish(with: settings.apply(to: request.sourceImage), context: nil)
        }
        if keepHDR, let track = try? await asset.loadTracks(withMediaType: .video).first, let hdr = HDRSupport.info(for: track) {
            composition.colorPrimaries = AVVideoColorPrimaries_ITU_R_2020
            composition.colorTransferFunction = hdr.transferFunction
            composition.colorYCbCrMatrix = AVVideoYCbCrMatrix_ITU_R_2020
        }
        guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHEVCHighestQuality) else {
            throw UpscaleError.exportFailed
        }
        let fileType: AVFileType = session.supportedFileTypes.contains(.mp4) ? .mp4 : .mov
        let ext = fileType == .mp4 ? "mp4" : "mov"
        let output = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Result_\(UUID().uuidString).\(ext)")
        session.outputURL = output
        session.outputFileType = fileType
        session.videoComposition = composition

        let poller = Task {
            while !Task.isCancelled {
                progress(Double(session.progress))
                try? await Task.sleep(nanoseconds: 200_000_000)
            }
        }
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            session.exportAsynchronously { continuation.resume() }
        }
        poller.cancel()
        guard session.status == .completed else { throw session.error ?? UpscaleError.exportFailed }
        return output
    }
}

/// Imagen ajustada compartible como PNG (se renderiza al compartir).
struct ShareableAdjustedImage: Transferable {
    let source: CGImage
    let settings: ColorSettings

    static var transferRepresentation: some TransferRepresentation {
        DataRepresentation(exportedContentType: .png) { item in
            guard let image = ColorViewModel.render(source: item.source, settings: item.settings),
                  let data = PhotoSaver.pngData(image) else { throw PhotoSaveError.encodingFailed }
            return data
        }
    }
}
