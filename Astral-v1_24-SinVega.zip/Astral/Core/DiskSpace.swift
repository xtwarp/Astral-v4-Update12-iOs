import Foundation

/// Espacio libre del iPhone y cálculo aproximado de lo que necesita un video antes de empezar,
/// para avisar a tiempo en lugar de fallar a mitad del proceso.
enum DiskSpace {
    /// Bytes libres para archivos importantes (incluye lo que iOS puede liberar por sí solo). nil si no se pudo leer.
    static func availableBytes() -> Int64? {
        let home = URL(fileURLWithPath: NSHomeDirectory())
        let values = try? home.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        return values?.volumeAvailableCapacityForImportantUsage
    }

    /// Bytes que hacen falta, de forma aproximada, para procesar un video: el resultado, las partes que se guardan
    /// mientras tanto (en videos largos), la copia del original que permite reanudar y un margen de seguridad.
    static func estimatedNeed(width: Int, height: Int, outputSeconds: Double, interpolating: Bool,
                              parts: Int, inputBytes: Int64) -> Int64 {
        // Misma fórmula de bitrate que usan los procesadores al codificar (HEVC).
        let minimumBitrate = interpolating ? 8_000_000 : 18_000_000
        let bitrate = Double(max(minimumBitrate, width * height * 5))
        let output = bitrate * max(outputSeconds, 0) / 8
        // Con varias partes conviven las partes y el video unido; con una sola, solo el resultado.
        let copies = parts > 1 ? 2.2 : 1.2
        let originalCopy = parts > 1 ? inputBytes : 0
        return Int64(output * copies) + originalCopy + 150_000_000
    }

    static func text(_ bytes: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        formatter.allowsNonnumericFormatting = false
        return formatter.string(fromByteCount: bytes)
    }
}
