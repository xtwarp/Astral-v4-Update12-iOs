import Foundation
import CoreML
import BackgroundTasks

/// Dónde puede ejecutarse Core ML.
///
/// En primer plano los modelos usan la GPU. Con la app en segundo plano iOS no da la GPU en iPhone,
/// así que mientras la tarea de segundo plano esté en marcha los modelos se cargan con CPU + Neural Engine.
/// Se lee cada vez que se carga un modelo (al empezar cada parte del video).
enum ComputePolicy {
    private static let lock = NSLock()
    private static var gpuAllowed = true

    static var allowGPU: Bool {
        get { lock.lock(); defer { lock.unlock() }; return gpuAllowed }
        set { lock.lock(); gpuAllowed = newValue; lock.unlock() }
    }

    static var units: MLComputeUnits { allowGPU ? .cpuAndGPU : .cpuAndNeuralEngine }
}

/// Continuación en segundo plano (iOS 26 o posterior).
///
/// Pide a iOS una tarea de procesamiento continuo (`BGContinuedProcessingTask`) cuando el usuario empieza un
/// trabajo. Si iOS la acepta, el trabajo sigue aunque se salga de la app y el sistema muestra su propia barra de
/// progreso. Si no la acepta (iOS anterior, Xcode anterior, el sistema la rechaza o la termina), no pasa nada
/// especial: el trabajo se pausa al salir y se retoma al volver, igual que antes.
///
/// Se usa siempre desde el hilo principal.
final class BackgroundContinuation {
    static let shared = BackgroundContinuation()
    private init() {}

    /// La tarea de iOS ya arrancó y el trabajo puede seguir con la app en segundo plano.
    private(set) var isActive = false

    private var isRequested = false
    private var requestedID: String?
    private var onExpire: (() -> Void)?
    private var lastFraction = 0.0
    private var lastUnits: Int64 = -1
    private var systemTask: AnyObject?
    private let totalUnits: Int64 = 1000

    /// Pide la tarea. Debe llamarse justo cuando el usuario pulsa Procesar o Reanudar, con la app en primer plano.
    /// `onExpire` se llama si iOS termina la tarea antes de tiempo (límite, batería, el usuario la detuvo…).
    func begin(title: String, subtitle: String, onExpire: @escaping () -> Void) {
        self.onExpire = onExpire
        guard !isRequested else { return }
        #if compiler(>=6.2)
        guard #available(iOS 26.0, *) else { return }
        let suffix = String(UUID().uuidString.prefix(8))
        let identifier = "\(Bundle.main.bundleIdentifier ?? "com.hugovela.Astral").process.\(suffix)"
        let registered = BGTaskScheduler.shared.register(forTaskWithIdentifier: identifier, using: nil) { [weak self] task in
            guard let continued = task as? BGContinuedProcessingTask else {
                task.setTaskCompleted(success: false)
                return
            }
            DispatchQueue.main.async { self?.taskDidStart(continued) }
        }
        guard registered else { return }
        let request = BGContinuedProcessingTaskRequest(identifier: identifier, title: title, subtitle: subtitle)
        request.strategy = .fail   // si no puede empezar ya, se sigue con el comportamiento de siempre
        do {
            try BGTaskScheduler.shared.submit(request)
            isRequested = true
            requestedID = identifier
            lastFraction = 0
            lastUnits = -1
        } catch {
            // iOS no aceptó la tarea: todo sigue funcionando como antes (pausa al salir, continúa al volver).
        }
        #endif
    }

    /// Avance total del trabajo (0...1). iOS lo muestra en su barra de progreso.
    /// Nunca llega al 100 % mientras el trabajo sigue: iOS cierra las tareas cuyo progreso ya figura completo.
    func report(_ fraction: Double) {
        lastFraction = min(max(fraction, 0), 0.99)
        #if compiler(>=6.2)
        guard isActive, #available(iOS 26.0, *), let task = systemTask as? BGContinuedProcessingTask else { return }
        let units = Int64(lastFraction * Double(totalUnits))
        guard units != lastUnits else { return }
        lastUnits = units
        task.progress.completedUnitCount = units
        #endif
    }

    /// El trabajo terminó, falló o se canceló.
    func end(success: Bool) {
        guard isRequested || isActive else { return }
        if !isActive, let id = requestedID {
            BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: id)   // la tarea aún no había arrancado
        }
        finishSystemTask(success: success)
        isRequested = false
        requestedID = nil
        onExpire = nil
        lastFraction = 0
        lastUnits = -1
    }

    #if compiler(>=6.2)
    @available(iOS 26.0, *)
    private func taskDidStart(_ task: BGContinuedProcessingTask) {
        // El trabajo ya terminó antes de que iOS iniciara la tarea: se cierra de inmediato.
        guard isRequested else { task.setTaskCompleted(success: false); return }
        systemTask = task
        isActive = true
        task.progress.totalUnitCount = totalUnits
        task.progress.completedUnitCount = Int64(lastFraction * Double(totalUnits))
        task.expirationHandler = { [weak self] in
            DispatchQueue.main.async { self?.taskDidExpire() }
        }
    }
    #endif

    private func taskDidExpire() {
        guard isActive else { return }
        let handler = onExpire
        finishSystemTask(success: false)
        isRequested = false
        requestedID = nil
        onExpire = nil
        handler?()
    }

    private func finishSystemTask(success: Bool) {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *), let task = systemTask as? BGContinuedProcessingTask {
            if success { task.progress.completedUnitCount = task.progress.totalUnitCount }
            task.setTaskCompleted(success: success)
        }
        #endif
        systemTask = nil
        isActive = false
    }
}
