# Astral

App de iOS que mejora videos y fotos **directamente en el iPhone**: sube la resolución, aumenta los fps, quita fondos y ajusta el color con modelos de IA que funcionan sin conexión. No hay servidores, cuentas, analíticas ni anuncios.

- **Requisitos:** iPhone con iOS 18 o posterior (el proyecto es solo para iPhone).
- **Idiomas:** español, inglés, portugués, francés, alemán, italiano, japonés, coreano y chino simplificado.

## Qué hace

| Herramienta | Detalle |
|---|---|
| **Mejora de video** | Escalado (×2 / ×4), aumento de fps por interpolación (×2 o ×4), cámara lenta, recorte, conservar HDR, calidad y resolución de exportación. Los videos largos se procesan por partes y se pueden reanudar si se interrumpen. |
| **Mejorar imagen** | Escalado de fotos hasta 4×. |
| **Quitar fondo** | Recorte del sujeto con el reconocimiento de sujetos de iOS (Vision). |
| **Color** | Looks y ajustes (exposición, contraste, saturación, temperatura, etc.) para fotos y videos. |

Además: presets, procesamiento por lotes, comparador antes/después con zoom, notificaciones opcionales, guardar en Fotos / Archivos / Compartir, temas claro y oscuro, etiquetas de VoiceOver en los controles que solo tienen icono, aviso de poco espacio antes de procesar un video grande y una pantalla de bienvenida con ejemplos (`Astral/Resources/Demo`).

## Modelos

Todos se incluyen dentro de la app y corren con Core ML:

- **Escalado:** Real-ESRGAN (AnimeVideo v3, General ×4, Anime 6B, x4plus) y Aurora ×2 / ×4 (2xHFA2kCompact y animerd v1).
- **Interpolación:** RIFE 4.25 (fp16 y fp32, formato horizontal 1920×1152 y vertical 1152×1920).

Autores y licencias: `LICENSES.md` (también se muestran dentro de la app en *Ajustes › Créditos y licencias*).

## Estructura

```
Astral/
  AstralApp.swift
  Core/        procesadores (video, imagen, interpolación), modelos de vista, traducciones, guardado
  UI/          pantallas y vistas (ContentView, Ajustes, bienvenida, comparadores, política de privacidad)
  Resources/   modelos Core ML, imágenes y videos de ejemplo (Demo), PrivacyInfo.xcprivacy,
               textos de los permisos en cada idioma (*.lproj/InfoPlist.strings)
project.yml    configuración de XcodeGen
.github/workflows/
  convert-sr.yml    convierte los modelos de escalado a Core ML y los publica en el release «sr-models»
  convert-rife.yml  convierte RIFE a Core ML y lo publica en el release «rife-models»
  build.yml         descarga los modelos, genera el proyecto con XcodeGen, compila e IPA sin firmar
```

## Compilar en la nube

1. **Una sola vez por repositorio:** ejecutar a mano `convert-sr.yml` y `convert-rife.yml`. Dejan los modelos como archivos de los releases `sr-models` y `rife-models`, que se conservan entre ejecuciones.
2. Ejecutar `build.yml`. Descarga esos releases, genera el proyecto, compila para iPhone y sube el `.ipa` como artefacto. El nombre sale de la versión de `project.yml` y del número de ejecución (por ejemplo, `Astral-v1.14.1-build27.ipa`).

El IPA no está firmado: para instalarlo en un iPhone o subirlo a TestFlight hace falta una cuenta de Apple Developer y firmarlo.

## Privacidad

Todo se procesa en el dispositivo. La política está dentro de la app y en `index.html`; la página de soporte es `support.html` (ambas en los 9 idiomas). `Astral/Resources/PrivacyInfo.xcprivacy` declara que no hay seguimiento ni datos recopilados y los usos de las APIs que Apple pide justificar (UserDefaults, fechas de archivos y espacio en disco).

## Estado

Pendiente antes de publicar: probar en iPhones reales (memoria, temperatura, videos largos, sincronía de audio), firma y TestFlight, y la causa real del rechazo de Fotos con videos de muchos fps (hoy se ofrece guardarlos en Archivos).
