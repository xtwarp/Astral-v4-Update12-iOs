import Foundation
import AVFoundation
import CoreMedia

/// Trabajo de mejora de video dividido en partes. Cada parte terminada se guarda en disco,
/// así, si la app se cierra o se interrumpe, se puede continuar desde la última parte completada.
struct ResumeJob: Codable, Equatable {
    var id: String
    /// Nombre del archivo copiado dentro de la carpeta del trabajo ("" = no hay copia, no se puede reanudar).
    var inputFile: String
    var rangeStart: Double
    var rangeEnd: Double
    var segmentCount: Int
    var doneSegments: Int
    var upscale: Bool
    var interpolate: Bool
    var slowMotion: Bool
    var modelRaw: String
    var factor: Int
    var precisionRaw: String
    var exportQualityRaw: Int
    var exportShortSide: Int?
    var keepHDR: Bool
    var sourceFps: Double
    var sourceWidth: Int
    var sourceHeight: Int
    var videoDuration: Double
    /// `true` si el usuario recortó el video (en un trabajo de una sola parte sin recorte se procesa el archivo entero).
    var trimmed: Bool
    /// Intensidad de limpieza del modelo General (nil en trabajos guardados por versiones anteriores = 100).
    var cleanup: Int?
    /// Salida a fps fijos (60 o 120). nil = multiplicador (usa `factor`). Los trabajos guardados antes de esta opción no lo traen.
    var targetFps: Int?

    /// Duración aproximada de cada parte, en segundos de video original.
    static let targetSegmentSeconds = 15.0

    static func segmentCount(for seconds: Double) -> Int {
        max(1, Int((seconds / targetSegmentSeconds).rounded()))
    }

    private var fps: Double { max(sourceFps, 1) }

    /// Los cortes caen a media distancia entre dos frames para que ninguno se repita ni se pierda.
    private func boundary(_ index: Int) -> Double {
        if index <= 0 { return rangeStart }
        if index >= segmentCount { return rangeEnd }
        let frames = ((rangeEnd - rangeStart) * fps / Double(segmentCount) * Double(index)).rounded()
        return rangeStart + (frames - 0.5) / fps
    }

    /// Rango de tiempo de una parte. nil = el video entero (trabajo de una sola parte sin recorte).
    func timeRange(forSegment index: Int) -> CMTimeRange? {
        if segmentCount == 1 {
            guard trimmed else { return nil }
            return CMTimeRange(start: CMTime(seconds: rangeStart, preferredTimescale: 6000),
                               end: CMTime(seconds: rangeEnd, preferredTimescale: 6000))
        }
        var start = boundary(index)
        // Al interpolar, cada parte empieza un frame antes para generar los frames que quedan entre dos partes.
        if index > 0 && interpolate { start -= 1 / fps }
        return CMTimeRange(start: CMTime(seconds: max(start, 0), preferredTimescale: 6000),
                           end: CMTime(seconds: boundary(index + 1), preferredTimescale: 6000))
    }

    /// Número de frames originales que quedan antes del corte `index` (índice del primer frame de esa parte).
    private func frameBoundary(_ index: Int) -> Int {
        if index <= 0 { return 0 }
        return Int(((rangeEnd - rangeStart) * fps / Double(segmentCount) * Double(index)).rounded())
    }

    /// Cuadrícula de fps fijos de una parte. nil si el trabajo usa multiplicador.
    func fixedGrid(forSegment index: Int) -> FixedGrid? {
        guard interpolate, let targetFps else { return nil }
        // Igual que en `timeRange`: las partes siguientes empiezan un frame antes para cubrir el hueco entre partes.
        let first = index > 0 ? frameBoundary(index) - 1 : 0
        let end: Int? = index + 1 < segmentCount ? frameBoundary(index + 1) - 1 : nil
        return FixedGrid(fps: Double(targetFps), sourceFps: fps, firstFrame: first, endFrame: end)
    }

    /// Con salida fija cada parte ya cubre justo su tramo (sin frame repetido que recortar al unirlas).
    var overlapsBetweenSegments: Bool { interpolate && targetFps == nil }

    /// Duración de un frame del resultado (para saltar el frame repetido al unir las partes).
    var outputFrameSeconds: Double {
        guard interpolate else { return 1 / fps }
        if let targetFps { return 1 / Double(targetFps) }
        return slowMotion ? 1 / fps : 1 / (fps * Double(factor))
    }
}

/// Carpeta persistente de los trabajos pendientes (Application Support, no se borra con "Vaciar caché").
enum ResumeStore {
    private static var root: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return base.appendingPathComponent("AstralResume", isDirectory: true)
    }

    static func directory(_ id: String) -> URL { root.appendingPathComponent(id, isDirectory: true) }

    static func inputURL(_ job: ResumeJob) -> URL { directory(job.id).appendingPathComponent(job.inputFile) }

    static func segmentURL(_ job: ResumeJob, _ index: Int) -> URL {
        directory(job.id).appendingPathComponent(String(format: "seg_%03d.mp4", index))
    }

    private static func jsonURL(_ id: String) -> URL { directory(id).appendingPathComponent("job.json") }

    /// Crea la carpeta del trabajo y copia (o enlaza) el video de entrada. Devuelve el nombre del archivo, o nil si falla.
    static func prepare(job: ResumeJob, copying source: URL) -> String? {
        let manager = FileManager.default
        do {
            try manager.createDirectory(at: directory(job.id), withIntermediateDirectories: true)
            let name = "input.mp4"
            let destination = directory(job.id).appendingPathComponent(name)
            try? manager.removeItem(at: destination)
            do { try manager.linkItem(at: source, to: destination) } catch { try manager.copyItem(at: source, to: destination) }
            return name
        } catch {
            try? manager.removeItem(at: directory(job.id))
            return nil
        }
    }

    static func save(_ job: ResumeJob) {
        guard let data = try? JSONEncoder().encode(job) else { return }
        try? data.write(to: jsonURL(job.id), options: .atomic)
    }

    /// Trabajo pendiente más reciente cuya entrada sigue existiendo. Las partes que faltan se descuentan.
    static func loadPending() -> ResumeJob? {
        let manager = FileManager.default
        let folders = (try? manager.contentsOfDirectory(at: root, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        var found: [(job: ResumeJob, date: Date)] = []
        for folder in folders {
            let json = folder.appendingPathComponent("job.json")
            guard let data = try? Data(contentsOf: json), var job = try? JSONDecoder().decode(ResumeJob.self, from: data) else {
                try? manager.removeItem(at: folder); continue
            }
            guard !job.inputFile.isEmpty, manager.fileExists(atPath: inputURL(job).path) else {
                try? manager.removeItem(at: folder); continue
            }
            var valid = 0
            while valid < job.doneSegments, manager.fileExists(atPath: segmentURL(job, valid).path) { valid += 1 }
            job.doneSegments = valid
            let date = (try? json.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
            found.append((job, date))
        }
        return found.sorted { $0.date > $1.date }.first?.job
    }

    static func clear(_ id: String) {
        try? FileManager.default.removeItem(at: directory(id))
    }
}

/// Une las partes terminadas en un solo video (sin volver a codificar) y le pone el audio original.
enum SegmentStitcher {
    static func stitch(job: ResumeJob, segmentURLs: [URL], inputURL: URL) async throws -> URL {
        do {
            return try await build(job: job, segmentURLs: segmentURLs, inputURL: inputURL, skipOverlap: true)
        } catch {
            // Plan B: si el sistema no acepta recortar el frame repetido, se une sin recortarlo.
            return try await build(job: job, segmentURLs: segmentURLs, inputURL: inputURL, skipOverlap: false)
        }
    }

    private static func build(job: ResumeJob, segmentURLs: [URL], inputURL: URL, skipOverlap: Bool) async throws -> URL {
        let composition = AVMutableComposition()
        guard let videoTrack = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw UpscaleError.exportFailed
        }
        var cursor = CMTime.zero
        var transform: CGAffineTransform?
        let skip = CMTime(seconds: job.outputFrameSeconds, preferredTimescale: 60_000)

        for (index, url) in segmentURLs.enumerated() {
            let asset = AVURLAsset(url: url)
            guard let source = try await asset.loadTracks(withMediaType: .video).first else { throw UpscaleError.invalidVideo }
            let range = try await source.load(.timeRange)
            if transform == nil { transform = try await source.load(.preferredTransform) }
            var start = range.start
            var duration = range.duration
            if skipOverlap, index > 0, job.overlapsBetweenSegments {
                start = CMTimeAdd(start, skip)
                duration = CMTimeSubtract(duration, skip)
            }
            guard CMTimeCompare(duration, .zero) > 0 else { continue }
            try videoTrack.insertTimeRange(CMTimeRange(start: start, duration: duration), of: source, at: cursor)
            cursor = CMTimeAdd(cursor, duration)
        }
        videoTrack.preferredTransform = transform ?? .identity

        // El audio se toma del video original (en cámara lenta el resultado no lleva audio).
        if !job.slowMotion {
            let original = AVURLAsset(url: inputURL)
            if let audio = try await original.loadTracks(withMediaType: .audio).first,
               let audioTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
                let wanted = min(job.rangeEnd - job.rangeStart, CMTimeGetSeconds(cursor))
                if wanted > 0 {
                    let range = CMTimeRange(start: CMTime(seconds: job.rangeStart, preferredTimescale: 60_000),
                                            duration: CMTime(seconds: wanted, preferredTimescale: 60_000))
                    try? audioTrack.insertTimeRange(range, of: audio, at: .zero)
                }
            }
        }

        guard let session = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetPassthrough) else {
            throw UpscaleError.exportFailed
        }
        let output = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Result_\(UUID().uuidString).mp4")
        try? FileManager.default.removeItem(at: output)
        session.outputURL = output
        session.outputFileType = .mp4
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            session.exportAsynchronously { continuation.resume() }
        }
        guard session.status == .completed else {
            try? FileManager.default.removeItem(at: output)
            throw session.error ?? UpscaleError.exportFailed
        }
        return output
    }
}
