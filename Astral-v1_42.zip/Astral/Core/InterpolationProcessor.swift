import Foundation
import AVFoundation
import CoreVideo

/// Salida a fps fijos (p. ej. 60 o 120): cada frame de salida cae en el instante g / fps de toda la línea de tiempo
/// del trabajo, y se calcula con RIFE en la posición exacta entre dos frames originales.
/// Las partes de un video largo comparten esa misma cuadrícula, así que encajan sin saltos ni duplicados.
struct FixedGrid: Equatable {
    /// fps de salida.
    var fps: Double
    /// fps del video original (los mismos en todas las partes del trabajo).
    var sourceFps: Double
    /// Índice (en todo el trabajo) del primer frame original que lee esta parte.
    var firstFrame: Int
    /// Índice (en todo el trabajo) del último frame original que lee esta parte, o nil si es la última parte.
    var endFrame: Int?
}

/// Interpola frames con RIFE y, si se pide, escala cada frame resultante con Real-ESRGAN justo después.
/// Los dos modelos nunca corren al mismo tiempo: por cada frame se interpola y, acto seguido, se escala,
/// uno después del otro, antes de pasar al siguiente. No se genera un vídeo intermedio.
final class InterpolationProcessor {
    private let queue = DispatchQueue(label: "astral.interpolation", qos: .userInitiated)
    private let stateLock = NSLock()
    private var cancelled = false

    func cancel() {
        stateLock.lock(); cancelled = true; stateLock.unlock()
    }

    private func isCancelled() -> Bool {
        stateLock.lock(); defer { stateLock.unlock() }
        return cancelled
    }

    func process(
        inputURL: URL,
        timeRange: CMTimeRange? = nil,
        factor: Int,
        precision: RIFEInterpolator.Precision,
        upscaleModel: RealESRGAN.Model?,
        exportShortSide: Int? = nil,
        slowMotion: Bool = false,
        fixed: FixedGrid? = nil,
        keepHDR: Bool = false,
        progress: @escaping (Double, String) -> Void,
        framePreview: @escaping (CVPixelBuffer, Int) -> Void,
        completion: @escaping (Result<URL, Error>) -> Void
    ) {
        stateLock.lock(); cancelled = false; stateLock.unlock()
        queue.async { [weak self] in
            guard let self else { return }
            autoreleasepool {
                do {
                    let output = try self.run(
                        inputURL: inputURL, timeRange: timeRange, factor: factor, precision: precision, upscaleModel: upscaleModel,
                        exportShortSide: exportShortSide, slowMotion: slowMotion, fixed: fixed, keepHDR: keepHDR, progress: progress, framePreview: framePreview
                    )
                    DispatchQueue.main.async { completion(.success(output)) }
                } catch {
                    DispatchQueue.main.async { completion(.failure(error)) }
                }
            }
        }
    }

    private func run(
        inputURL: URL,
        timeRange: CMTimeRange?,
        factor: Int,
        precision: RIFEInterpolator.Precision,
        upscaleModel: RealESRGAN.Model?,
        exportShortSide: Int?,
        slowMotion requestedSlowMotion: Bool,
        fixed: FixedGrid?,
        keepHDR: Bool,
        progress: @escaping (Double, String) -> Void,
        framePreview: @escaping (CVPixelBuffer, Int) -> Void
    ) throws -> URL {
        // Con salida fija no hay cámara lenta: los fps de salida ya son los que se eligieron.
        let slowMotion = requestedSlowMotion && fixed == nil
        let asset = AVAsset(url: inputURL)
        guard let videoTrack = asset.tracks(withMediaType: .video).first else { throw UpscaleError.invalidVideo }

        let durationSeconds = timeRange.map { CMTimeGetSeconds($0.duration) } ?? CMTimeGetSeconds(asset.duration)
        guard durationSeconds.isFinite, durationSeconds > 0 else { throw UpscaleError.invalidVideo }

        let sourceFps = videoTrack.nominalFrameRate > 0 ? Double(videoTrack.nominalFrameRate) : 24.0
        let outputFps = fixed?.fps ?? sourceFps * Double(factor)
        // Cámara lenta: los frames nuevos se reproducen a los fps originales, así el vídeo dura ×factor.
        let playbackFps = slowMotion ? sourceFps : outputFps
        let expectedSourceFrames = max(Int(ceil(durationSeconds * sourceFps)), 1)
        let expectedOutputFrames = fixed != nil
            ? max(Int(ceil(durationSeconds * outputFps)), 1)
            : max(expectedSourceFrames * factor, 1)

        let naturalSize = videoTrack.naturalSize
        let encodedWidth = Int(abs(naturalSize.width.rounded()))
        let encodedHeight = Int(abs(naturalSize.height.rounded()))
        guard encodedWidth > 0, encodedHeight > 0 else { throw UpscaleError.invalidVideo }

        let scale = upscaleModel?.scale ?? 1
        let processedWidth = encodedWidth * scale
        let processedHeight = encodedHeight * scale
        // Calidad de exportación: solo reduce (lado corto), nunca agranda.
        var outputWidth = processedWidth
        var outputHeight = processedHeight
        if let target = exportShortSide, min(processedWidth, processedHeight) > target {
            let ratio = Double(target) / Double(min(processedWidth, processedHeight))
            outputWidth = max(2, Int((Double(processedWidth) * ratio).rounded()) & ~1)
            outputHeight = max(2, Int((Double(processedHeight) * ratio).rounded()) & ~1)
        }
        let needsResize = outputWidth != processedWidth || outputHeight != processedHeight
        if upscaleModel != nil {
            guard !RealESRGAN.exceedsSafeLimit(width: encodedWidth, height: encodedHeight, scale: scale) else {
                throw UpscaleError.frameTooLarge(width: encodedWidth, height: encodedHeight)
            }
        }

        progress(0.01, tr("Preparando vídeo…", "Preparing video…"))

        let reader = try AVAssetReader(asset: asset)
        if let timeRange { reader.timeRange = timeRange }
        let startOffset = timeRange?.start ?? .zero
        let videoOutput = AVAssetReaderTrackOutput(
            track: videoTrack,
            outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        )
        videoOutput.alwaysCopiesSampleData = false
        guard reader.canAdd(videoOutput) else { throw UpscaleError.readerFailed }
        reader.add(videoOutput)

        var audioOutput: AVAssetReaderTrackOutput?
        if !slowMotion, let audioTrack = asset.tracks(withMediaType: .audio).first {
            let candidate = AVAssetReaderTrackOutput(track: audioTrack, outputSettings: nil)
            candidate.alwaysCopiesSampleData = false
            if reader.canAdd(candidate) { reader.add(candidate); audioOutput = candidate }
        }

        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("Astral_Result_\(UUID().uuidString).mp4")
        try? FileManager.default.removeItem(at: outputURL)

        let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mp4)
        let baseSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.hevc,
            AVVideoWidthKey: outputWidth,
            AVVideoHeightKey: outputHeight,
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: max(8_000_000, outputWidth * outputHeight * 5),
                AVVideoExpectedSourceFrameRateKey: playbackFps,
                AVVideoMaxKeyFrameIntervalKey: max(Int(playbackFps), 1)
            ]
        ]
        // HDR: solo si se pidió y el video lo es. Si el iPhone no admite exportarlo, se usa el modo normal.
        var activeHDR: HDRInfo? = keepHDR ? HDRSupport.info(for: videoTrack) : nil
        var videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: activeHDR.map { HDRSupport.writerSettings(baseSettings, hdr: $0) } ?? baseSettings)
        if activeHDR != nil, !writer.canAdd(videoInput) {
            activeHDR = nil
            videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: baseSettings)
        }
        videoInput.expectsMediaDataInRealTime = false
        videoInput.transform = videoTrack.preferredTransform
        guard writer.canAdd(videoInput) else { throw UpscaleError.writerFailed }
        writer.add(videoInput)

        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: videoInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: outputWidth,
                kCVPixelBufferHeightKey as String: outputHeight,
                kCVPixelBufferIOSurfacePropertiesKey as String: [:]
            ]
        )

        var audioInput: AVAssetWriterInput?
        if !slowMotion, let audioTrack = asset.tracks(withMediaType: .audio).first,
           let audioOutput,
           let firstDescription = audioTrack.formatDescriptions.first {
            let format = firstDescription as! CMFormatDescription
            let input = AVAssetWriterInput(mediaType: .audio, outputSettings: nil, sourceFormatHint: format)
            input.expectsMediaDataInRealTime = false
            if writer.canAdd(input) { writer.add(input); audioInput = input }
        }

        // El escritor intercala audio y vídeo: si el vídeo avanza y el audio no recibe datos,
        // el escritor deja de aceptar vídeo (isReadyForMoreMediaData = false) y se atasca.
        // Por eso el audio se alimenta a la par que el vídeo.
        var audioFinished = (audioInput == nil)
        func pumpAudio() {
            guard let audioOutput, let audioInput, !audioFinished else { return }
            while audioInput.isReadyForMoreMediaData {
                guard let sample = audioOutput.copyNextSampleBuffer() else {
                    audioInput.markAsFinished(); audioFinished = true; return
                }
                if !audioInput.append(sample) { audioFinished = true; return }
            }
        }

        guard reader.startReading() else { throw reader.error ?? UpscaleError.readerFailed }
        guard writer.startWriting() else { throw writer.error ?? UpscaleError.writerFailed }
        writer.startSession(atSourceTime: startOffset)

        let interpolator = RIFEInterpolator(precision: precision)
        let upscaler = try upscaleModel.map { try RealESRGAN(model: $0) }

        func waitForInput() throws {
            try WriterWait.until(videoInput, writer: writer, reader: reader, pump: pumpAudio, isCancelled: isCancelled)
        }

        // Si el mismo frame se emite varias veces seguidas (pausas del dibujo), se reutiliza su versión ya procesada.
        var cachedSource: CVPixelBuffer?
        var cachedFinal: CVPixelBuffer?
        var cachedExport: CVPixelBuffer?

        func emit(_ buffer: CVPixelBuffer, outputIndex: Int) throws {
            if isCancelled() { reader.cancelReading(); writer.cancelWriting(); throw UpscaleError.cancelled }
            try waitForInput()
            let finalBuffer: CVPixelBuffer
            let exportBuffer: CVPixelBuffer
            if let cachedSource, cachedSource === buffer, let cachedFinal, let cachedExport {
                finalBuffer = cachedFinal
                exportBuffer = cachedExport
            } else {
                if let upscaler {
                    finalBuffer = try autoreleasepool { try upscaler.upscale(pixelBuffer: buffer) { self.isCancelled() } }
                } else {
                    finalBuffer = buffer
                }
                exportBuffer = needsResize
                    ? try autoreleasepool { try PixelBufferTools.resized(finalBuffer, width: outputWidth, height: outputHeight) }
                    : finalBuffer
                cachedSource = buffer
                cachedFinal = finalBuffer
                cachedExport = exportBuffer
            }
            if let activeHDR { HDRSupport.tag(exportBuffer, hdr: activeHDR) }
            let pts = CMTimeAdd(startOffset, CMTime(value: Int64((Double(outputIndex) / playbackFps * 60_000).rounded()), timescale: 60_000))
            guard adaptor.append(exportBuffer, withPresentationTime: pts) else {
                reader.cancelReading(); writer.cancelWriting(); throw writer.error ?? UpscaleError.writerFailed
            }
            pumpAudio()
            framePreview(finalBuffer, outputIndex + 1)
            let value = min(Double(outputIndex + 1) / Double(expectedOutputFrames), 0.97)
            progress(value, tr("Procesando frame \(outputIndex + 1)/\(expectedOutputFrames)", "Processing frame \(outputIndex + 1)/\(expectedOutputFrames)"))
        }

        var previousFrame: CVPixelBuffer?
        var outputIndex = 0

        if slowMotion {
            // Cámara lenta suave. En animación un mismo dibujo suele mantenerse 2-3 fotogramas;
            // interpolar entre fotogramas consecutivos repite ese dibujo y el vídeo "se para y arranca".
            // Aquí se detectan esos dibujos repetidos y se interpola entre dibujos DISTINTOS,
            // repartiendo los frames nuevos a lo largo de toda la pausa. En vídeo real (sin repetidos)
            // el resultado es el mismo que antes.
            let duplicateThreshold = 1.0   // diferencia media (0-255) por debajo de la cual el frame se considera repetido
            let sceneCutThreshold = 40.0   // por encima se considera un corte de escena: no se interpola entre escenas
            let maxSmoothHold = 4          // pausas más largas son quietud real: se mantiene el frame y solo se interpola el último tramo

            var keyFrame: CVPixelBuffer?
            var keySignature: FrameSignature?
            var runLength = 0

            func finishRun(next: CVPixelBuffer?, isCut: Bool) throws {
                guard let key = keyFrame else { return }
                if let next, !isCut {
                    let smoothSpan = runLength <= maxSmoothHold ? runLength : 1
                    let holdFrames = (runLength - smoothSpan) * factor
                    for _ in 0..<holdFrames {
                        try emit(key, outputIndex: outputIndex); outputIndex += 1
                    }
                    let steps = smoothSpan * factor
                    try emit(key, outputIndex: outputIndex); outputIndex += 1
                    for step in 1..<steps {
                        let t = Float(step) / Float(steps)
                        let mid = try autoreleasepool {
                            try interpolator.interpolate(a: key, b: next, t: t)
                        }
                        try emit(mid, outputIndex: outputIndex); outputIndex += 1
                    }
                } else if next != nil {
                    for _ in 0..<(runLength * factor) {
                        try emit(key, outputIndex: outputIndex); outputIndex += 1
                    }
                } else {
                    for _ in 0..<((runLength - 1) * factor + 1) {
                        try emit(key, outputIndex: outputIndex); outputIndex += 1
                    }
                }
            }

            while let sample = videoOutput.copyNextSampleBuffer() {
                if isCancelled() { reader.cancelReading(); writer.cancelWriting(); throw UpscaleError.cancelled }
                guard let frame = CMSampleBufferGetImageBuffer(sample) else {
                    reader.cancelReading(); writer.cancelWriting(); throw UpscaleError.unsupportedPixelFormat
                }
                let signature = FrameSignature(pixelBuffer: frame)
                if keyFrame == nil {
                    keyFrame = frame
                    keySignature = signature
                    runLength = 1
                    continue
                }
                let difference = FrameSignature.difference(signature, keySignature)
                if difference <= duplicateThreshold {
                    runLength += 1
                    continue
                }
                try finishRun(next: frame, isCut: difference > sceneCutThreshold)
                keyFrame = frame
                keySignature = signature
                runLength = 1
            }
            try finishRun(next: nil, isCut: false)
        } else if let fixed {
            // Salida a fps fijos. `ratio` = frames de salida por cada frame original (puede no ser entero: 24→60 = 2.5).
            // El frame de salida g está en la posición g / ratio de los frames originales de todo el trabajo.
            let ratio = fixed.fps / max(fixed.sourceFps, 1)
            let epsilon = 1e-6
            let first = fixed.firstFrame
            let gStart = Int((Double(first) * ratio - epsilon).rounded(.up))
            let gEnd: Int? = fixed.endFrame.map { Int((Double($0) * ratio - epsilon).rounded(.up)) }
            var g = gStart
            var previous: CVPixelBuffer?
            var previousIndex = 0
            var localIndex = 0

            /// Posición del frame de salida g, en frames originales contados desde el primero de esta parte.
            func position(_ g: Int) -> Double { Double(g) / ratio - Double(first) }

            // Emite los frames de salida que caen entre `previous` y `current`.
            func emitBetween(current: CVPixelBuffer, currentIndex: Int) throws {
                guard let previous else { return }
                while true {
                    if let gEnd, g >= gEnd { return }
                    let pos = position(g)
                    if pos >= Double(currentIndex) - epsilon { return }
                    let t = pos - Double(previousIndex)
                    if t < 0.01 {
                        try emit(previous, outputIndex: g - gStart)
                    } else if t > 0.99 {
                        try emit(current, outputIndex: g - gStart)
                    } else {
                        let mid = try autoreleasepool {
                            try interpolator.interpolate(a: previous, b: current, t: Float(t))
                        }
                        try emit(mid, outputIndex: g - gStart)
                    }
                    g += 1
                }
            }

            while let sample = videoOutput.copyNextSampleBuffer() {
                if isCancelled() { reader.cancelReading(); writer.cancelWriting(); throw UpscaleError.cancelled }
                guard let currentFrame = CMSampleBufferGetImageBuffer(sample) else {
                    reader.cancelReading(); writer.cancelWriting(); throw UpscaleError.unsupportedPixelFormat
                }
                try emitBetween(current: currentFrame, currentIndex: localIndex)
                previous = currentFrame
                previousIndex = localIndex
                localIndex += 1
            }
            // Cola: el último frame original (y, si faltaron frames por un video de fps variable, se mantiene hasta el final de la parte).
            if let previous {
                while true {
                    if let gEnd {
                        if g >= gEnd { break }
                    } else if position(g) > Double(previousIndex) + epsilon {
                        break
                    }
                    try emit(previous, outputIndex: g - gStart); g += 1
                }
            }
        } else {
            while let sample = videoOutput.copyNextSampleBuffer() {
                if isCancelled() { reader.cancelReading(); writer.cancelWriting(); throw UpscaleError.cancelled }
                guard let currentFrame = CMSampleBufferGetImageBuffer(sample) else {
                    reader.cancelReading(); writer.cancelWriting(); throw UpscaleError.unsupportedPixelFormat
                }

                if let previousFrame {
                    try emit(previousFrame, outputIndex: outputIndex); outputIndex += 1
                    if factor > 1 {
                        for step in 1..<factor {
                            let t = Float(step) / Float(factor)
                            let mid = try autoreleasepool {
                                try interpolator.interpolate(a: previousFrame, b: currentFrame, t: t)
                            }
                            try emit(mid, outputIndex: outputIndex); outputIndex += 1
                        }
                    }
                }
                previousFrame = currentFrame
            }
            if let previousFrame {
                try emit(previousFrame, outputIndex: outputIndex); outputIndex += 1
            }
        }

        if reader.status == .failed {
            writer.cancelWriting(); throw reader.error ?? UpscaleError.readerFailed
        }
        videoInput.markAsFinished()

        let audioDrainStart = Date()
        while !audioFinished {
            if isCancelled() { reader.cancelReading(); writer.cancelWriting(); throw UpscaleError.cancelled }
            pumpAudio()
            if audioFinished { break }
            if writer.status == .failed { throw writer.error ?? UpscaleError.writerFailed }
            if Date().timeIntervalSince(audioDrainStart) > 120 { writer.cancelWriting(); throw UpscaleError.writerStalled }
            Thread.sleep(forTimeInterval: 0.002)
        }

        guard !isCancelled() else { writer.cancelWriting(); throw UpscaleError.cancelled }
        let semaphore = DispatchSemaphore(value: 0)
        writer.finishWriting { semaphore.signal() }
        semaphore.wait()
        guard writer.status == .completed else { throw writer.error ?? UpscaleError.exportFailed }
        progress(1.0, tr("Terminado", "Finished"))
        return outputURL
    }
}
