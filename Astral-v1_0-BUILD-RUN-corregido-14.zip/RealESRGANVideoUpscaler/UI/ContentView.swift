import SwiftUI
import AVFoundation
import AVKit
import PhotosUI
import UniformTypeIdentifiers

struct ContentView: View {
    enum Tab: String { case video = "VIDEO", image = "IMAGEN", interpolate = "INTERPOLAR", background = "FONDO", color = "COLOR" }

    private func title(for tab: Tab) -> String {
        switch tab {
        case .video: return L.tabVideo.text
        case .image: return L.tabImage.text
        case .interpolate: return L.tabInterpolate.text
        case .background: return L.tabBackground.text
        case .color: return L.tabColor.text
        }
    }

    @ObservedObject private var languageStore = AppLanguageStore.shared
    @StateObject private var videoVM = VideoViewModel()
    @StateObject private var imageVM = ImageViewModel()
    @StateObject private var interpVM = InterpolationViewModel()
    @StateObject private var backgroundVM = BackgroundViewModel()
    @StateObject private var colorVM = ColorViewModel()
    @State private var tab: Tab = .video
    @State private var selectedVideo: PhotosPickerItem?
    @State private var selectedImage: PhotosPickerItem?
    @State private var selectedInterpVideo: PhotosPickerItem?
    @State private var inputPlayer: AVPlayer?
    @State private var interpInputPlayer: AVPlayer?
    @State private var showSettings = false
    @State private var batchVideoItems: [PhotosPickerItem] = []
    @State private var batchInterpItems: [PhotosPickerItem] = []
    @State private var batchImageItems: [PhotosPickerItem] = []
    @State private var presetsKind: Preset.Kind?
    @State private var selectedBackgroundImage: PhotosPickerItem?
    @State private var selectedColorItem: PhotosPickerItem?
    @State private var batchBackgroundItems: [PhotosPickerItem] = []

    var body: some View {
        withSheets(withChangeHandlersB(withChangeHandlersA(mainContent)))
    }

    private var mainContent: some View {
        GeometryReader { geometry in
            ZStack {
                NeonBackground().ignoresSafeArea()

                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 14) {
                        tabs
                        switch tab {
                        case .video: videoView(geometry: geometry)
                        case .image: imageView(geometry: geometry)
                        case .interpolate: interpolateView(geometry: geometry)
                        case .background: backgroundView(geometry: geometry)
                        case .color: colorView(geometry: geometry)
                        }
                        Spacer(minLength: 0)
                    }
                    .frame(maxWidth: .infinity, minHeight: geometry.size.height, alignment: .top)
                    .padding(.horizontal, 8)
                    .padding(.top, 8)
                    .padding(.bottom, 28)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .preferredColorScheme(.dark)
    }

    private func withChangeHandlersA<V: View>(_ view: V) -> some View {
        view
        .onChange(of: languageStore.language) { _, _ in
            videoVM.relocalizeIdleStatus(); imageVM.relocalizeIdleStatus(); interpVM.relocalizeIdleStatus(); backgroundVM.relocalizeIdleStatus(); colorVM.relocalizeIdleStatus()
        }
        .onChange(of: batchVideoItems) { _, items in
            guard !items.isEmpty else { return }
            videoVM.startBatch(items)
            batchVideoItems = []
        }
        .onChange(of: selectedColorItem) { _, item in
            guard let item else { return }
            Task { await colorVM.importItem(item); selectedColorItem = nil }
        }
        .onChange(of: selectedBackgroundImage) { _, item in
            guard let item else { return }
            Task { await backgroundVM.importImage(from: item); selectedBackgroundImage = nil }
        }
        .onChange(of: batchBackgroundItems) { _, items in
            guard !items.isEmpty else { return }
            backgroundVM.startBatch(items)
            batchBackgroundItems = []
        }
        .onChange(of: batchImageItems) { _, items in
            guard !items.isEmpty else { return }
            imageVM.startBatch(items)
            batchImageItems = []
        }
    }

    private func withChangeHandlersB<V: View>(_ view: V) -> some View {
        view
        .onChange(of: batchInterpItems) { _, items in
            guard !items.isEmpty else { return }
            interpVM.startBatch(items)
            batchInterpItems = []
        }
        .onChange(of: selectedVideo) { _, item in
            guard let item else { return }
            Task { await videoVM.importVideo(from: item); selectedVideo = nil }
        }
        .onChange(of: selectedImage) { _, item in
            guard let item else { return }
            Task { await imageVM.importImage(from: item); selectedImage = nil }
        }
        .onChange(of: selectedInterpVideo) { _, item in
            guard let item else { return }
            Task { await interpVM.importVideo(from: item); selectedInterpVideo = nil }
        }
        .onChange(of: videoVM.inputURL) { _, url in
            inputPlayer?.pause()
            inputPlayer = url.map(AVPlayer.init)
            inputPlayer?.isMuted = true
        }
        .onChange(of: interpVM.inputURL) { _, url in
            interpInputPlayer?.pause()
            interpInputPlayer = url.map(AVPlayer.init)
            interpInputPlayer?.isMuted = true
        }
    }

    private func withSheets<V: View>(_ view: V) -> some View {
        view
        .sheet(item: $presetsKind) { kind in
            switch kind {
            case .video:
                PresetsSheet(kind: kind, current: { videoVM.makePreset(name: $0) }, apply: { videoVM.apply($0) })
            case .interpolate:
                PresetsSheet(kind: kind, current: { interpVM.makePreset(name: $0) }, apply: { interpVM.apply($0) })
            case .image:
                PresetsSheet(kind: kind, current: { imageVM.makePreset(name: $0) }, apply: { imageVM.apply($0) })
            }
        }
        .sheet(isPresented: $showSettings) {
            SettingsView(keepURLs: urlsToKeep, isBusy: anythingBusy)
        }
    }

    private var urlsToKeep: [URL] {
        var urls: [URL] = []
        urls += [videoVM.inputURL, videoVM.outputURL, interpVM.inputURL, interpVM.outputURL].compactMap { $0 }
        urls += videoVM.batchResults
        urls += interpVM.batchResults
        urls += imageVM.batchResults
        urls += backgroundVM.batchResults
        if let colorURL = colorVM.outputURL { urls.append(colorURL) }
        return urls
    }

    private var anythingBusy: Bool {
        let video: Bool = videoVM.isProcessing || videoVM.isBatchRunning
        let interp: Bool = interpVM.isProcessing || interpVM.isBatchRunning
        let image: Bool = imageVM.isBusy
        let background: Bool = backgroundVM.isBusy
        let color: Bool = colorVM.isExporting
        return video || interp || image || background || color
    }

    private var tabs: some View {
        VStack(spacing: 6) {
            HStack(spacing: 6) {
                HStack(spacing: 6) {
                    Circle().fill(Color(red: 0.35, green: 0.95, blue: 0.68)).frame(width: 7, height: 7)
                    Text(L.onDevice.text).font(.system(size: 9, weight: .bold, design: .rounded)).tracking(0.8)
                }
                .foregroundStyle(Color(red: 0.35, green: 0.95, blue: 0.68))
                Spacer()
                Button { showSettings = true } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(LocalStyle.mint)
                        .frame(width: 30, height: 30)
                        .background(Color.white.opacity(0.055), in: Circle())
                        .overlay(Circle().stroke(LocalStyle.mint.opacity(0.35), lineWidth: 1))
                }
            }
            HStack(spacing: 4) {
                tabButton(.video)
                tabButton(.image)
                tabButton(.interpolate)
            }
            HStack(spacing: 4) {
                tabButton(.background)
                tabButton(.color)
            }
        }
        .padding(4)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 13))
    }

    private func tabButton(_ value: Tab) -> some View {
        Button { tab = value } label: {
            Text(title(for: value))
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .tracking(0.5)
                .minimumScaleFactor(0.75)
                .lineLimit(1)
                .foregroundStyle(tab == value ? .black : .white.opacity(0.55))
                .frame(height: 38)
                .frame(maxWidth: .infinity)
                .background(tab == value ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.clear), in: RoundedRectangle(cornerRadius: 10))
                .shadow(color: tab == value ? LocalStyle.mint.opacity(0.45) : Color.clear, radius: 10)
        }
    }

    @ViewBuilder
    private func videoView(geometry: GeometryProxy) -> some View {
        videoPreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.52, 320))

        if let url = videoVM.inputURL, videoVM.videoDuration > 0 {
            TrimBar(url: url, duration: videoVM.videoDuration, start: $videoVM.trimStart, end: $videoVM.trimEnd,
                    disabled: videoVM.isProcessing || videoVM.isBatchRunning)
        }

        modelSelector(models: RealESRGAN.Model.videoModels, selected: videoVM.selectedModel) { videoVM.selectedModel = $0 }

        interpolateAlsoToggle

        PhotosPicker(selection: $selectedVideo, matching: .videos, photoLibrary: .shared()) {
            pickerButton(title: L.selectVideo.text, icon: "video.badge.plus")
        }
        .disabled(videoVM.isProcessing || videoVM.isBatchRunning)

        HStack(spacing: 8) {
            presetsCompactButton(.video, busy: videoVM.isProcessing || videoVM.isBatchRunning)
            batchCompactPicker(selection: $batchVideoItems, maxCount: 20, matching: .videos, busy: videoVM.isProcessing || videoVM.isBatchRunning)
        }

        BatchSummary(isRunning: videoVM.isBatchRunning, index: videoVM.batchIndex, total: videoVM.batchTotal,
                     failures: videoVM.batchFailures, results: videoVM.batchResults)

        if videoVM.isProcessing || videoVM.isBatchRunning {
            processingSection
        } else {
            Button { videoVM.start() } label: {
                primaryButton(videoVM.alsoInterpolate ? L.startButtonCombined.text : L.startButton.text)
            }
            .disabled(videoVM.inputURL == nil)
            .opacity(videoVM.inputURL == nil ? 0.45 : 1)
        }

        if videoVM.outputURL != nil { videoResult }
    }

    private func modelSelector(models: [RealESRGAN.Model], selected: RealESRGAN.Model, onSelect: @escaping (RealESRGAN.Model) -> Void) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text(L.modelSectionTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
            }
            HStack(spacing: 7) {
                ForEach(models) { model in
                    Button { onSelect(model) } label: {
                        VStack(spacing: 3) {
                            Text(model.shortName)
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                            HStack(spacing: 3) {
                                Image(systemName: "iphone").font(.system(size: 8, weight: .bold))
                                Text(model.caption)
                                    .font(.system(size: 9, weight: .medium, design: .rounded))
                                    .lineLimit(1)
                            }
                            .opacity(selected == model ? 0.75 : 0.55)
                        }
                        .foregroundStyle(selected == model ? .black : .white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                        .background(selected == model ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.white.opacity(0.055)), in: RoundedRectangle(cornerRadius: 12))
                        .shadow(color: selected == model ? LocalStyle.mint.opacity(0.4) : Color.clear, radius: 9)
                    }
                }
            }
        }
    }

    private var interpolateAlsoToggle: some View {
        VStack(spacing: 10) {
            Toggle(isOn: $videoVM.alsoInterpolate.animation()) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(L.alsoInterpolateTitle.text).font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(.white)
                    Text(L.alsoInterpolateSubtitle.text).font(.caption2).foregroundStyle(.white.opacity(0.45))
                }
            }
            .tint(LocalStyle.mint)
            .disabled(videoVM.isProcessing)

            if videoVM.alsoInterpolate {
                HStack(spacing: 7) {
                    ForEach([2, 4], id: \.self) { value in
                        Button { videoVM.interpolationFactor = value } label: {
                            Text("\(value)×").font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundStyle(videoVM.interpolationFactor == value ? .black : .white)
                                .frame(maxWidth: .infinity).frame(height: 38)
                                .background(videoVM.interpolationFactor == value ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.white.opacity(0.055)), in: RoundedRectangle(cornerRadius: 10))
                        }
                        .disabled(videoVM.isProcessing)
                    }
                    Picker("", selection: $videoVM.interpolationPrecision) {
                        ForEach(RIFEInterpolator.Precision.allCases) { option in
                            Text(option == .fp16 ? L.precisionFast.text : L.precisionHigh.text).tag(option)
                        }
                    }
                    .pickerStyle(.segmented)
                    .disabled(videoVM.isProcessing)
                }
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private var videoPreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let frame = videoVM.liveFrame, videoVM.isProcessing {
                Image(decorative: frame, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
            } else if let input = videoVM.inputURL, let output = videoVM.outputURL {
                VideoCompareView(beforeURL: input, afterURL: output, beforeStart: videoVM.resultTrimStart).id(output)
            } else if let player = inputPlayer {
                VideoPlayer(player: player)
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "film").font(.system(size: 30)).foregroundStyle(.white.opacity(0.3))
                    Text(L.selectVideoPlaceholderTitle.text).font(.headline).foregroundStyle(.white.opacity(0.85))
                    Text(L.selectVideoPlaceholderSubtitle.text).font(.caption).foregroundStyle(.white.opacity(0.35))
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.07)))
    }

    private var processingSection: some View {
        VStack(spacing: 9) {
            ProgressView(value: videoVM.progress).tint(Color(red: 0.25, green: 0.58, blue: 1))
            HStack {
                Text(videoVM.status).lineLimit(1)
                Spacer()
                Text("\(Int(videoVM.progress * 100))%")
            }
            .font(.caption.weight(.medium)).foregroundStyle(.white.opacity(0.55))

            Button { videoVM.cancel() } label: { secondaryButton(L.cancelButton.text, color: Color(red: 0.75, green: 0.08, blue: 0.12)) }
        }
    }

    private var videoResult: some View {
        Group {
            if let output = videoVM.outputURL {
                ResultActionBar(save: { try await PhotoSaver.saveVideo(at: output) },
                                share: ShareLink(item: output) { ShareBarLabel() })
                    .id(output)
            }
        }
    }

    @ViewBuilder
    private func interpolateView(geometry: GeometryProxy) -> some View {
        interpPreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.52, 320))

        if let url = interpVM.inputURL, interpVM.videoDuration > 0 {
            TrimBar(url: url, duration: interpVM.videoDuration, start: $interpVM.trimStart, end: $interpVM.trimEnd,
                    disabled: interpVM.isProcessing || interpVM.isBatchRunning)
        }

        factorSelector

        precisionSelector

        slowMotionToggle

        upscaleAfterToggle

        exportQualitySelector

        PhotosPicker(selection: $selectedInterpVideo, matching: .videos, photoLibrary: .shared()) {
            pickerButton(title: L.selectVideo.text, icon: "video.badge.plus")
        }
        .disabled(interpVM.isProcessing || interpVM.isBatchRunning)

        HStack(spacing: 8) {
            presetsCompactButton(.interpolate, busy: interpVM.isProcessing || interpVM.isBatchRunning)
            batchCompactPicker(selection: $batchInterpItems, maxCount: 20, matching: .videos, busy: interpVM.isProcessing || interpVM.isBatchRunning)
        }

        BatchSummary(isRunning: interpVM.isBatchRunning, index: interpVM.batchIndex, total: interpVM.batchTotal,
                     failures: interpVM.batchFailures, results: interpVM.batchResults)

        if interpVM.isProcessing || interpVM.isBatchRunning {
            interpProcessingSection
        } else {
            Button { interpVM.start() } label: {
                primaryButton(interpVM.alsoUpscale ? L.interpolateButtonCombined.text : "\(L.interpolateButton.text) \(interpVM.factor)×")
            }
            .disabled(interpVM.inputURL == nil)
            .opacity(interpVM.inputURL == nil ? 0.45 : 1)
        }

        if interpVM.outputURL != nil { interpResult }

        if !interpVM.isProcessing && !interpVM.isBatchRunning {
            Text(interpVM.status).font(.caption).foregroundStyle(.white.opacity(0.45)).frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var factorSelector: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(L.interpolateFactorTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
            HStack(spacing: 7) {
                ForEach([2, 4], id: \.self) { value in
                    Button { interpVM.factor = value } label: {
                        VStack(spacing: 2) {
                            Text("\(value)×").font(.system(size: 15, weight: .bold, design: .rounded))
                            HStack(spacing: 3) {
                                if interpVM.factor == value { Image(systemName: "iphone").font(.system(size: 8, weight: .bold)) }
                                Text(value == 2 ? L.interpolateFactorFast.text : L.interpolateFactorSmooth.text).font(.system(size: 9, weight: .medium, design: .rounded))
                            }
                            .opacity(interpVM.factor == value ? 0.75 : 0.55)
                        }
                        .foregroundStyle(interpVM.factor == value ? .black : .white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                        .background(interpVM.factor == value ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.white.opacity(0.055)), in: RoundedRectangle(cornerRadius: 12))
                        .shadow(color: interpVM.factor == value ? LocalStyle.mint.opacity(0.4) : Color.clear, radius: 9)
                    }
                    .disabled(interpVM.isProcessing)
                }
            }
        }
    }

    private var slowMotionToggle: some View {
        Toggle(isOn: $interpVM.slowMotion) {
            VStack(alignment: .leading, spacing: 2) {
                Text(tr("Cámara lenta", "Slow motion")).font(.system(size: 14, weight: .semibold, design: .rounded))
                Text(interpVM.slowMotion
                     ? tr("El video dura ×\(interpVM.factor) más y se omite el audio", "The video lasts ×\(interpVM.factor) longer and audio is dropped")
                     : tr("Mantiene la duración y sube los fps", "Keeps the duration and raises the fps"))
                    .font(.caption2).foregroundStyle(.white.opacity(0.45))
            }
        }
        .tint(LocalStyle.mint)
        .disabled(interpVM.isProcessing || interpVM.isBatchRunning)
        .padding(12)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private var exportQualitySelector: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(tr("CALIDAD DE EXPORTACIÓN", "EXPORT QUALITY"))
                    .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
                Text(interpVM.exportQuality.caption)
                    .font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.8))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
            Picker("", selection: $interpVM.exportQuality) {
                ForEach(ExportQuality.allCases) { option in
                    Text(option.label).tag(option)
                }
            }
            .pickerStyle(.menu)
            .tint(LocalStyle.mint)
            .disabled(interpVM.isProcessing || interpVM.isBatchRunning)
        }
        .padding(12)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private var precisionSelector: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(L.precisionTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
                Text(interpVM.precision.caption.isEmpty ? interpVM.precision.displayName : interpVM.precision.displayName + " · " + interpVM.precision.caption)
                    .font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.8))
            }
            Spacer()
            Picker("", selection: $interpVM.precision) {
                ForEach(RIFEInterpolator.Precision.allCases) { option in
                    Text(option == .fp16 ? L.precisionFast.text : L.precisionHigh.text).tag(option)
                }
            }
            .pickerStyle(.segmented)
            .frame(width: 150)
            .disabled(interpVM.isProcessing)
        }
        .padding(12)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private var upscaleAfterToggle: some View {
        VStack(spacing: 10) {
            Toggle(isOn: $interpVM.alsoUpscale.animation()) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(L.alsoUpscaleTitle.text).font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(.white)
                    Text(L.alsoUpscaleSubtitle.text).font(.caption2).foregroundStyle(.white.opacity(0.45))
                }
            }
            .tint(LocalStyle.mint)
            .disabled(interpVM.isProcessing)

            if interpVM.alsoUpscale {
                modelSelector(models: RealESRGAN.Model.videoModels, selected: interpVM.selectedUpscaleModel) { interpVM.selectedUpscaleModel = $0 }
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private var interpPreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let frame = interpVM.liveFrame, interpVM.isProcessing {
                Image(decorative: frame, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
            } else if let input = interpVM.inputURL, let output = interpVM.outputURL {
                VideoCompareView(beforeURL: input, afterURL: output, beforeStart: interpVM.resultTrimStart).id(output)
            } else if let player = interpInputPlayer {
                VideoPlayer(player: player)
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "timelapse").font(.system(size: 30)).foregroundStyle(.white.opacity(0.3))
                    Text(L.interpolatePlaceholderTitle.text).font(.headline).foregroundStyle(.white.opacity(0.85))
                    Text(L.interpolatePlaceholderSubtitle.text).font(.caption).foregroundStyle(.white.opacity(0.35))
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.07)))
    }

    private var interpProcessingSection: some View {
        VStack(spacing: 9) {
            ProgressView(value: interpVM.progress).tint(Color(red: 0.25, green: 0.58, blue: 1))
            HStack {
                Text(interpVM.status).lineLimit(1)
                Spacer()
                Text("\(Int(interpVM.progress * 100))%")
            }
            .font(.caption.weight(.medium)).foregroundStyle(.white.opacity(0.55))

            Button { interpVM.cancel() } label: { secondaryButton(L.cancelButton.text, color: Color(red: 0.75, green: 0.08, blue: 0.12)) }
        }
    }

    private var interpResult: some View {
        Group {
            if let output = interpVM.outputURL {
                ResultActionBar(save: { try await PhotoSaver.saveVideo(at: output) },
                                share: ShareLink(item: output) { ShareBarLabel() })
                    .id(output)
            }
        }
    }

    @ViewBuilder
    private func imageView(geometry: GeometryProxy) -> some View {
        imagePreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.52, 320))

        modelSelector(models: RealESRGAN.Model.imageModels, selected: imageVM.selectedModel) { imageVM.selectedModel = $0 }

        PhotosPicker(selection: $selectedImage, matching: .images, photoLibrary: .shared()) {
            pickerButton(title: L.selectImage.text, icon: "photo.badge.plus")
        }
        .disabled(imageVM.isBusy)

        HStack(spacing: 8) {
            presetsCompactButton(.image, busy: imageVM.isBusy)
            batchCompactPicker(selection: $batchImageItems, maxCount: 50, matching: .images, busy: imageVM.isBusy)
        }

        BatchSummary(isRunning: imageVM.isBatchRunning, index: imageVM.batchIndex, total: imageVM.batchTotal,
                     failures: imageVM.batchFailures, results: imageVM.batchResults)

        if imageVM.isBatchRunning {
            Button { imageVM.cancelBatch() } label: {
                secondaryButton(tr("Cancelar lote", "Cancel batch"), color: Color.red.opacity(0.35), icon: "xmark")
            }
        }

        Button { imageVM.start() } label: { primaryButton(tr("Mejorar imagen", "Enhance image")) }
            .disabled(imageVM.inputImage == nil || imageVM.isBusy)
            .opacity(imageVM.inputImage == nil || imageVM.isBusy ? 0.45 : 1)

        if imageVM.needsLargeConfirmation && !imageVM.isProcessing {
            Button { imageVM.start(force: true) } label: {
                secondaryButton(L.tryAnyway.text, color: Color.orange.opacity(0.35), icon: "exclamationmark.triangle")
            }
        }

        if let output = imageVM.outputImage {
            ResultActionBar(
                save: { try await PhotoSaver.saveImage(output) },
                share: ShareLink(item: ShareableImage(image: output), preview: SharePreview("Astral", image: Image(decorative: output, scale: 1))) { ShareBarLabel() }
            )
            .id(ObjectIdentifier(output))
        } else if imageVM.isProcessing {
            ProgressView().tint(.white)
        }

        if !imageVM.isBusy {
            Text(imageVM.status).font(.caption).foregroundStyle(.white.opacity(0.45)).frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var imagePreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let output = imageVM.outputImage, let before = imageVM.inputImage {
                ImageComparisonView(before: before, after: output)
            } else if let image = imageVM.inputImage {
                Image(decorative: image, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
            } else {
                Image(systemName: "photo").font(.system(size: 34)).foregroundStyle(.white.opacity(0.25))
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.07)))
    }

    @ViewBuilder
    private func colorView(geometry: GeometryProxy) -> some View {
        colorPreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.46, 300))

        PhotosPicker(selection: $selectedColorItem, matching: .any(of: [.images, .videos]), photoLibrary: .shared()) {
            pickerButton(title: tr("Elegir foto o video", "Choose photo or video"), icon: "photo.on.rectangle")
        }
        .disabled(colorVM.isExporting)

        if colorVM.hasMedia {
            colorLooksRow
            colorSlidersCard

            if colorVM.media == .video {
                if colorVM.isExporting {
                    VStack(alignment: .leading, spacing: 8) {
                        ProgressView(value: colorVM.progress).tint(LocalStyle.mint)
                        Text(tr("Exportando…", "Exporting…") + " \(Int(colorVM.progress * 100))%")
                            .font(.caption).foregroundStyle(.white.opacity(0.6))
                    }
                } else {
                    Button { colorVM.exportVideo() } label: { primaryButton(tr("Exportar video", "Export video")) }
                        .disabled(colorVM.settings.isNeutral)
                        .opacity(colorVM.settings.isNeutral ? 0.45 : 1)
                }
                if let output = colorVM.outputURL, !colorVM.isExporting {
                    ResultActionBar(save: { try await PhotoSaver.saveVideo(at: output) },
                                    share: ShareLink(item: output) { ShareBarLabel() })
                        .id(output)
                }
            } else if colorVM.media == .image, !colorVM.settings.isNeutral, let source = colorVM.sourceImage {
                ResultActionBar(
                    save: { try await PhotoSaver.saveImage(try await colorVM.renderedImage()) },
                    share: ShareLink(item: ShareableAdjustedImage(source: source, settings: colorVM.settings),
                                     preview: SharePreview("Astral", image: Image(decorative: source, scale: 1))) { ShareBarLabel() }
                )
            }
        }

        if !colorVM.isExporting {
            Text(colorVM.status).font(.caption).foregroundStyle(.white.opacity(0.45)).frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var colorPreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            switch colorVM.media {
            case .image:
                if let image = colorVM.previewImage {
                    Image(decorative: image, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
                }
            case .video:
                if let player = colorVM.player {
                    PlayerLayerView(player: player)
                        .contentShape(Rectangle())
                        .onTapGesture { colorVM.togglePlay() }
                    if !colorVM.isPlaying {
                        Image(systemName: "play.fill")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 58, height: 58)
                            .background(.black.opacity(0.45), in: Circle())
                            .allowsHitTesting(false)
                    }
                }
            case .none:
                VStack(spacing: 8) {
                    Image(systemName: "slider.horizontal.below.rectangle").font(.system(size: 34)).foregroundStyle(.white.opacity(0.25))
                    Text(tr("Ajuste de color", "Color adjustment")).font(.callout.weight(.semibold)).foregroundStyle(.white.opacity(0.4))
                }
            }

            if colorVM.hasMedia {
                VStack {
                    HStack {
                        Spacer()
                        Text(tr("Mantén para ver el original", "Hold to see the original"))
                            .font(.system(size: 10, weight: .bold, design: .rounded))
                            .foregroundStyle(colorVM.showOriginal ? .black : .white)
                            .padding(.horizontal, 10).padding(.vertical, 6)
                            .background(colorVM.showOriginal ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.black.opacity(0.55)), in: Capsule())
                            .onLongPressGesture(minimumDuration: 0.01, maximumDistance: 60, pressing: { pressing in
                                colorVM.showOriginal = pressing
                            }, perform: {})
                    }
                    .padding(10)
                    Spacer()
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.07)))
    }

    private var colorLooksRow: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(tr("ESTILOS", "LOOKS"))
                .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 7) {
                    ForEach(ColorLook.allCases) { look in
                        let selected = colorVM.settings == look.settings
                        Button { colorVM.applyLook(look) } label: {
                            Text(look.title)
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundStyle(selected ? .black : .white)
                                .padding(.horizontal, 14).frame(height: 38)
                                .background(selected ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.white.opacity(0.055)), in: RoundedRectangle(cornerRadius: 11))
                        }
                    }
                }
            }
        }
        .disabled(colorVM.isExporting)
    }

    private var colorSlidersCard: some View {
        VStack(spacing: 12) {
            HStack {
                Text(tr("AJUSTES", "ADJUSTMENTS"))
                    .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
                Spacer()
                Button(tr("Restablecer", "Reset")) { colorVM.reset() }
                    .font(.caption.weight(.semibold)).foregroundStyle(LocalStyle.mint)
                    .disabled(colorVM.settings.isNeutral)
                    .opacity(colorVM.settings.isNeutral ? 0.4 : 1)
            }
            colorSlider(tr("Exposición", "Exposure"), $colorVM.settings.exposure, -2...2, neutral: 0)
            colorSlider(tr("Brillo", "Brightness"), $colorVM.settings.brightness, -0.3...0.3, neutral: 0)
            colorSlider(tr("Contraste", "Contrast"), $colorVM.settings.contrast, 0.6...1.6, neutral: 1)
            colorSlider(tr("Saturación", "Saturation"), $colorVM.settings.saturation, 0...2, neutral: 1)
            colorSlider(tr("Intensidad", "Vibrance"), $colorVM.settings.vibrance, -1...1, neutral: 0)
            colorSlider(tr("Temperatura", "Temperature"), $colorVM.settings.temperature, -1...1, neutral: 0)
            colorSlider(tr("Matiz", "Tint"), $colorVM.settings.tint, -1...1, neutral: 0)
            colorSlider(tr("Luces altas", "Highlights"), $colorVM.settings.highlights, 0...1, neutral: 0)
            colorSlider(tr("Sombras", "Shadows"), $colorVM.settings.shadows, 0...1, neutral: 0)
            colorSlider(tr("Reducir ruido", "Noise reduction"), $colorVM.settings.denoise, 0...1, neutral: 0)
            colorSlider(tr("Nitidez", "Sharpness"), $colorVM.settings.sharpness, 0...1.5, neutral: 0)
            colorSlider(tr("Viñeta", "Vignette"), $colorVM.settings.vignette, 0...1, neutral: 0)
        }
        .padding(12)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
        .disabled(colorVM.isExporting)
    }

    private func colorSlider(_ title: String, _ value: Binding<Double>, _ range: ClosedRange<Double>, neutral: Double) -> some View {
        VStack(spacing: 3) {
            HStack {
                Text(title).font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.85))
                Spacer()
                Text(String(format: "%+.2f", value.wrappedValue - neutral))
                    .font(.system(size: 11, weight: .medium, design: .rounded)).monospacedDigit()
                    .foregroundStyle(value.wrappedValue == neutral ? .white.opacity(0.35) : LocalStyle.mint)
            }
            Slider(value: value, in: range).tint(LocalStyle.mint)
        }
    }

    @ViewBuilder
    private func backgroundView(geometry: GeometryProxy) -> some View {
        backgroundPreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.52, 320))

        PhotosPicker(selection: $selectedBackgroundImage, matching: .images, photoLibrary: .shared()) {
            pickerButton(title: L.selectImage.text, icon: "photo.badge.plus")
        }
        .disabled(backgroundVM.isBusy)

        HStack(spacing: 8) {
            batchCompactPicker(selection: $batchBackgroundItems, maxCount: 50, matching: .images, busy: backgroundVM.isBusy)
        }

        BatchSummary(isRunning: backgroundVM.isBatchRunning, index: backgroundVM.batchIndex, total: backgroundVM.batchTotal,
                     failures: backgroundVM.batchFailures, results: backgroundVM.batchResults)

        if backgroundVM.isBatchRunning {
            Button { backgroundVM.cancelBatch() } label: {
                secondaryButton(tr("Cancelar lote", "Cancel batch"), color: Color.red.opacity(0.35), icon: "xmark")
            }
        }

        Button { backgroundVM.start() } label: { primaryButton(tr("Quitar fondo", "Remove background")) }
            .disabled(backgroundVM.inputImage == nil || backgroundVM.isBusy)
            .opacity(backgroundVM.inputImage == nil || backgroundVM.isBusy ? 0.45 : 1)

        if let output = backgroundVM.outputImage {
            ResultActionBar(
                save: { try await PhotoSaver.saveImage(output) },
                share: ShareLink(item: ShareableImage(image: output), preview: SharePreview("Astral", image: Image(decorative: output, scale: 1))) { ShareBarLabel() }
            )
            .id(ObjectIdentifier(output))
        } else if backgroundVM.isProcessing {
            ProgressView().tint(.white)
        }

        if !backgroundVM.isBusy {
            Text(backgroundVM.status).font(.caption).foregroundStyle(.white.opacity(0.45)).frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var backgroundPreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let output = backgroundVM.outputImage, let before = backgroundVM.inputImage {
                ImageComparisonView(before: before, after: output)
            } else if let image = backgroundVM.inputImage {
                Image(decorative: image, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
            } else {
                Image(systemName: "person.crop.rectangle").font(.system(size: 34)).foregroundStyle(.white.opacity(0.25))
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.07)))
    }

    private func presetsCompactButton(_ kind: Preset.Kind, busy: Bool) -> some View {
        Button { presetsKind = kind } label: {
            compactAction("Presets", icon: "slider.horizontal.3")
        }
        .disabled(busy)
        .opacity(busy ? 0.45 : 1)
    }

    private func batchCompactPicker(selection: Binding<[PhotosPickerItem]>, maxCount: Int, matching: PHPickerFilter, busy: Bool) -> some View {
        PhotosPicker(selection: selection, maxSelectionCount: maxCount, matching: matching, photoLibrary: .shared()) {
            compactAction(tr("Procesar por lotes", "Batch process"), icon: "square.stack.3d.up")
        }
        .disabled(busy)
        .opacity(busy ? 0.45 : 1)
    }

    private func compactAction(_ title: String, icon: String) -> some View {
        VStack(spacing: 5) {
            Image(systemName: icon).font(.system(size: 17, weight: .semibold))
            Text(title)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .lineLimit(1).minimumScaleFactor(0.8)
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity)
        .frame(height: 56)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private func pickerButton(title: String, icon: String) -> some View {
        HStack {
            Image(systemName: icon)
            Text(title).fontWeight(.semibold)
            Spacer()
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).opacity(0.4)
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity).frame(height: 46).padding(.horizontal, 16)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private func primaryButton(_ title: String) -> some View {
        Text(title).font(.headline.weight(.bold)).foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 50).background(Color(red: 0.12, green: 0.47, blue: 1), in: RoundedRectangle(cornerRadius: 13))
    }

    private func secondaryButton(_ title: String, color: Color, icon: String? = nil) -> some View {
        HStack(spacing: 8) {
            if let icon { Image(systemName: icon) }
            Text(title).font(.subheadline.weight(.semibold))
        }
        .foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 48).background(color, in: RoundedRectangle(cornerRadius: 13))
    }
}

struct NeonBackground: View {
    @State private var animate = false

    var body: some View {
        ZStack {
            Color(red: 0.02, green: 0.03, blue: 0.04)
            GeometryReader { proxy in
                let w = proxy.size.width
                let h = proxy.size.height
                ZStack {
                    Circle().fill(Color(red: 0.35, green: 1.0, blue: 0.25))
                        .frame(width: w * 0.9, height: w * 0.9)
                        .offset(x: animate ? -w * 0.30 : -w * 0.05, y: animate ? -h * 0.30 : -h * 0.18)
                    Circle().fill(Color(red: 0.0, green: 0.85, blue: 1.0))
                        .frame(width: w * 0.8, height: w * 0.8)
                        .offset(x: animate ? w * 0.35 : w * 0.15, y: animate ? h * 0.05 : h * 0.20)
                    Circle().fill(Color(red: 0.75, green: 0.2, blue: 1.0))
                        .frame(width: w * 0.85, height: w * 0.85)
                        .offset(x: animate ? -w * 0.10 : -w * 0.30, y: animate ? h * 0.38 : h * 0.28)
                }
                .frame(width: w, height: h)
                .blur(radius: 90)
                .opacity(0.38)
            }
            Color.black.opacity(0.35)
        }
        .allowsHitTesting(false)
        .onAppear {
            withAnimation(.easeInOut(duration: 9).repeatForever(autoreverses: true)) { animate = true }
        }
    }
}

enum LocalStyle {
    static let mint = Color(red: 0.35, green: 0.95, blue: 0.68)
    static let cyan = Color(red: 0.20, green: 0.85, blue: 1.0)
    static var gradient: LinearGradient {
        LinearGradient(colors: [mint, cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}
