import SwiftUI
import AVFoundation
import AVKit
import PhotosUI
import UniformTypeIdentifiers

struct ContentView: View {
    enum Tab: String { case enhance = "MEJORA", image = "IMAGEN", background = "FONDO", color = "COLOR" }

    private func title(for tab: Tab) -> String {
        switch tab {
        case .enhance: return tr("MEJORA DE VIDEO", "VIDEO ENHANCE")
        case .image: return L.tabImage.text
        case .background: return L.tabBackground.text
        case .color: return L.tabColor.text
        }
    }

    @ObservedObject private var languageStore = AppLanguageStore.shared
    @ObservedObject private var themeStore = ThemeStore.shared
    @StateObject private var enhanceVM = EnhanceViewModel()
    @StateObject private var imageVM = ImageViewModel()
    @StateObject private var enhanceTrimSync = TrimPlaybackSync()
    @StateObject private var backgroundVM = BackgroundViewModel()
    @StateObject private var colorVM = ColorViewModel()
    @State private var tab: Tab = .enhance
    @State private var selectedVideo: PhotosPickerItem?
    @State private var selectedImage: PhotosPickerItem?
    @State private var enhancePlayer: AVPlayer?
    @State private var showSettings = false
    @State private var showPresets = false
    @State private var showMoreTools = false
    @State private var showEnhanceAdvanced = false
    @State private var showColorAdvanced = false
    @State private var batchEnhanceItems: [PhotosPickerItem] = []
    @State private var batchImageItems: [PhotosPickerItem] = []
    @State private var selectedBackgroundImage: PhotosPickerItem?
    @State private var selectedColorItem: PhotosPickerItem?
    @State private var batchBackgroundItems: [PhotosPickerItem] = []

    var body: some View {
        withSheets(withTrimHandlers(withChangeHandlersB(withChangeHandlersA(mainContent.id(themeStore.theme)))))
    }

    private var mainContent: some View {
        GeometryReader { geometry in
            ZStack {
                NeonBackground().ignoresSafeArea()

                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 14) {
                        tabs
                        switch tab {
                        case .enhance: enhanceView(geometry: geometry)
                        case .image: imageView(geometry: geometry)
                        case .background: backgroundView(geometry: geometry)
                        case .color: colorView(geometry: geometry)
                        }
                        Spacer(minLength: 0)
                    }
                    .frame(maxWidth: .infinity, minHeight: geometry.size.height, alignment: .top)
                    .padding(.horizontal, 8)
                    .padding(.top, 8)
                    .padding(.bottom, 28)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .preferredColorScheme(themeStore.theme.palette.scheme)
    }

    private func withChangeHandlersA<V: View>(_ view: V) -> some View {
        view
        .onChange(of: languageStore.language) { _, _ in
            enhanceVM.relocalizeIdleStatus(); imageVM.relocalizeIdleStatus(); backgroundVM.relocalizeIdleStatus(); colorVM.relocalizeIdleStatus()
        }
        .onChange(of: batchEnhanceItems) { _, items in
            guard !items.isEmpty else { return }
            enhanceVM.startBatch(items)
            batchEnhanceItems = []
        }
        .onChange(of: selectedColorItem) { _, item in
            guard let item else { return }
            Task { await colorVM.importItem(item); selectedColorItem = nil }
        }
        .onChange(of: selectedBackgroundImage) { _, item in
            guard let item else { return }
            Task { await backgroundVM.importImage(from: item); selectedBackgroundImage = nil }
        }
        .onChange(of: batchBackgroundItems) { _, items in
            guard !items.isEmpty else { return }
            backgroundVM.startBatch(items)
            batchBackgroundItems = []
        }
        .onChange(of: batchImageItems) { _, items in
            guard !items.isEmpty else { return }
            imageVM.startBatch(items)
            batchImageItems = []
        }
    }

    private func withChangeHandlersB<V: View>(_ view: V) -> some View {
        view
        .onChange(of: selectedVideo) { _, item in
            guard let item else { return }
            Task { await enhanceVM.importVideo(from: item); selectedVideo = nil }
        }
        .onChange(of: selectedImage) { _, item in
            guard let item else { return }
            Task { await imageVM.importImage(from: item); selectedImage = nil }
        }
        .onChange(of: enhanceVM.inputURL) { _, url in
            enhancePlayer?.pause()
            enhancePlayer = url.map(AVPlayer.init)
            enhancePlayer?.isMuted = true
            enhanceTrimSync.attach(enhancePlayer)
        }
    }

    /// La vista previa sigue al recorte: al mover una manija se ve ese frame y al reproducir solo se ve lo seleccionado.
    private func withTrimHandlers<V: View>(_ view: V) -> some View {
        view
        .onChange(of: enhanceVM.trimStart) { _, _ in
            enhanceTrimSync.update(start: enhanceVM.trimStart, end: enhanceVM.trimEnd, duration: enhanceVM.videoDuration)
        }
        .onChange(of: enhanceVM.trimEnd) { _, _ in
            enhanceTrimSync.update(start: enhanceVM.trimStart, end: enhanceVM.trimEnd, duration: enhanceVM.videoDuration)
        }
    }

    private func withSheets<V: View>(_ view: V) -> some View {
        view
        .sheet(isPresented: $showPresets) {
            PresetsSheet(current: { makeCurrentPreset(name: $0) }, apply: { applyPreset($0) })
        }
        .sheet(isPresented: $showSettings) {
            SettingsView(keepURLs: urlsToKeep, isBusy: anythingBusy)
        }
        .sheet(isPresented: $showMoreTools) {
            MoreToolsSheet(items: moreToolItems, current: tab) { tab = $0 }
        }
    }

    /// Un preset guarda la configuración de todas las pestañas.
    private func makeCurrentPreset(name: String) -> Preset {
        Preset(name: name,
               enhance: enhanceVM.makeSection(),
               image: ImageSection(modelRaw: imageVM.selectedModel.rawValue),
               color: colorVM.settings)
    }

    private func applyPreset(_ preset: Preset) {
        guard !anythingBusy else { return }
        if let section = preset.enhance { enhanceVM.apply(section) }
        if let image = preset.image,
           let model = RealESRGAN.Model(rawValue: image.modelRaw),
           RealESRGAN.Model.imageModels.contains(model) {
            imageVM.selectedModel = model
        }
        if let color = preset.color { colorVM.settings = color }
    }

    private var urlsToKeep: [URL] {
        var urls: [URL] = []
        urls += [enhanceVM.inputURL, enhanceVM.outputURL].compactMap { $0 }
        urls += enhanceVM.batchResults
        urls += imageVM.batchResults
        urls += backgroundVM.batchResults
        if let colorURL = colorVM.outputURL { urls.append(colorURL) }
        return urls
    }

    private var anythingBusy: Bool {
        let enhance: Bool = enhanceVM.isProcessing || enhanceVM.isBatchRunning
        let image: Bool = imageVM.isBusy
        let background: Bool = backgroundVM.isBusy
        let color: Bool = colorVM.isExporting
        return enhance || image || background || color
    }

    private var tabs: some View {
        VStack(spacing: 6) {
            HStack(spacing: 6) {
                HStack(spacing: 6) {
                    Circle().fill(LocalStyle.mint).frame(width: 7, height: 7)
                    Text(L.onDevice.text).font(.system(size: 9, weight: .bold, design: .rounded)).tracking(0.8)
                }
                .foregroundStyle(LocalStyle.mint)
                Spacer()
                headerCircleButton(icon: "slider.horizontal.3", disabled: anythingBusy) { showPresets = true }
                headerCircleButton(icon: "gearshape.fill", disabled: false) { showSettings = true }
            }
            HStack(spacing: 4) {
                tabButton(.enhance, height: 44, icon: "wand.and.stars", fontSize: 13)
                moreToolsButton
            }
        }
        .padding(4)
        .background(Theme.fill(0.045), in: RoundedRectangle(cornerRadius: 13))
    }

    private var moreToolItems: [MoreToolsSheet.Item] {
        let tools: [Tab] = [.image, .background, .color]
        return tools.map { MoreToolsSheet.Item(tab: $0, icon: toolIcon($0), title: toolTitle($0), detail: toolDetail($0)) }
    }

    private func toolIcon(_ tab: Tab) -> String {
        switch tab {
        case .enhance: return "wand.and.stars"
        case .image: return "photo"
        case .background: return "person.crop.rectangle"
        case .color: return "slider.horizontal.below.rectangle"
        }
    }

    private func toolTitle(_ tab: Tab) -> String {
        switch tab {
        case .enhance: return tr("Mejora de video", "Video enhance")
        case .image: return tr("Mejorar imagen", "Enhance image")
        case .background: return tr("Eliminar fondo", "Remove background")
        case .color: return tr("Ajustar color", "Adjust color")
        }
    }

    private func toolDetail(_ tab: Tab) -> String {
        switch tab {
        case .enhance: return tr("Más calidad y más fps en tus videos", "More quality and more fps in your videos")
        case .image: return tr("Amplía y mejora fotos hasta 4×", "Upscale and sharpen photos up to 4×")
        case .background: return tr("Deja solo al sujeto, con fondo transparente", "Keep only the subject, on a transparent background")
        case .color: return tr("Estilos y ajustes para fotos y videos", "Looks and adjustments for photos and videos")
        }
    }

    /// Segundo botón de la barra: abre la lista de herramientas. Si hay una activa, muestra su nombre.
    private var moreToolsButton: some View {
        let active = tab != .enhance
        return Button { showMoreTools = true } label: {
            HStack(spacing: 6) {
                Image(systemName: active ? toolIcon(tab) : "square.grid.2x2").font(.system(size: 13, weight: .bold))
                Text(active ? toolTitle(tab).uppercased() : tr("MÁS HERRAMIENTAS", "MORE TOOLS"))
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .tracking(0.5)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.7)
                    .lineLimit(2)
                Image(systemName: "chevron.down").font(.system(size: 10, weight: .bold)).opacity(0.7)
            }
            .foregroundStyle(active ? Theme.onAccent : Theme.ink().opacity(0.55))
            .frame(height: 44)
            .frame(maxWidth: .infinity)
            .background(active ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.clear), in: RoundedRectangle(cornerRadius: 10))
            .shadow(color: active ? LocalStyle.mint.opacity(0.45) : Color.clear, radius: 10)
        }
    }

    private func headerCircleButton(icon: String, disabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(LocalStyle.mint)
                .frame(width: 30, height: 30)
                .background(Theme.fill(0.055), in: Circle())
                .overlay(Circle().stroke(LocalStyle.mint.opacity(0.35), lineWidth: 1))
        }
        .disabled(disabled)
        .opacity(disabled ? 0.45 : 1)
    }

    private func tabButton(_ value: Tab, height: CGFloat = 38, icon: String? = nil, fontSize: CGFloat = 11) -> some View {
        Button { tab = value } label: {
            HStack(spacing: 6) {
                if let icon { Image(systemName: icon).font(.system(size: fontSize, weight: .bold)) }
                Text(title(for: value))
                    .font(.system(size: fontSize, weight: .bold, design: .rounded))
                    .tracking(0.5)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.7)
                    .lineLimit(2)
            }
            .foregroundStyle(tab == value ? Theme.onAccent : Theme.ink().opacity(0.55))
            .frame(height: height)
            .frame(maxWidth: .infinity)
            .background(tab == value ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.clear), in: RoundedRectangle(cornerRadius: 10))
            .shadow(color: tab == value ? LocalStyle.mint.opacity(0.45) : Color.clear, radius: 10)
        }
    }

    /// Los modelos se reparten en dos filas: la primera con `topRowCount` botones y el resto debajo.
    /// Todos los botones de una pestaña comparten el mismo ancho (la fila de abajo deja huecos vacíos si hace falta).
    private func modelSelector(models: [RealESRGAN.Model], topRowCount: Int = 2, selected: RealESRGAN.Model, onSelect: @escaping (RealESRGAN.Model) -> Void) -> some View {
        let topRow = Array(models.prefix(topRowCount))
        let bottomRow = Array(models.dropFirst(topRowCount))
        return VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text(L.modelSectionTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
            }
            VStack(spacing: 7) {
                modelRow(topRow, slots: topRowCount, selected: selected, onSelect: onSelect)
                if !bottomRow.isEmpty {
                    modelRow(bottomRow, slots: topRowCount, selected: selected, onSelect: onSelect)
                }
            }
            if models.contains(selected) {
                Text(selected.speedTag + " " + selected.blurb)
                    .font(.caption2)
                    .foregroundStyle(Theme.ink(0.45))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private func modelRow(_ row: [RealESRGAN.Model], slots: Int, selected: RealESRGAN.Model, onSelect: @escaping (RealESRGAN.Model) -> Void) -> some View {
        HStack(spacing: 7) {
            ForEach(row) { model in
                Button { onSelect(model) } label: {
                    VStack(spacing: 3) {
                        Text(model.shortName)
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        HStack(spacing: 3) {
                            Image(systemName: "iphone").font(.system(size: 8, weight: .bold))
                            Text(model.caption)
                                .font(.system(size: 9, weight: .medium, design: .rounded))
                                .lineLimit(1)
                        }
                        .opacity(selected == model ? 0.75 : 0.55)
                    }
                    .foregroundStyle(selected == model ? Theme.onAccent : Theme.ink())
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(selected == model ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Theme.fill(0.055)), in: RoundedRectangle(cornerRadius: 12))
                    .shadow(color: selected == model ? LocalStyle.mint.opacity(0.4) : Color.clear, radius: 9)
                }
            }
            ForEach(0..<max(slots - row.count, 0), id: \.self) { _ in
                Color.clear.frame(maxWidth: .infinity).frame(height: 52)
            }
        }
    }

    // MARK: - Mejora de video

    @ViewBuilder
    private func enhanceView(geometry: GeometryProxy) -> some View {
        let busy = enhanceVM.isProcessing || enhanceVM.isBatchRunning
        // Resultado listo: solo quedan la preview, Guardar/Compartir y el selector para elegir otro video.
        let showingResult = enhanceVM.outputURL != nil && !busy

        enhancePreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.52, 320))

        if showingResult {
            enhanceResult
        } else {
            if let url = enhanceVM.inputURL, enhanceVM.videoDuration > 0 {
                TrimBar(url: url, duration: enhanceVM.videoDuration, start: $enhanceVM.trimStart, end: $enhanceVM.trimEnd,
                        disabled: busy)
            }

            enhanceModeMenu(busy: busy)

            // Hasta que no elija qué hacer, no se muestra ninguna opción.
            if enhanceVM.doUpscale {
                upscaleOptionsCard(busy: busy)
            }
            if enhanceVM.doInterpolate {
                fpsOptionsCard(busy: busy)
            }
            if enhanceVM.mode != nil {
                enhanceAdvancedCard(busy: busy)
            }
        }

        HStack(spacing: 8) {
            PhotosPicker(selection: $selectedVideo, matching: .videos, photoLibrary: .shared()) {
                pickerButton(title: L.selectVideo.text, icon: "video.badge.plus")
            }
            .disabled(busy)
            if !showingResult {
                batchCompactPicker(selection: $batchEnhanceItems, maxCount: 20, matching: .videos, busy: busy)
            }
        }

        if !showingResult {
            BatchSummary(isRunning: enhanceVM.isBatchRunning, index: enhanceVM.batchIndex, total: enhanceVM.batchTotal,
                         failures: enhanceVM.batchFailures, results: enhanceVM.batchResults)

            if busy {
                enhanceProcessingSection
            } else {
                Button { enhanceVM.start() } label: {
                    startButtonLabel(title: enhanceStartTitle, subtitle: enhanceVM.resultSummary)
                }
                .disabled(!enhanceCanStart)
                .opacity(enhanceCanStart ? 1 : 0.45)

                Text(enhanceVM.status).font(.caption).foregroundStyle(Theme.ink(0.45)).frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var enhanceCanStart: Bool {
        enhanceVM.inputURL != nil && enhanceVM.mode != nil && !enhanceVM.isTooLarge
    }

    private var enhanceStartTitle: String {
        switch enhanceVM.mode {
        case .none: return tr("Elige qué hacer", "Choose what to do")
        case .some(.both): return tr("Mejorar + aumentar fps", "Enhance + raise fps")
        case .some(.quality): return tr("Mejorar calidad", "Improve quality")
        case .some(.fps): return tr("Aumentar fps", "Raise fps") + " \(enhanceVM.factor)×"
        }
    }

    /// Botón principal con la línea "Resultado: …" pegada debajo del título: se ve justo donde se decide empezar
    /// y no ocupa una fila extra.
    private func startButtonLabel(title: String, subtitle: String?) -> some View {
        VStack(spacing: 2) {
            Text(title).font(.headline.weight(.bold))
            if let subtitle {
                Text(subtitle)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                    .opacity(0.88)
            }
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity)
        .frame(height: subtitle == nil ? 50 : 58)
        .background(Color(red: 0.12, green: 0.47, blue: 1), in: RoundedRectangle(cornerRadius: 13))
    }

    /// Un solo botón de ancho completo con menú desplegable (flecha a la derecha).
    /// Al entrar no hay nada elegido: primero se escoge qué hacer y solo entonces aparecen las opciones.
    private func enhanceModeMenu(busy: Bool) -> some View {
        let current = enhanceVM.mode
        let isOn = current != nil
        let shown = current ?? .quality   // por defecto se ve "Mejorar calidad", pero sin elegir
        // Con una opción elegida el botón solo muestra su nombre; la ayuda aparece únicamente mientras no hay nada elegido.
        let hint: String? = current == nil ? tr("Toca para elegir qué hacer", "Tap to choose what to do") : nil
        return Menu {
            ForEach(EnhanceMode.allCases) { option in
                Button {
                    withAnimation { enhanceVM.mode = option }
                } label: {
                    Label(option.title, systemImage: current == option ? "checkmark" : option.icon)
                }
            }
        } label: {
            HStack(spacing: 10) {
                Image(systemName: shown.icon).font(.system(size: 16, weight: .bold))
                VStack(alignment: .leading, spacing: 3) {
                    Text(shown.title)
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.65)
                    if let hint {
                        Text(hint)
                            .font(.system(size: 10, weight: .medium, design: .rounded))
                            .lineLimit(1)
                            .opacity(0.55)
                    }
                }
                Spacer(minLength: 8)
                Image(systemName: "chevron.down").font(.system(size: 13, weight: .bold))
            }
            .foregroundStyle(isOn ? Theme.onAccent : Theme.ink())
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .background(isOn ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Theme.fill(0.055)), in: RoundedRectangle(cornerRadius: 12))
            .shadow(color: isOn ? LocalStyle.mint.opacity(0.4) : Color.clear, radius: 9)
        }
        .menuOrder(.fixed)
        .disabled(busy)
    }

    /// Opciones de "Mejorar calidad": el modelo.
    private func upscaleOptionsCard(busy: Bool) -> some View {
        modelSelector(models: RealESRGAN.Model.videoModels, selected: enhanceVM.selectedModel) { enhanceVM.selectedModel = $0 }
            .padding(12)
            .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 13))
            .disabled(busy)
    }

    /// Opciones de "Aumentar fps": factor, precisión y cámara lenta.
    private func fpsOptionsCard(busy: Bool) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 9) {
                Text(L.interpolateFactorTitle.text)
                    .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
                HStack(spacing: 7) {
                    ForEach([2, 4], id: \.self) { value in
                        Button { enhanceVM.factor = value } label: {
                            VStack(spacing: 2) {
                                Text("\(value)×").font(.system(size: 15, weight: .bold, design: .rounded))
                                HStack(spacing: 3) {
                                    if enhanceVM.factor == value { Image(systemName: "iphone").font(.system(size: 8, weight: .bold)) }
                                    Text(value == 2 ? L.interpolateFactorFast.text : L.interpolateFactorSmooth.text)
                                        .font(.system(size: 9, weight: .medium, design: .rounded))
                                }
                                .opacity(enhanceVM.factor == value ? 0.75 : 0.55)
                            }
                            .foregroundStyle(enhanceVM.factor == value ? Theme.onAccent : Theme.ink())
                            .frame(maxWidth: .infinity)
                            .frame(height: 52)
                            .background(enhanceVM.factor == value ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Theme.fill(0.055)), in: RoundedRectangle(cornerRadius: 12))
                            .shadow(color: enhanceVM.factor == value ? LocalStyle.mint.opacity(0.4) : Color.clear, radius: 9)
                        }
                    }
                }
            }
        }
        .padding(12)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 13))
        .disabled(busy)
    }

    /// Ajustes que casi nunca hace falta tocar: precisión, cámara lenta y resolución final.
    private func enhanceAdvancedCard(busy: Bool) -> some View {
        AdvancedDisclosure(isExpanded: $showEnhanceAdvanced, isModified: enhanceAdvancedModified) {
            if enhanceVM.doInterpolate {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(L.precisionTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
                    Text(enhanceVM.precision.caption.isEmpty ? enhanceVM.precision.displayName : enhanceVM.precision.displayName + " · " + enhanceVM.precision.caption)
                        .font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(Theme.ink(0.8))
                }
                Spacer()
                Picker("", selection: $enhanceVM.precision) {
                    ForEach(RIFEInterpolator.Precision.allCases) { option in
                        Text(option == .fp16 ? L.precisionFast.text : L.precisionHigh.text).tag(option)
                    }
                }
                .pickerStyle(.segmented)
                .frame(width: 150)
            }

            Toggle(isOn: $enhanceVM.slowMotion) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(tr("Cámara lenta", "Slow motion")).font(.system(size: 14, weight: .semibold, design: .rounded))
                    Text(enhanceVM.slowMotion
                         ? tr("El video dura ×\(enhanceVM.factor) más", "The video lasts ×\(enhanceVM.factor) longer")
                         : tr("Mantiene la duración y sube los fps", "Keeps the duration and raises the fps"))
                        .font(.caption2).foregroundStyle(Theme.ink(0.45))
                }
            }
            .tint(LocalStyle.mint)
            }
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(tr("RESOLUCIÓN DE EXPORTACIÓN", "EXPORT RESOLUTION"))
                    .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
                Text(enhanceVM.exportQuality.caption)
                    .font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(Theme.ink(0.8))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
            Picker("", selection: $enhanceVM.exportQuality) {
                ForEach(ExportQuality.allCases) { option in
                    Text(option.label).tag(option)
                }
            }
            .pickerStyle(.menu)
            .tint(LocalStyle.mint)
            .disabled(busy)
        }
        }
        .disabled(busy)
    }

    private var enhanceAdvancedModified: Bool {
        (enhanceVM.doInterpolate && (enhanceVM.precision != .fp16 || enhanceVM.slowMotion)) || enhanceVM.exportQuality != .automatic
    }

    private var enhancePreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let frame = enhanceVM.liveFrame, enhanceVM.isProcessing {
                Image(decorative: frame, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
            } else if let input = enhanceVM.inputURL, let output = enhanceVM.outputURL {
                VideoCompareView(beforeURL: input, afterURL: output, beforeStart: enhanceVM.resultTrimStart, slowFactor: enhanceVM.resultSlowFactor).id(output)
            } else if let player = enhancePlayer {
                ZoomableVideoPreview(player: player).id(ObjectIdentifier(player))
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "film").font(.system(size: 30)).foregroundStyle(.white.opacity(0.3))
                    Text(L.selectVideoPlaceholderTitle.text).font(.headline).foregroundStyle(.white.opacity(0.85))
                    Text(tr("Mejora calidad y fps, todo en tu iPhone", "Improve quality and fps, all on your iPhone"))
                        .font(.caption).foregroundStyle(.white.opacity(0.35))
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.fill(0.1)))
    }

    private var enhanceProcessingSection: some View {
        VStack(spacing: 9) {
            ProgressView(value: enhanceVM.progress).tint(Color(red: 0.25, green: 0.58, blue: 1))
            HStack {
                Text(enhanceVM.status).lineLimit(1)
                Spacer()
                ETALabel(progress: enhanceVM.progress)
            }
            .font(.caption.weight(.medium)).foregroundStyle(Theme.ink(0.55))

            Button { enhanceVM.cancel() } label: { secondaryButton(L.cancelButton.text, color: Color(red: 0.75, green: 0.08, blue: 0.12)) }
        }
    }

    private var enhanceResult: some View {
        Group {
            if let output = enhanceVM.outputURL {
                ResultActionBar(save: { try await PhotoSaver.saveVideo(at: output) },
                                share: ShareLink(item: output) { ShareBarLabel() })
                    .id(output)
            }
        }
    }

    @ViewBuilder
    private func imageView(geometry: GeometryProxy) -> some View {
        // Resultado listo: solo quedan la preview, Guardar/Compartir y el selector para elegir otra imagen.
        let showingResult = imageVM.outputImage != nil && !imageVM.isBusy

        imagePreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.52, 320))

        if showingResult, let output = imageVM.outputImage {
            ResultActionBar(
                save: { try await PhotoSaver.saveImage(output) },
                share: ShareLink(item: ShareableImage(image: output), preview: SharePreview("Astral", image: Image(decorative: output, scale: 1))) { ShareBarLabel() }
            )
            .id(ObjectIdentifier(output))
        } else {
            modelSelector(models: RealESRGAN.Model.imageModels, topRowCount: 3, selected: imageVM.selectedModel) { imageVM.selectedModel = $0 }
        }

        HStack(spacing: 8) {
            PhotosPicker(selection: $selectedImage, matching: .images, photoLibrary: .shared()) {
                pickerButton(title: L.selectImage.text, icon: "photo.badge.plus")
            }
            .disabled(imageVM.isBusy)
            if !showingResult {
                batchCompactPicker(selection: $batchImageItems, maxCount: 50, matching: .images, busy: imageVM.isBusy)
            }
        }

        if !showingResult {
            BatchSummary(isRunning: imageVM.isBatchRunning, index: imageVM.batchIndex, total: imageVM.batchTotal,
                         failures: imageVM.batchFailures, results: imageVM.batchResults)

            if imageVM.isBatchRunning {
                Button { imageVM.cancelBatch() } label: {
                    secondaryButton(tr("Cancelar lote", "Cancel batch"), color: Color.red.opacity(0.35), icon: "xmark")
                }
            }

            Button { imageVM.start() } label: { primaryButton(tr("Mejorar imagen", "Enhance image")) }
                .disabled(imageVM.inputImage == nil || imageVM.isBusy)
                .opacity(imageVM.inputImage == nil || imageVM.isBusy ? 0.45 : 1)

            if imageVM.needsLargeConfirmation && !imageVM.isProcessing {
                Button { imageVM.start(force: true) } label: {
                    secondaryButton(L.tryAnyway.text, color: Color.orange.opacity(0.35), icon: "exclamationmark.triangle")
                }
            }

            if imageVM.isProcessing {
                ProgressView().tint(Theme.ink())
            }

            if !imageVM.isBusy {
                Text(imageVM.status).font(.caption).foregroundStyle(Theme.ink(0.45)).frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var imagePreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let output = imageVM.outputImage, let before = imageVM.inputImage {
                ImageComparisonView(before: before, after: output)
            } else if let image = imageVM.inputImage {
                ZoomablePreview(resetToken: ObjectIdentifier(image).hashValue) {
                    Image(decorative: image, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
                }
            } else {
                Image(systemName: "photo").font(.system(size: 34)).foregroundStyle(.white.opacity(0.25))
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.fill(0.1)))
    }

    @ViewBuilder
    private func colorView(geometry: GeometryProxy) -> some View {
        colorPreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.46, 300))

        PhotosPicker(selection: $selectedColorItem, matching: .any(of: [.images, .videos]), photoLibrary: .shared()) {
            pickerButton(title: tr("Elegir foto o video", "Choose photo or video"), icon: "photo.on.rectangle")
        }
        .disabled(colorVM.isExporting)

        // Video exportado: solo quedan Guardar/Compartir (elegir otro archivo vuelve a mostrar los ajustes).
        let colorExportDone = colorVM.media == .video && colorVM.outputURL != nil && !colorVM.isExporting

        if colorVM.hasMedia {
            if !colorExportDone {
                colorLooksRow
                colorSlidersCard
            }

            if colorVM.media == .video {
                if colorVM.isExporting {
                    VStack(alignment: .leading, spacing: 8) {
                        ProgressView(value: colorVM.progress).tint(LocalStyle.mint)
                        Text(tr("Exportando…", "Exporting…") + " \(Int(colorVM.progress * 100))%")
                            .font(.caption).foregroundStyle(Theme.ink(0.6))
                    }
                } else if !colorExportDone {
                    Button { colorVM.exportVideo() } label: { primaryButton(tr("Exportar video", "Export video")) }
                        .disabled(colorVM.settings.isNeutral)
                        .opacity(colorVM.settings.isNeutral ? 0.45 : 1)
                }
                if let output = colorVM.outputURL, !colorVM.isExporting {
                    ResultActionBar(save: { try await PhotoSaver.saveVideo(at: output) },
                                    share: ShareLink(item: output) { ShareBarLabel() })
                        .id(output)
                }
            } else if colorVM.media == .image, !colorVM.settings.isNeutral, let source = colorVM.sourceImage {
                ResultActionBar(
                    save: { try await PhotoSaver.saveImage(try await colorVM.renderedImage()) },
                    share: ShareLink(item: ShareableAdjustedImage(source: source, settings: colorVM.settings),
                                     preview: SharePreview("Astral", image: Image(decorative: source, scale: 1))) { ShareBarLabel() }
                )
            }
        }

        if !colorVM.isExporting && !colorExportDone {
            Text(colorVM.status).font(.caption).foregroundStyle(Theme.ink(0.45)).frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var colorPreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            switch colorVM.media {
            case .image:
                if let image = colorVM.previewImage {
                    ZoomablePreview(resetToken: ObjectIdentifier(image).hashValue) {
                        Image(decorative: image, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
                    }
                }
            case .video:
                if let player = colorVM.player {
                    ZoomablePreview(resetToken: ObjectIdentifier(player).hashValue, onTap: { colorVM.togglePlay() }) {
                        PlayerLayerView(player: player).allowsHitTesting(false)
                    }
                    if !colorVM.isPlaying {
                        Image(systemName: "play.fill")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 58, height: 58)
                            .background(.black.opacity(0.45), in: Circle())
                            .allowsHitTesting(false)
                    }
                }
            case .none:
                VStack(spacing: 8) {
                    Image(systemName: "slider.horizontal.below.rectangle").font(.system(size: 34)).foregroundStyle(.white.opacity(0.25))
                    Text(tr("Ajuste de color", "Color adjustment")).font(.callout.weight(.semibold)).foregroundStyle(.white.opacity(0.4))
                }
            }

            if colorVM.hasMedia {
                VStack {
                    HStack {
                        Spacer()
                        Text(tr("Mantén para ver el original", "Hold to see the original"))
                            .font(.system(size: 10, weight: .bold, design: .rounded))
                            .foregroundStyle(colorVM.showOriginal ? Theme.onAccent : .white)
                            .padding(.horizontal, 10).padding(.vertical, 6)
                            .background(colorVM.showOriginal ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.black.opacity(0.55)), in: Capsule())
                            .onLongPressGesture(minimumDuration: 0.01, maximumDistance: 60, pressing: { pressing in
                                colorVM.showOriginal = pressing
                            }, perform: {})
                    }
                    .padding(10)
                    Spacer()
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.fill(0.1)))
    }

    private var colorLooksRow: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(tr("ESTILOS", "LOOKS"))
                .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 7) {
                    ForEach(ColorLook.allCases) { look in
                        let selected = colorVM.settings == look.settings
                        Button { colorVM.applyLook(look) } label: {
                            Text(look.title)
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundStyle(selected ? Theme.onAccent : Theme.ink())
                                .padding(.horizontal, 14).frame(height: 38)
                                .background(selected ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Theme.fill(0.055)), in: RoundedRectangle(cornerRadius: 11))
                        }
                    }
                }
            }
        }
        .disabled(colorVM.isExporting)
    }

    private var colorSlidersCard: some View {
        VStack(spacing: 12) {
            HStack {
                Text(tr("AJUSTES", "ADJUSTMENTS"))
                    .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
                Spacer()
                Button(tr("Restablecer", "Reset")) { colorVM.reset() }
                    .font(.caption.weight(.semibold)).foregroundStyle(LocalStyle.mint)
                    .disabled(colorVM.settings.isNeutral)
                    .opacity(colorVM.settings.isNeutral ? 0.4 : 1)
            }
            colorSlider(tr("Exposición", "Exposure"), $colorVM.settings.exposure, -2...2, neutral: 0)
            colorSlider(tr("Contraste", "Contrast"), $colorVM.settings.contrast, 0.6...1.6, neutral: 1)
            colorSlider(tr("Saturación", "Saturation"), $colorVM.settings.saturation, 0...2, neutral: 1)
            colorSlider(tr("Temperatura", "Temperature"), $colorVM.settings.temperature, -1...1, neutral: 0)

            AdvancedDisclosure(isExpanded: $showColorAdvanced, isModified: colorAdvancedModified, plain: true) {
                colorSlider(tr("Brillo", "Brightness"), $colorVM.settings.brightness, -0.3...0.3, neutral: 0)
                colorSlider(tr("Intensidad", "Vibrance"), $colorVM.settings.vibrance, -1...1, neutral: 0)
                colorSlider(tr("Matiz", "Tint"), $colorVM.settings.tint, -1...1, neutral: 0)
                colorSlider(tr("Luces altas", "Highlights"), $colorVM.settings.highlights, 0...1, neutral: 0)
                colorSlider(tr("Sombras", "Shadows"), $colorVM.settings.shadows, 0...1, neutral: 0)
                colorSlider(tr("Reducir ruido", "Noise reduction"), $colorVM.settings.denoise, 0...1, neutral: 0)
                colorSlider(tr("Nitidez", "Sharpness"), $colorVM.settings.sharpness, 0...1.5, neutral: 0)
                colorSlider(tr("Viñeta", "Vignette"), $colorVM.settings.vignette, 0...1, neutral: 0)
            }
        }
        .padding(12)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 13))
        .disabled(colorVM.isExporting)
    }

    private var colorAdvancedModified: Bool {
        let c = colorVM.settings
        return c.brightness != 0 || c.vibrance != 0 || c.tint != 0 || c.highlights != 0
            || c.shadows != 0 || c.denoise != 0 || c.sharpness != 0 || c.vignette != 0
    }

    private func colorSlider(_ title: String, _ value: Binding<Double>, _ range: ClosedRange<Double>, neutral: Double) -> some View {
        VStack(spacing: 3) {
            HStack {
                Text(title).font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(Theme.ink(0.85))
                Spacer()
                Text(String(format: "%+.2f", value.wrappedValue - neutral))
                    .font(.system(size: 11, weight: .medium, design: .rounded)).monospacedDigit()
                    .foregroundStyle(value.wrappedValue == neutral ? Theme.ink(0.35) : LocalStyle.mint)
            }
            Slider(value: value, in: range).tint(LocalStyle.mint)
        }
    }

    @ViewBuilder
    private func backgroundView(geometry: GeometryProxy) -> some View {
        // Resultado listo: solo quedan la preview, Guardar/Compartir y el selector para elegir otra imagen.
        let showingResult = backgroundVM.outputImage != nil && !backgroundVM.isBusy

        backgroundPreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.52, 320))

        if showingResult, let output = backgroundVM.outputImage {
            ResultActionBar(
                save: { try await PhotoSaver.saveImage(output) },
                share: ShareLink(item: ShareableImage(image: output), preview: SharePreview("Astral", image: Image(decorative: output, scale: 1))) { ShareBarLabel() }
            )
            .id(ObjectIdentifier(output))
        }

        HStack(spacing: 8) {
            PhotosPicker(selection: $selectedBackgroundImage, matching: .images, photoLibrary: .shared()) {
                pickerButton(title: L.selectImage.text, icon: "photo.badge.plus")
            }
            .disabled(backgroundVM.isBusy)
            if !showingResult {
                batchCompactPicker(selection: $batchBackgroundItems, maxCount: 50, matching: .images, busy: backgroundVM.isBusy)
            }
        }

        if !showingResult {
            BatchSummary(isRunning: backgroundVM.isBatchRunning, index: backgroundVM.batchIndex, total: backgroundVM.batchTotal,
                         failures: backgroundVM.batchFailures, results: backgroundVM.batchResults)

            if backgroundVM.isBatchRunning {
                Button { backgroundVM.cancelBatch() } label: {
                    secondaryButton(tr("Cancelar lote", "Cancel batch"), color: Color.red.opacity(0.35), icon: "xmark")
                }
            }

            Button { backgroundVM.start() } label: { primaryButton(tr("Quitar fondo", "Remove background")) }
                .disabled(backgroundVM.inputImage == nil || backgroundVM.isBusy)
                .opacity(backgroundVM.inputImage == nil || backgroundVM.isBusy ? 0.45 : 1)

            if backgroundVM.isProcessing {
                ProgressView().tint(Theme.ink())
            }

            if !backgroundVM.isBusy {
                Text(backgroundVM.status).font(.caption).foregroundStyle(Theme.ink(0.45)).frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var backgroundPreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let output = backgroundVM.outputImage, let before = backgroundVM.inputImage {
                ImageComparisonView(before: before, after: output)
            } else if let image = backgroundVM.inputImage {
                ZoomablePreview(resetToken: ObjectIdentifier(image).hashValue) {
                    Image(decorative: image, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
                }
            } else {
                Image(systemName: "person.crop.rectangle").font(.system(size: 34)).foregroundStyle(.white.opacity(0.25))
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.fill(0.1)))
    }

    private func batchCompactPicker(selection: Binding<[PhotosPickerItem]>, maxCount: Int, matching: PHPickerFilter, busy: Bool) -> some View {
        PhotosPicker(selection: selection, maxSelectionCount: maxCount, matching: matching, photoLibrary: .shared()) {
            compactAction(tr("Procesar por lotes", "Batch process"), icon: "square.stack.3d.up")
        }
        .disabled(busy)
        .opacity(busy ? 0.45 : 1)
    }

    private func compactAction(_ title: String, icon: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 14, weight: .semibold))
            Text(title)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .lineLimit(1).minimumScaleFactor(0.75)
        }
        .foregroundStyle(Theme.ink())
        .frame(width: 148, height: 46)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private func pickerButton(title: String, icon: String) -> some View {
        HStack {
            Image(systemName: icon)
            Text(title).fontWeight(.semibold)
            Spacer()
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).opacity(0.4)
        }
        .foregroundStyle(Theme.ink())
        .frame(maxWidth: .infinity).frame(height: 46).padding(.horizontal, 16)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private func primaryButton(_ title: String) -> some View {
        Text(title).font(.headline.weight(.bold)).foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 50).background(Color(red: 0.12, green: 0.47, blue: 1), in: RoundedRectangle(cornerRadius: 13))
    }

    private func secondaryButton(_ title: String, color: Color, icon: String? = nil) -> some View {
        HStack(spacing: 8) {
            if let icon { Image(systemName: icon) }
            Text(title).font(.subheadline.weight(.semibold))
        }
        .foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 48).background(color, in: RoundedRectangle(cornerRadius: 13))
    }
}
