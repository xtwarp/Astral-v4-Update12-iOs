import SwiftUI

struct SettingsView: View {
    let keepURLs: [URL]
    let isBusy: Bool
    let onResultsDeleted: () -> Void

    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var languageStore = AppLanguageStore.shared
    @State private var cacheBytes: Int64 = 0
    @State private var resultsBytes: Int64 = 0
    @State private var resultsCount = 0
    @State private var message = ""
    @State private var confirmDeleteResults = false

    var body: some View {
        ZStack {
            NeonBackground().ignoresSafeArea()
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text(L.settingsTitle.text)
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(.white.opacity(0.6))
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white.opacity(0.7))
                            .frame(width: 34, height: 34)
                            .background(Color.white.opacity(0.055), in: Circle())
                    }
                }

                languageCard

                storageCard(
                    title: L.cacheTitle.text,
                    detail: ByteCountFormatter.string(fromByteCount: cacheBytes, countStyle: .file),
                    buttonTitle: L.cacheButton.text,
                    icon: "trash",
                    enabled: !isBusy && cacheBytes > 0
                ) {
                    let freed = CacheManager.remove(CacheManager.temporaryFiles(), keeping: keepURLs)
                    message = "Liberado: \(ByteCountFormatter.string(fromByteCount: freed, countStyle: .file))"
                    refresh()
                }

                storageCard(
                    title: L.resultsTitle.text,
                    detail: "\(resultsCount) · \(ByteCountFormatter.string(fromByteCount: resultsBytes, countStyle: .file))",
                    buttonTitle: L.resultsButton.text,
                    icon: "trash.fill",
                    enabled: !isBusy && resultsCount > 0,
                    destructive: true
                ) {
                    confirmDeleteResults = true
                }

                if !message.isEmpty {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(LocalStyle.mint)
                }

                Text(L.cacheFootnote.text)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.45))

                Spacer(minLength: 0)
            }
            .padding(16)
        }
        .preferredColorScheme(.dark)
        .presentationDetents([.medium])
        .onAppear(perform: refresh)
        .alert(L.deleteResultsTitle.text, isPresented: $confirmDeleteResults) {
            Button(L.deleteButton.text, role: .destructive) {
                let freed = CacheManager.remove(CacheManager.resultFiles())
                message = "Liberado: \(ByteCountFormatter.string(fromByteCount: freed, countStyle: .file))"
                onResultsDeleted()
                refresh()
            }
            Button(L.cancelButton.text, role: .cancel) {}
        } message: {
            Text(L.deleteResultsMessage.text)
        }
    }

    private var languageCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(L.settingsLanguage.text)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(.white.opacity(0.45))
            Picker("", selection: $languageStore.language) {
                ForEach(AppLanguage.allCases) { lang in
                    Text(lang.displayName).tag(lang)
                }
            }
            .pickerStyle(.segmented)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 14))
    }

    private func refresh() {
        cacheBytes = CacheManager.size(of: CacheManager.temporaryFiles().filter { url in
            !keepURLs.contains { $0.resolvingSymlinksInPath().path == url.resolvingSymlinksInPath().path }
        })
        let results = CacheManager.resultFiles()
        resultsCount = results.count
        resultsBytes = CacheManager.size(of: results)
    }

    private func storageCard(title: String, detail: String, buttonTitle: String, icon: String, enabled: Bool, destructive: Bool = false, action: @escaping () -> Void) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(.white.opacity(0.45))
            Text(detail)
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Button(action: action) {
                HStack(spacing: 8) {
                    Image(systemName: icon)
                    Text(buttonTitle).font(.subheadline.weight(.semibold))
                }
                .foregroundStyle(destructive ? Color.white : Color.black)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(destructive ? AnyShapeStyle(Color.red.opacity(0.75)) : AnyShapeStyle(LocalStyle.gradient), in: RoundedRectangle(cornerRadius: 13))
            }
            .disabled(!enabled)
            .opacity(enabled ? 1 : 0.4)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 14))
    }
}
