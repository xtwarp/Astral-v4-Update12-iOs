import Foundation

enum CacheManager {
    private static let temporaryPrefixes = ["RealESRGAN-", "Astral_Input_", "Astral_Imported_"]

    private static func key(_ url: URL) -> String { url.resolvingSymlinksInPath().path }

    static var resultsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Astral Results", isDirectory: true)
    }

    static func isTemporary(_ url: URL) -> Bool {
        let tmp = FileManager.default.temporaryDirectory.resolvingSymlinksInPath().path
        return url.resolvingSymlinksInPath().deletingLastPathComponent().path == tmp
            && temporaryPrefixes.contains { url.lastPathComponent.hasPrefix($0) }
    }

    static func removeIfTemporary(_ url: URL?) {
        guard let url, isTemporary(url) else { return }
        try? FileManager.default.removeItem(at: url)
    }

    static func temporaryFiles() -> [URL] {
        let directory = FileManager.default.temporaryDirectory
        let urls = (try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)) ?? []
        return urls.filter { isTemporary($0) }
    }

    static func resultFiles() -> [URL] {
        (try? FileManager.default.contentsOfDirectory(at: resultsDirectory, includingPropertiesForKeys: nil)) ?? []
    }

    static func size(of urls: [URL]) -> Int64 {
        urls.reduce(0) { total, url in
            let values = try? url.resourceValues(forKeys: [.fileSizeKey])
            return total + Int64(values?.fileSize ?? 0)
        }
    }

    @discardableResult
    static func remove(_ urls: [URL], keeping: [URL] = []) -> Int64 {
        let protected = Set(keeping.map(key))
        var freed: Int64 = 0
        for url in urls where !protected.contains(key(url)) {
            let bytes = size(of: [url])
            if (try? FileManager.default.removeItem(at: url)) != nil { freed += bytes }
        }
        return freed
    }
}
