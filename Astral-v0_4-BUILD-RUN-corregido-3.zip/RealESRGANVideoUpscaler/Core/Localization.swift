import Foundation
import SwiftUI

enum AppLanguage: String, CaseIterable, Identifiable {
    case es, en
    var id: String { rawValue }
    var displayName: String { self == .es ? "Español" : "English" }
}

/// Guarda el idioma elegido y lo recuerda entre sesiones. No reinicia la app:
/// las vistas que observan `AppLanguageStore.shared` se redibujan solas al cambiarlo.
@MainActor
final class AppLanguageStore: ObservableObject {
    static let shared = AppLanguageStore()
    @Published var language: AppLanguage {
        didSet { UserDefaults.standard.set(language.rawValue, forKey: "astral.language") }
    }
    private init() {
        if let raw = UserDefaults.standard.string(forKey: "astral.language"), let saved = AppLanguage(rawValue: raw) {
            language = saved
        } else {
            language = (Locale.preferredLanguages.first ?? "es").hasPrefix("en") ? .en : .es
        }
    }
}

/// Textos de la interfaz en español e inglés. Cubre las etiquetas fijas (pestañas, botones,
/// títulos de sección, ajustes). Los mensajes de estado y de error que genera el procesamiento
/// (p. ej. "Procesando frame 12/80" o los errores de UpscaleError) siguen solo en español por ahora.
enum L: String {
    case tabVideo, tabImage, tabInterpolate, onDevice
    case settingsTitle, settingsLanguage
    case cacheTitle, cacheButton, resultsTitle, resultsButton, cacheFootnote
    case deleteResultsTitle, deleteResultsMessage, deleteButton, cancelButton
    case selectVideo, selectImage
    case startButton, startButtonCombined, interpolateButton, interpolateButtonCombined
    case modelSectionTitle
    case interpolateFactorTitle, interpolateFactorFast, interpolateFactorSmooth
    case precisionTitle, precisionFast, precisionHigh
    case alsoInterpolateTitle, alsoInterpolateSubtitle
    case alsoUpscaleTitle, alsoUpscaleSubtitle
    case beforeAfterTitle, saveToFiles, shareExport
    case selectVideoPlaceholderTitle, selectVideoPlaceholderSubtitle
    case selectImagePlaceholderTitle
    case interpolatePlaceholderTitle, interpolatePlaceholderSubtitle
    case tryAnyway
    case beforeLabel, afterLabel

    private static let table: [L: (es: String, en: String)] = [
        .tabVideo: ("VIDEO", "VIDEO"),
        .tabImage: ("IMAGEN", "IMAGE"),
        .tabInterpolate: ("INTERPOLAR", "INTERPOLATE"),
        .onDevice: ("ON-DEVICE", "ON-DEVICE"),
        .settingsTitle: ("AJUSTES", "SETTINGS"),
        .settingsLanguage: ("IDIOMA", "LANGUAGE"),
        .cacheTitle: ("CACHÉ TEMPORAL", "TEMPORARY CACHE"),
        .cacheButton: ("Borrar caché", "Clear cache"),
        .resultsTitle: ("RESULTADOS GUARDADOS EN LA APP", "RESULTS SAVED IN THE APP"),
        .resultsButton: ("Borrar resultados", "Delete results"),
        .cacheFootnote: (
            "Los archivos que estás usando ahora se conservan al borrar la caché. Todo se procesa y se guarda solo en tu dispositivo.",
            "Files you're currently using are kept when you clear the cache. Everything is processed and saved only on your device."
        ),
        .deleteResultsTitle: ("¿Borrar resultados guardados?", "Delete saved results?"),
        .deleteResultsMessage: (
            "Se eliminarán los videos de la carpeta «Astral Results» (Archivos › En mi iPhone › Astral). Los que exportaste a otra ubicación no se tocan.",
            "This deletes the videos in the “Astral Results” folder (Files › On My iPhone › Astral). Anything you already exported elsewhere is untouched."
        ),
        .deleteButton: ("Borrar", "Delete"),
        .cancelButton: ("Cancelar", "Cancel"),
        .selectVideo: ("Seleccionar video", "Select video"),
        .selectImage: ("Seleccionar imagen", "Select image"),
        .startButton: ("Comenzar", "Start"),
        .startButtonCombined: ("Escalar + interpolar", "Upscale + interpolate"),
        .interpolateButton: ("Interpolar", "Interpolate"),
        .interpolateButtonCombined: ("Interpolar + escalar", "Interpolate + upscale"),
        .modelSectionTitle: ("MODELO", "MODEL"),
        .interpolateFactorTitle: ("FACTOR DE INTERPOLACIÓN", "INTERPOLATION FACTOR"),
        .interpolateFactorFast: ("más rápido", "faster"),
        .interpolateFactorSmooth: ("más fluido", "smoother"),
        .precisionTitle: ("PRECISIÓN", "PRECISION"),
        .precisionFast: ("Rápida", "Fast"),
        .precisionHigh: ("Alta", "High"),
        .alsoInterpolateTitle: ("Interpolar también", "Also interpolate"),
        .alsoInterpolateSubtitle: (
            "Escala y, frame a frame, genera frames intermedios con RIFE después",
            "Upscales and, frame by frame, generates in-between frames with RIFE afterwards"
        ),
        .alsoUpscaleTitle: ("Escalar también", "Also upscale"),
        .alsoUpscaleSubtitle: (
            "Interpola y, frame a frame, aplica Real-ESRGAN después",
            "Interpolates and, frame by frame, applies Real-ESRGAN afterwards"
        ),
        .beforeAfterTitle: ("ANTES / DESPUÉS", "BEFORE / AFTER"),
        .saveToFiles: ("Guardar en Archivos", "Save to Files"),
        .shareExport: ("Compartir / Exportar", "Share / Export"),
        .selectVideoPlaceholderTitle: ("Selecciona un video", "Select a video"),
        .selectVideoPlaceholderSubtitle: ("Real-ESRGAN procesa todo en el iPhone", "Real-ESRGAN processes everything on your iPhone"),
        .selectImagePlaceholderTitle: ("Selecciona una imagen", "Select an image"),
        .interpolatePlaceholderTitle: ("Selecciona un video", "Select a video"),
        .interpolatePlaceholderSubtitle: ("RIFE genera frames intermedios en el iPhone", "RIFE generates in-between frames on your iPhone"),
        .tryAnyway: ("Intentar de todos modos", "Try anyway"),
        .beforeLabel: ("ANTES", "BEFORE"),
        .afterLabel: ("DESPUÉS", "AFTER"),
    ]

    @MainActor
    var text: String {
        guard let pair = Self.table[self] else { return rawValue }
        return AppLanguageStore.shared.language == .es ? pair.es : pair.en
    }
}
