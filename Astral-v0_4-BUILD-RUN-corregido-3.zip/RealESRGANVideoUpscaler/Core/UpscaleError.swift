import Foundation

enum UpscaleError: LocalizedError {
    case invalidVideo
    case modelMissing(String)
    case unsupportedPixelFormat
    case cancelled
    case readerFailed
    case writerFailed
    case coreML(String)
    case exportFailed
    case frameTooLarge(width: Int, height: Int)
    case interpolationUnsupportedSize(width: Int, height: Int)
    case writerStalled

    var errorDescription: String? {
        switch self {
        case .invalidVideo: return "No se pudo abrir el vídeo."
        case .modelMissing(let name): return "Falta \(name) en esta compilación. Vuelve a correr el build para incluirlo."
        case .unsupportedPixelFormat: return "El vídeo usa un formato de píxel no compatible."
        case .cancelled: return "Procesamiento cancelado."
        case .readerFailed: return "No se pudo leer el vídeo."
        case .writerFailed: return "No se pudo escribir el vídeo."
        case .coreML(let message): return "Core ML: \(message)"
        case .exportFailed: return "No se pudo finalizar el archivo de vídeo."
        case .frameTooLarge(let width, let height):
            return "El frame \(width)×\(height) es demasiado grande para procesarlo a 4× con seguridad en este iPhone."
        case .interpolationUnsupportedSize(let width, let height):
            return "El vídeo \(width)×\(height) supera el tamaño máximo para interpolar (\(RIFEInterpolator.maxSizeDescription))."
        case .writerStalled:
            return "El proceso se detuvo sin avanzar (probable límite de memoria o calor del iPhone). Prueba con un vídeo más corto o ciérralo y vuelve a intentarlo."
        }
    }
}
