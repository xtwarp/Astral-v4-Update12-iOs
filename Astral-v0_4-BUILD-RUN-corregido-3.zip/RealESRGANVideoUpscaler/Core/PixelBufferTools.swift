import Foundation
import CoreVideo

struct RGBFrame {
    let values: [Float]
    let width: Int
    let height: Int
}

enum PixelBufferTools {
    static func rgbFloatArray(from buffer: CVPixelBuffer) throws -> RGBFrame {
        guard CVPixelBufferGetPixelFormatType(buffer) == kCVPixelFormatType_32BGRA else {
            throw UpscaleError.unsupportedPixelFormat
        }

        CVPixelBufferLockBaseAddress(buffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }

        guard let base = CVPixelBufferGetBaseAddress(buffer) else {
            throw UpscaleError.unsupportedPixelFormat
        }

        let width = CVPixelBufferGetWidth(buffer)
        let height = CVPixelBufferGetHeight(buffer)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(buffer)
        let ptr = base.assumingMemoryBound(to: UInt8.self)
        var rgb = [Float](repeating: 0, count: width * height * 3)

        for y in 0..<height {
            let row = ptr.advanced(by: y * bytesPerRow)
            for x in 0..<width {
                let i = x * 4
                let d = (y * width + x) * 3
                rgb[d] = Float(row[i + 2]) / 255.0
                rgb[d + 1] = Float(row[i + 1]) / 255.0
                rgb[d + 2] = Float(row[i]) / 255.0
            }
        }
        return RGBFrame(values: rgb, width: width, height: height)
    }

    static func makeBGRA(values: [Float], width: Int, height: Int) throws -> CVPixelBuffer {
        var pb: CVPixelBuffer?
        let attrs: [CFString: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey: true,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ]
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            width,
            height,
            kCVPixelFormatType_32BGRA,
            attrs as CFDictionary,
            &pb
        )
        guard status == kCVReturnSuccess, let buffer = pb else {
            throw UpscaleError.writerFailed
        }

        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        guard let base = CVPixelBufferGetBaseAddress(buffer) else {
            throw UpscaleError.writerFailed
        }

        let ptr = base.assumingMemoryBound(to: UInt8.self)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(buffer)

        for y in 0..<height {
            let row = ptr.advanced(by: y * bytesPerRow)
            for x in 0..<width {
                let s = (y * width + x) * 3
                let d = x * 4
                row[d] = toByte(values[s + 2])
                row[d + 1] = toByte(values[s + 1])
                row[d + 2] = toByte(values[s])
                row[d + 3] = 255
            }
        }
        return buffer
    }

    private static func toByte(_ value: Float) -> UInt8 {
        let clamped = min(max(value, 0.0), 1.0)
        return UInt8((clamped * 255.0).rounded())
    }
}
