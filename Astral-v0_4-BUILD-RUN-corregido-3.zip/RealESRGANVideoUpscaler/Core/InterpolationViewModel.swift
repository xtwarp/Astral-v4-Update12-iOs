import Foundation
import SwiftUI
import PhotosUI
import CoreImage
import CoreVideo

@MainActor
final class InterpolationViewModel: ObservableObject {
    @Published var inputURL: URL?
    @Published var outputURL: URL?
    @Published var progress: Double = 0
    @Published var status = "Selecciona un video"
    @Published var isProcessing = false
    @Published var liveFrame: CGImage?
    @Published var liveFrameNumber = 0

    @Published var factor = 2
    @Published var precision: RIFEInterpolator.Precision = .fp16
    @Published var alsoUpscale = false
    @Published var selectedUpscaleModel: RealESRGAN.Model = .animevideo

    private var processor: InterpolationProcessor?
    private var securityScopedInput = false
    private let previewContext = CIContext(options: [.cacheIntermediates: false])

    func importVideo(from item: PhotosPickerItem) async {
        guard !isProcessing else { return }
        status = "Cargando video…"
        do {
            let imported = try await item.loadTransferable(type: ImportedMovie.self)
            guard let imported else { status = "No se pudo cargar el video"; return }
            if securityScopedInput, let oldURL = inputURL { oldURL.stopAccessingSecurityScopedResource() }
            securityScopedInput = false
            let previousInput = inputURL
            inputURL = imported.url
            if previousInput != imported.url { CacheManager.removeIfTemporary(previousInput) }
            outputURL = nil
            liveFrame = nil
            liveFrameNumber = 0
            progress = 0
            status = "Video seleccionado"
        } catch {
            status = "No se pudo cargar el video: \(error.localizedDescription)"
        }
    }

    func start() {
        guard let sourceURL = inputURL, !isProcessing else { return }
        isProcessing = true
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        progress = 0
        status = "Cargando interpolación \(factor)×…"

        let processor = InterpolationProcessor()
        self.processor = processor
        let chosenFactor = factor
        let chosenPrecision = precision
        let upscaleModel = alsoUpscale ? selectedUpscaleModel : nil

        processor.process(
            inputURL: sourceURL,
            factor: chosenFactor,
            precision: chosenPrecision,
            upscaleModel: upscaleModel,
            progress: { [weak self] value, text in
                DispatchQueue.main.async { self?.progress = value; self?.status = text }
            },
            framePreview: { [weak self] pixelBuffer, frameNumber in
                guard let self else { return }
                autoreleasepool {
                    let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
                    let maxDimension: CGFloat = 900
                    let longest = max(ciImage.extent.width, ciImage.extent.height)
                    let scale = min(1, maxDimension / max(longest, 1))
                    let previewImage = scale < 1 ? ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale)) : ciImage
                    if let cg = self.previewContext.createCGImage(previewImage, from: previewImage.extent) {
                        DispatchQueue.main.async {
                            self.liveFrame = cg
                            self.liveFrameNumber = frameNumber
                        }
                    }
                }
            },
            completion: { [weak self] result in
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.isProcessing = false
                    self.processor = nil
                    switch result {
                    case .success(let url):
                        do {
                            let permanentURL = try self.persistOutput(url)
                            self.outputURL = permanentURL
                            self.status = "Listo — usa Guardar en Archivos para elegir la ubicación"
                        } catch {
                            self.outputURL = url
                            self.status = "Listo — usa Guardar en Archivos para exportar"
                        }
                    case .failure(let error):
                        self.status = error.localizedDescription
                    }
                }
            }
        )
    }

    func cancel() { processor?.cancel(); status = "Cancelando…" }

    private func persistOutput(_ sourceURL: URL) throws -> URL {
        let directory = CacheManager.resultsDirectory
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let destination = directory.appendingPathComponent("Astral_Interp_\(UUID().uuidString).mp4")
        try FileManager.default.copyItem(at: sourceURL, to: destination)
        CacheManager.removeIfTemporary(sourceURL)
        return destination
    }

    func discardOutputIfMissing() {
        guard let url = outputURL, !FileManager.default.fileExists(atPath: url.path) else { return }
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        progress = 0
        status = "Selecciona un video"
    }
}
