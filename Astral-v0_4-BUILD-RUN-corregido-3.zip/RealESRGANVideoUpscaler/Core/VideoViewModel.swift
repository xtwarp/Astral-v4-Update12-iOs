import Foundation
import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import CoreImage
import CoreVideo

@MainActor
final class VideoViewModel: ObservableObject {
    @Published var inputURL: URL?
    @Published var outputURL: URL?
    @Published var progress: Double = 0
    @Published var status = "Selecciona un video"
    @Published var isProcessing = false
    @Published var liveFrame: CGImage?
    @Published var liveFrameNumber = 0
    @Published var selectedModel: RealESRGAN.Model = .animevideo
    @Published var alsoInterpolate = false
    @Published var interpolationFactor = 2
    @Published var interpolationPrecision: RIFEInterpolator.Precision = .fp16

    private var processor: VideoProcessor?
    private var interpolationProcessor: InterpolationProcessor?
    private var securityScopedInput = false
    private let previewContext = CIContext(options: [.cacheIntermediates: false])

    func importVideo(from item: PhotosPickerItem) async {
        guard !isProcessing else { return }
        status = "Cargando video…"
        do {
            let imported = try await item.loadTransferable(type: ImportedMovie.self)
            guard let imported else { status = "No se pudo cargar el video"; return }
            if securityScopedInput, let oldURL = inputURL { oldURL.stopAccessingSecurityScopedResource() }
            securityScopedInput = false
            let previousInput = inputURL
            inputURL = imported.url
            if previousInput != imported.url { CacheManager.removeIfTemporary(previousInput) }
            outputURL = nil
            liveFrame = nil
            liveFrameNumber = 0
            progress = 0
            status = "Video seleccionado"
        } catch {
            status = "No se pudo cargar el video: \(error.localizedDescription)"
        }
    }

    func start() {
        guard let sourceURL = inputURL, !isProcessing else { return }
        isProcessing = true
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        progress = 0
        let model = selectedModel

        let framePreview: (CVPixelBuffer, Int) -> Void = { [weak self] pixelBuffer, frameNumber in
            guard let self else { return }
            autoreleasepool {
                let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
                let maxDimension: CGFloat = 900
                let longest = max(ciImage.extent.width, ciImage.extent.height)
                let scale = min(1, maxDimension / max(longest, 1))
                let previewImage = scale < 1 ? ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale)) : ciImage
                if let cg = self.previewContext.createCGImage(previewImage, from: previewImage.extent) {
                    DispatchQueue.main.async {
                        self.liveFrame = cg
                        self.liveFrameNumber = frameNumber
                    }
                }
            }
        }
        let completion: (Result<URL, Error>) -> Void = { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                self.isProcessing = false
                self.processor = nil
                self.interpolationProcessor = nil
                switch result {
                case .success(let url):
                    do {
                        let permanentURL = try self.persistOutput(url)
                        self.outputURL = permanentURL
                        self.status = "Listo — usa Guardar en Archivos para elegir la ubicación"
                    } catch {
                        self.outputURL = url
                        self.status = "Listo — usa Guardar en Archivos para exportar"
                    }
                case .failure(let error):
                    self.status = error.localizedDescription
                }
            }
        }

        if alsoInterpolate {
            status = "Cargando interpolación \(interpolationFactor)× + \(model.displayName)…"
            let processor = InterpolationProcessor()
            self.interpolationProcessor = processor
            processor.process(
                inputURL: sourceURL,
                factor: interpolationFactor,
                precision: interpolationPrecision,
                upscaleModel: model,
                progress: { [weak self] value, text in
                    DispatchQueue.main.async { self?.progress = value; self?.status = text }
                },
                framePreview: framePreview,
                completion: completion
            )
        } else {
            status = "Cargando \(model.displayName)…"
            let processor = VideoProcessor()
            self.processor = processor
            processor.process(
                inputURL: sourceURL,
                model: model,
                progress: { [weak self] value, text in
                    DispatchQueue.main.async { self?.progress = value; self?.status = text }
                },
                framePreview: framePreview,
                completion: completion
            )
        }
    }

    func cancel() {
        processor?.cancel()
        interpolationProcessor?.cancel()
        status = "Cancelando…"
    }

    private func persistOutput(_ sourceURL: URL) throws -> URL {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let directory = documents.appendingPathComponent("Astral Results", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let destination = directory.appendingPathComponent("Astral_\(UUID().uuidString).mp4")
        try FileManager.default.copyItem(at: sourceURL, to: destination)
        CacheManager.removeIfTemporary(sourceURL)
        return destination
    }

    func discardOutputIfMissing() {
        guard let url = outputURL, !FileManager.default.fileExists(atPath: url.path) else { return }
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        progress = 0
        status = "Selecciona un video"
    }
}

struct ImportedMovie: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { movie in SentTransferredFile(movie.url) } importing: { received in
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Input_\(UUID().uuidString).mp4")
            try FileManager.default.copyItem(at: received.file, to: destination)
            return ImportedMovie(url: destination)
        }
    }
}

struct VideoDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.movie] }
    static var writableContentTypes: [UTType] { [.movie] }
    let url: URL
    init(url: URL) { self.url = url }
    init(configuration: ReadConfiguration) throws {
        let temp = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Imported_\(UUID().uuidString).mp4")
        guard let data = configuration.file.regularFileContents else { throw CocoaError(.fileReadCorruptFile) }
        try data.write(to: temp)
        self.url = temp
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { try FileWrapper(url: url, options: .immediate) }
}
