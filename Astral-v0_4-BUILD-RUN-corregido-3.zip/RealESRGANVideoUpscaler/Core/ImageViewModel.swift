import Foundation
import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import ImageIO

@MainActor
final class ImageViewModel: ObservableObject {
    @Published var inputImage: CGImage?
    @Published var outputImage: CGImage?
    @Published var isProcessing = false
    @Published var status = "Selecciona una imagen"
    @Published var selectedModel: RealESRGAN.Model = .general
    @Published var needsLargeConfirmation = false

    func importImage(from item: PhotosPickerItem) async {
        guard !isProcessing else { return }
        status = "Cargando imagen…"
        do {
            guard let data = try await item.loadTransferable(type: Data.self),
                  let source = CGImageSourceCreateWithData(data as CFData, nil),
                  let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
                status = "No se pudo cargar la imagen"
                return
            }
            inputImage = image
            outputImage = nil
            needsLargeConfirmation = false
            status = "Imagen seleccionada"
        } catch {
            status = "No se pudo cargar la imagen: \(error.localizedDescription)"
        }
    }

    func start(force: Bool = false) {
        guard let source = inputImage, !isProcessing else { return }
        let model = selectedModel
        if !force, RealESRGAN.exceedsSafeLimit(width: source.width, height: source.height, scale: model.scale) {
            needsLargeConfirmation = true
            status = "La imagen \(source.width)×\(source.height) es muy grande para procesarla a \(model.scale)× con seguridad en este iPhone. Si lo intentas, la app puede cerrarse por falta de memoria."
            return
        }
        needsLargeConfirmation = false
        isProcessing = true
        outputImage = nil
        status = "Procesando con \(model.displayName)…"

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                let engine = try RealESRGAN(model: model)
                let result = try engine.upscale(cgImage: source, allowLarge: force) { false }
                DispatchQueue.main.async {
                    self?.outputImage = result
                    self?.isProcessing = false
                    self?.status = "Listo — guarda el resultado en Archivos"
                }
            } catch {
                DispatchQueue.main.async {
                    self?.isProcessing = false
                    self?.status = error.localizedDescription
                }
            }
        }
    }
}

struct ImageDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.png, .jpeg] }
    static var writableContentTypes: [UTType] { [.png] }

    let image: CGImage

    init(image: CGImage) { self.image = image }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents,
              let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
            throw CocoaError(.fileReadCorruptFile)
        }
        self.image = image
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        let data = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil) else {
            throw CocoaError(.fileWriteUnknown)
        }
        CGImageDestinationAddImage(destination, image, nil)
        guard CGImageDestinationFinalize(destination) else {
            throw CocoaError(.fileWriteUnknown)
        }
        return FileWrapper(regularFileWithContents: data as Data)
    }
}
