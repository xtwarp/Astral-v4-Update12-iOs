# Licencias

## Modelos de IA incluidos

| Nombre en la app | Modelo | Autor | Licencia | Fuente |
|---|---|---|---|---|
| Anime / General / Plus / Anime (6B) | Real-ESRGAN (AnimeVideo v3, General x4v3 y su modelo hermano wdn, x4plus, x4plus anime 6B) | xinntao | BSD-3-Clause | https://github.com/xinntao/Real-ESRGAN |
| Aurora (×2) | 2xHFA2kCompact | Philip Hofmann (Phhofm), entrenado con el dataset HFA2k de musl | CC BY 4.0 | https://github.com/Phhofm/models/releases/tag/2xHFA2kCompact |
| Aurora (×4) | animerd v1 | musl | CC0-1.0 | https://openmodeldb.info/models/4x-animerd-v1 |
| Interpolación de frames | RIFE 4.25 | hzwer (Practical-RIFE) | MIT | https://github.com/hzwer/Practical-RIFE |

Los modelos Aurora ×2 y Aurora ×4 se convierten a Core ML (fp16) con el workflow `convert-sr.yml`.
Aurora ×2 es una adaptación (conversión de formato) de 2xHFA2kCompact: CC BY 4.0 exige dar crédito al autor, enlazar la licencia e indicar que se hicieron cambios (se indica en Ajustes › Créditos y licencias).

## Código de referencia

- Los modelos Real-ESRGAN (AnimeVideo v3, General, x4plus y Anime 6B) se descargan ya convertidos a Core ML del release v1.0.0 de hanxiao/real-esrgan-coreml (MIT).
- «Intensidad de limpieza»: las mezclas del modelo General (`general_dn0`, `general_dn25`, `general_dn50`, `general_dn75`) las genera `convert-sr.yml` mezclando los pesos oficiales `realesr-general-x4v3` y `realesr-general-wdn-x4v3` (release v0.2.5.0 de Real-ESRGAN, BSD-3-Clause), igual que la opción `--denoise_strength` de Real-ESRGAN. El 100 % es el modelo General sin mezclar.

## Contenido de ejemplo

La pantalla de bienvenida incluye contenido de ejemplo en `Astral/Resources/Demo`:

| Archivo | Uso | Licencia |
|---|---|---|
| `real-antes.jpg`, `real-despues.jpg` | Comparativa «Foto real» | Gratuita, de uso comercial (comprobada por el desarrollador) |
| `anime-antes.jpg`, `anime-despues.jpg` | Comparativa «Anime» | Gratuita, de uso comercial (comprobada por el desarrollador) |
| `interpolacion-antes.mp4` (30 fps), `interpolacion-despues.mp4` (60 fps) | Comparativa «Interpolación» | Gratuita, de uso comercial (comprobada por el desarrollador) |

Las imágenes y los videos «después» son resultados de la propia app. Los videos de prueba del usuario deben ser aportados por él y tener los derechos correspondientes.

## Antes de publicar comercialmente

- Conservar los textos de licencia y mostrar los créditos de los modelos dentro de la app (CC BY 4.0 y BSD-3-Clause lo requieren).
- Revisar los términos vigentes de cada repositorio/modelo.
- Conservar la fuente y la licencia de cada imagen y video de `Resources/Demo`.

## Textos completos de las licencias

La app los muestra en *Ajustes › Créditos y licencias* (`Astral/UI/LicenseTexts.swift`). BSD-3-Clause y MIT exigen conservar el aviso de copyright y el texto; CC BY 4.0 exige dar crédito, enlazar la licencia e indicar los cambios.

### Real-ESRGAN — BSD 3-Clause

```
BSD 3-Clause License

Copyright (c) 2021, Xintao Wang
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
```

### Practical-RIFE (RIFE 4.25) — MIT, y real-esrgan-coreml — MIT

Mismo texto MIT para ambos, con su propia línea de copyright: «Copyright (c) 2021 hzwer» (Practical-RIFE) y «Copyright (c) hanxiao» (real-esrgan-coreml).

Pendiente: confirmar la línea exacta de copyright de real-esrgan-coreml con el archivo LICENSE de ese repositorio y la de Practical-RIFE con su LICENSE oficial.

### Aurora ×2 — CC BY 4.0 · Aurora ×4 — CC0 1.0

Ver el texto de atribución en `LicenseTexts.swift` (enlaces a creativecommons.org y cambios indicados).
