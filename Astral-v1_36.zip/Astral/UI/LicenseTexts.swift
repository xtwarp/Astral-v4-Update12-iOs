import Foundation

/// Textos completos de las licencias de lo que incluye la app. BSD-3-Clause y MIT exigen conservar el aviso de
/// copyright y el texto de la licencia; CC BY 4.0 exige dar crédito, enlazar la licencia e indicar los cambios.
/// Los textos legales se muestran siempre en su idioma original.
enum LicenseTexts {
    struct Doc: Identifiable {
        let id: String
        let title: String
        let source: String
        let text: String
    }

    static let all: [Doc] = [
        Doc(id: "realesrgan",
            title: "Real-ESRGAN — BSD 3-Clause",
            source: "https://github.com/xinntao/Real-ESRGAN",
            text: """
            BSD 3-Clause License

            Copyright (c) 2021, Xintao Wang
            All rights reserved.

            Redistribution and use in source and binary forms, with or without
            modification, are permitted provided that the following conditions are met:

            1. Redistributions of source code must retain the above copyright notice, this
               list of conditions and the following disclaimer.

            2. Redistributions in binary form must reproduce the above copyright notice,
               this list of conditions and the following disclaimer in the documentation
               and/or other materials provided with the distribution.

            3. Neither the name of the copyright holder nor the names of its
               contributors may be used to endorse or promote products derived from
               this software without specific prior written permission.

            THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
            AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
            IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
            DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
            FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
            DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
            SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
            CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
            OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
            OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
            """),
        Doc(id: "rife",
            title: "Practical-RIFE (RIFE 4.25) — MIT",
            source: "https://github.com/hzwer/Practical-RIFE",
            text: """
            MIT License

            Copyright (c) 2021 hzwer

            Permission is hereby granted, free of charge, to any person obtaining a copy
            of this software and associated documentation files (the "Software"), to deal
            in the Software without restriction, including without limitation the rights
            to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
            copies of the Software, and to permit persons to whom the Software is
            furnished to do so, subject to the following conditions:

            The above copyright notice and this permission notice shall be included in all
            copies or substantial portions of the Software.

            THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
            IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
            FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
            AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
            LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
            OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
            SOFTWARE.
            """),
        Doc(id: "coreml",
            title: "real-esrgan-coreml — MIT",
            source: "https://github.com/hanxiao/real-esrgan-coreml",
            text: """
            MIT License

            Copyright (c) hanxiao

            Permission is hereby granted, free of charge, to any person obtaining a copy
            of this software and associated documentation files (the "Software"), to deal
            in the Software without restriction, including without limitation the rights
            to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
            copies of the Software, and to permit persons to whom the Software is
            furnished to do so, subject to the following conditions:

            The above copyright notice and this permission notice shall be included in all
            copies or substantial portions of the Software.

            THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
            IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
            FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
            AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
            LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
            OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
            SOFTWARE.
            """),
        Doc(id: "hfa2k",
            title: "2xHFA2kCompact — CC BY 4.0",
            source: "https://creativecommons.org/licenses/by/4.0/",
            text: """
            2xHFA2kCompact by Philip Hofmann (Phhofm), trained on musl's HFA2k dataset.
            Licensed under the Creative Commons Attribution 4.0 International License (CC BY 4.0):
            https://creativecommons.org/licenses/by/4.0/

            Source: https://github.com/Phhofm/models/releases/tag/2xHFA2kCompact

            Changes made: the model was converted to Core ML (fp16) for use in this app. The model is used
            as published; the authors do not endorse this app.
            """),
        Doc(id: "animerd",
            title: "animerd v1 — CC0 1.0",
            source: "https://creativecommons.org/publicdomain/zero/1.0/",
            text: """
            4x-animerd-v1 by musl, released under CC0 1.0 Universal (public domain dedication):
            https://creativecommons.org/publicdomain/zero/1.0/

            Source: https://openmodeldb.info/models/4x-animerd-v1

            The model was converted to Core ML (fp16) for use in this app.
            """)
    ]
}
