import Foundation
import CoreML
import CoreVideo
import CoreGraphics
import ImageIO
import UniformTypeIdentifiers

final class RealESRGAN {
    enum Model: String, CaseIterable, Identifiable {
        case animevideo = "animevideo"
        case general = "general"
        case anime6B = "anime_6B"
        case x4plus = "x4plus"
        /// Aurora ×2 — 2xHFA2kCompact (Philip Hofmann, CC BY 4.0). Anime ×2, arquitectura Compact.
        case nova = "hfa2k_compact"
        /// Aurora ×4 — animerd v1 (musl, CC0-1.0). Anime ×4, arquitectura Compact.
        case quasar = "animerd"

        static let videoModels: [Model] = [.general, .animevideo, .nova, .quasar]
        static let imageModels: [Model] = [.general, .anime6B, .x4plus, .nova, .quasar]

        var id: String { rawValue }
        var displayName: String {
            switch self {
            case .animevideo: return "Real-ESRGAN AnimeVideo v3"
            case .general: return "Real-ESRGAN General x4"
            case .anime6B: return "Real-ESRGAN Anime 6B"
            case .x4plus: return "Real-ESRGAN x4plus"
            case .nova: return "Aurora ×2 (2xHFA2kCompact)"
            case .quasar: return "Aurora ×4 (animerd v1)"
            }
        }
        var shortName: String {
            switch self {
            case .animevideo: return "Anime"
            case .general: return "General"
            case .anime6B: return "Anime"
            case .x4plus: return "Plus"
            case .nova: return "Aurora"
            case .quasar: return "Aurora"
            }
        }
        /// Nombre para resúmenes (presets): Aurora comparte nombre en ×2 y ×4, así que lleva la escala.
        var summaryName: String {
            switch self {
            case .nova, .quasar: return "\(shortName) ×\(scale)"
            default: return shortName
            }
        }
        /// Para qué sirve cada modelo; se muestra bajo el selector.
        var blurb: String {
            switch self {
            case .animevideo: return tr("Especializado en anime, rápido y ligero.", "Specialized in anime, fast and light.")
            case .general: return tr("Anime y vida real, equilibrado.", "Anime and real life, balanced.")
            case .anime6B: return tr("Ilustraciones y arte anime. El más detallado, pero lento.", "Anime illustrations and art. Most detailed, but slow.")
            case .x4plus: return tr("Fotos reales con mucho detalle. Pesado.", "Real photos with lots of detail. Heavy.")
            case .nova: return tr("Para anime, también funciona con vida real: resultado más suave y natural.", "For anime, also works on real life: a softer, more natural result.")
            case .quasar: return tr("Para anime, también funciona con vida real: resultado más suave y natural.", "For anime, also works on real life: a softer, more natural result.")
            }
        }
        var caption: String { "×\(scale)" }
        var scale: Int {
            switch self {
            case .nova: return 2
            default: return 4
            }
        }
    }

    /// Intensidad de limpieza del modelo General (mezcla con su modelo hermano "wdn", como hace Real-ESRGAN).
    /// 100 % = el modelo General normal; 0 % = el modelo "wdn", que conserva más ruido y textura.
    static let cleanupSteps = [0, 25, 50, 75, 100]
    static let defaultCleanup = 100

    /// El control solo aparece si las mezclas vienen incluidas en la app (las genera el workflow convert-sr).
    static let cleanupAvailable: Bool = cleanupSteps.filter { $0 != defaultCleanup }.allSatisfy {
        Bundle.main.url(forResource: "RealESRGAN_general_dn\($0)_522_fp16", withExtension: "mlmodelc") != nil
    }

    static let safeWorkingBytes: Int64 = 700 * 1024 * 1024

    static func exceedsSafeLimit(width: Int, height: Int, scale: Int) -> Bool {
        Int64(width * scale) * Int64(height * scale) * 16 > safeWorkingBytes
    }

    static let tileSize = 512
    static let overlap = 32
    static let prePad = 10
    static let modelSize = tileSize + prePad

    let modelKind: Model
    private let model: MLModel
    private let inputName: String
    private let outputName: String

    init(model: Model, cleanup: Int = RealESRGAN.defaultCleanup) throws {
        self.modelKind = model
        let resourceName: String
        if model == .general, cleanup != Self.defaultCleanup, Self.cleanupSteps.contains(cleanup) {
            resourceName = "RealESRGAN_general_dn\(cleanup)_522_fp16"
        } else {
            resourceName = "RealESRGAN_\(model.rawValue)_522_fp16"
        }
        guard let url = Bundle.main.url(forResource: resourceName, withExtension: "mlmodelc") else {
            throw UpscaleError.modelMissing(tr("el modelo Real-ESRGAN \(model.displayName)", "the Real-ESRGAN \(model.displayName) model"))
        }

        let configuration = MLModelConfiguration()
        configuration.computeUnits = ComputePolicy.units

        do {
            self.model = try MLModel(contentsOf: url, configuration: configuration)
        } catch {
            throw UpscaleError.coreML(tr("No se pudo cargar \(model.displayName): \(error.localizedDescription)", "Could not load \(model.displayName): \(error.localizedDescription)"))
        }

        guard let input = self.model.modelDescription.inputDescriptionsByName.keys.first,
              let output = self.model.modelDescription.outputDescriptionsByName.keys.first else {
            throw UpscaleError.coreML(tr("No se encontraron las entradas/salidas del modelo.", "The model's inputs/outputs were not found."))
        }
        inputName = input
        outputName = output
    }

    func upscale(pixelBuffer: CVPixelBuffer, isCancelled: () -> Bool) throws -> CVPixelBuffer {
        let frame = try PixelBufferTools.rgbFloatArray(from: pixelBuffer)
        let values = try upscaleRGB(frame.values, width: frame.width, height: frame.height, isCancelled: isCancelled)
        return try PixelBufferTools.makeBGRA(
            values: values,
            width: frame.width * modelKind.scale,
            height: frame.height * modelKind.scale
        )
    }

    func upscale(cgImage: CGImage, allowLarge: Bool = false, isCancelled: () -> Bool) throws -> CGImage {
        if !allowLarge, Self.exceedsSafeLimit(width: cgImage.width, height: cgImage.height, scale: modelKind.scale) {
            throw UpscaleError.frameTooLarge(width: cgImage.width, height: cgImage.height)
        }
        let frame = try Self.rgbFloatArray(from: cgImage)
        let values = try upscaleRGB(frame.values, width: frame.width, height: frame.height, isCancelled: isCancelled)
        return try Self.makeCGImage(values: values, width: frame.width * modelKind.scale, height: frame.height * modelKind.scale)
    }

    private func tileStarts(total: Int) -> [Int] {
        guard total > Self.tileSize else { return [0] }
        let stride = Self.tileSize - Self.overlap
        var result: [Int] = []
        var position = 0
        while position < total {
            if position + Self.tileSize >= total {
                result.append(total - Self.tileSize)
                break
            }
            result.append(position)
            position += stride
        }
        return result
    }

    private func reflectIndex(_ index: Int, limit: Int) -> Int {
        guard limit > 1 else { return 0 }
        let period = 2 * (limit - 1)
        var value = index % period
        if value < 0 { value += period }
        if value >= limit { value = period - value }
        return value
    }

    private func makeModelInput(source: [Float], width: Int, height: Int, x0: Int, y0: Int, tileWidth: Int, tileHeight: Int) throws -> MLMultiArray {
        let prePaddedWidth = tileWidth + Self.prePad
        let prePaddedHeight = tileHeight + Self.prePad
        guard prePaddedWidth <= Self.modelSize, prePaddedHeight <= Self.modelSize else {
            throw UpscaleError.coreML(tr("El tile supera el tamaño de entrada del modelo.", "The tile exceeds the model's input size."))
        }

        let array = try MLMultiArray(shape: [1, 3, NSNumber(value: Self.modelSize), NSNumber(value: Self.modelSize)], dataType: .float32)
        let ptr = array.dataPointer.bindMemory(to: Float32.self, capacity: 3 * Self.modelSize * Self.modelSize)
        let plane = Self.modelSize * Self.modelSize

        for y in 0..<Self.modelSize {
            let py = reflectIndex(y, limit: prePaddedHeight)
            let sy = min(reflectIndex(py, limit: tileHeight), tileHeight - 1)
            for x in 0..<Self.modelSize {
                let px = reflectIndex(x, limit: prePaddedWidth)
                let sx = min(reflectIndex(px, limit: tileWidth), tileWidth - 1)
                let src = ((y0 + sy) * width + (x0 + sx)) * 3
                let dst = y * Self.modelSize + x
                ptr[dst] = source[src]
                ptr[plane + dst] = source[src + 1]
                ptr[2 * plane + dst] = source[src + 2]
            }
        }
        return array
    }

    private func predict(_ input: MLMultiArray) throws -> MLMultiArray {
        do {
            let provider = try MLDictionaryFeatureProvider(dictionary: [inputName: MLFeatureValue(multiArray: input)])
            let result = try model.prediction(from: provider)
            guard let output = result.featureValue(for: outputName)?.multiArrayValue else {
                throw UpscaleError.coreML(tr("El modelo no devolvió un MLMultiArray.", "The model did not return an MLMultiArray."))
            }
            return output
        } catch let error as UpscaleError {
            throw error
        } catch {
            throw UpscaleError.coreML(error.localizedDescription)
        }
    }

    private func readOutput(_ output: MLMultiArray) throws -> (values: [Float], width: Int, height: Int) {
        let shape = output.shape.map(\NSNumber.intValue)
        guard shape.count == 4, shape[0] == 1, shape[1] == 3 else {
            throw UpscaleError.coreML(tr("Forma de salida inesperada: \(output.shape)", "Unexpected output shape: \(output.shape)"))
        }
        let height = shape[2]
        let width = shape[3]
        let strides = output.strides.map(\NSNumber.intValue)
        guard height > 0, width > 0, strides.count == 4 else {
            throw UpscaleError.coreML(tr("Salida del modelo inválida.", "Invalid model output."))
        }

        let count = height * width
        var result = [Float](repeating: 0, count: count * 3)
        func offset(channel: Int, y: Int, x: Int) -> Int {
            channel * strides[1] + y * strides[2] + x * strides[3]
        }

        switch output.dataType {
        case .float32:
            let ptr = output.dataPointer.bindMemory(to: Float32.self, capacity: output.count)
            for y in 0..<height { for x in 0..<width {
                let dst = (y * width + x) * 3
                result[dst] = ptr[offset(channel: 0, y: y, x: x)]
                result[dst + 1] = ptr[offset(channel: 1, y: y, x: x)]
                result[dst + 2] = ptr[offset(channel: 2, y: y, x: x)]
            }}
        case .float16:
            let ptr = output.dataPointer.bindMemory(to: UInt16.self, capacity: output.count)
            for y in 0..<height { for x in 0..<width {
                let dst = (y * width + x) * 3
                result[dst] = Float(Float16(bitPattern: ptr[offset(channel: 0, y: y, x: x)]))
                result[dst + 1] = Float(Float16(bitPattern: ptr[offset(channel: 1, y: y, x: x)]))
                result[dst + 2] = Float(Float16(bitPattern: ptr[offset(channel: 2, y: y, x: x)]))
            }}
        default:
            throw UpscaleError.coreML(tr("Tipo de salida no compatible: \(output.dataType)", "Unsupported output type: \(output.dataType)"))
        }
        return (result, width, height)
    }

    private func upscaleRGB(_ source: [Float], width: Int, height: Int, isCancelled: () -> Bool) throws -> [Float] {
        let scale = modelKind.scale
        let outWidth = width * scale
        let outHeight = height * scale
        var accumulator = [Float](repeating: 0, count: outWidth * outHeight * 3)
        var weights = [Float](repeating: 0, count: outWidth * outHeight)

        for y0 in tileStarts(total: height) {
            for x0 in tileStarts(total: width) {
                if isCancelled() { throw UpscaleError.cancelled }
                let tileWidth = min(Self.tileSize, width - x0)
                let tileHeight = min(Self.tileSize, height - y0)
                let input = try makeModelInput(source: source, width: width, height: height, x0: x0, y0: y0, tileWidth: tileWidth, tileHeight: tileHeight)
                let output = try readOutput(try predict(input))

                guard output.width >= tileWidth * scale, output.height >= tileHeight * scale else {
                    throw UpscaleError.coreML(tr("El modelo devolvió un tamaño inesperado.", "The model returned an unexpected size."))
                }

                let edgeX = x0 > 0 ? Self.overlap * scale / 2 : 0
                let edgeY = y0 > 0 ? Self.overlap * scale / 2 : 0
                let endX = min(tileWidth * scale, output.width) - (x0 + tileWidth < width ? Self.overlap * scale / 2 : 0)
                let endY = min(tileHeight * scale, output.height) - (y0 + tileHeight < height ? Self.overlap * scale / 2 : 0)

                for oy in edgeY..<max(edgeY + 1, endY) {
                    let globalY = y0 * scale + oy
                    if globalY >= outHeight { continue }
                    for ox in edgeX..<max(edgeX + 1, endX) {
                        let globalX = x0 * scale + ox
                        if globalX >= outWidth { continue }
                        let centerX = Double(ox) / Double(max(tileWidth * scale - 1, 1))
                        let centerY = Double(oy) / Double(max(tileHeight * scale - 1, 1))
                        let wx = 0.5 - 0.5 * cos(2.0 * Double.pi * min(max(centerX, 0), 1))
                        let wy = 0.5 - 0.5 * cos(2.0 * Double.pi * min(max(centerY, 0), 1))
                        let weight = Float(max(wx * wy, 0.02))
                        let src = (oy * output.width + ox) * 3
                        let dstPixel = globalY * outWidth + globalX
                        let dst = dstPixel * 3
                        accumulator[dst] += output.values[src] * weight
                        accumulator[dst + 1] += output.values[src + 1] * weight
                        accumulator[dst + 2] += output.values[src + 2] * weight
                        weights[dstPixel] += weight
                    }
                }
            }
        }

        for i in 0..<weights.count {
            let weight = max(weights[i], 1e-8)
            accumulator[i * 3] /= weight
            accumulator[i * 3 + 1] /= weight
            accumulator[i * 3 + 2] /= weight
        }
        return accumulator
    }

    private static func rgbFloatArray(from image: CGImage) throws -> RGBFrame {
        let width = image.width
        let height = image.height
        var values = [Float](repeating: 0, count: width * height * 3)
        guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) else { throw UpscaleError.coreML(tr("No se pudo crear el espacio de color.", "Could not create the color space.")) }
        var rgba = [UInt8](repeating: 0, count: width * height * 4)
        guard let context = CGContext(data: &rgba, width: width, height: height, bitsPerComponent: 8, bytesPerRow: width * 4, space: colorSpace, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            throw UpscaleError.coreML(tr("No se pudo preparar la imagen.", "Could not prepare the image."))
        }
        context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
        for i in 0..<(width * height) {
            values[i * 3] = Float(rgba[i * 4]) / 255
            values[i * 3 + 1] = Float(rgba[i * 4 + 1]) / 255
            values[i * 3 + 2] = Float(rgba[i * 4 + 2]) / 255
        }
        return RGBFrame(values: values, width: width, height: height)
    }

    private static func makeCGImage(values: [Float], width: Int, height: Int) throws -> CGImage {
        var rgba = [UInt8](repeating: 255, count: width * height * 4)
        for i in 0..<(width * height) {
            rgba[i * 4] = toByte(values[i * 3])
            rgba[i * 4 + 1] = toByte(values[i * 3 + 1])
            rgba[i * 4 + 2] = toByte(values[i * 3 + 2])
        }
        guard let provider = CGDataProvider(data: Data(rgba) as CFData),
              let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
              let image = CGImage(width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: width * 4, space: colorSpace, bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue), provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent) else {
            throw UpscaleError.coreML(tr("No se pudo crear la imagen resultante.", "Could not create the resulting image."))
        }
        return image
    }

    private static func toByte(_ value: Float) -> UInt8 {
        UInt8((min(max(value, 0), 1) * 255).rounded())
    }
}
