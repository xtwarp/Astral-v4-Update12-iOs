import Foundation
import AVFoundation
import CoreVideo

/// Escalar + interpolar en dos pasos completos, uno después del otro:
/// 1) se escala todo el video con Real-ESRGAN y se guarda un archivo temporal;
/// 2) se interpola ese resultado con RIFE.
/// Los dos modelos nunca están cargados a la vez, así el iPhone trabaja con un solo modelo cada vez.
final class CombinedPipeline {
    private let lock = NSLock()
    private var cancelled = false
    private var upscaler: VideoProcessor?
    private var interpolator: InterpolationProcessor?

    /// Parte del progreso total que ocupa el primer paso (escalar suele ser el más pesado).
    private let upscaleShare = 0.6

    func cancel() {
        lock.lock(); cancelled = true; let up = upscaler; let inter = interpolator; lock.unlock()
        up?.cancel()
        inter?.cancel()
    }

    private func isCancelled() -> Bool {
        lock.lock(); defer { lock.unlock() }
        return cancelled
    }

    func run(
        inputURL: URL,
        timeRange: CMTimeRange?,
        model: RealESRGAN.Model,
        cleanup: Int = RealESRGAN.defaultCleanup,
        factor: Int,
        precision: RIFEInterpolator.Precision,
        exportShortSide: Int? = nil,
        slowMotion: Bool = false,
        keepHDR: Bool = false,
        progress: @escaping (Double, String) -> Void,
        framePreview: @escaping (CVPixelBuffer, Int) -> Void,
        completion: @escaping (Result<URL, Error>) -> Void
    ) {
        lock.lock(); cancelled = false; lock.unlock()

        let firstStep = VideoProcessor()
        lock.lock(); upscaler = firstStep; lock.unlock()
        let share = upscaleShare

        firstStep.process(
            inputURL: inputURL,
            timeRange: timeRange,
            model: model,
            cleanup: cleanup,
            keepHDR: keepHDR,
            progress: { value, text in
                progress(value * share, tr("Paso 1/2 · ", "Step 1/2 · ") + text)
            },
            framePreview: framePreview,
            completion: { [weak self] result in
                guard let self else { return }
                self.lock.lock(); self.upscaler = nil; self.lock.unlock()
                switch result {
                case .failure(let error):
                    completion(.failure(error))
                case .success(let upscaledURL):
                    if self.isCancelled() {
                        try? FileManager.default.removeItem(at: upscaledURL)
                        completion(.failure(UpscaleError.cancelled))
                        return
                    }
                    self.runSecondStep(upscaledURL: upscaledURL, factor: factor, precision: precision,
                                       exportShortSide: exportShortSide, slowMotion: slowMotion, keepHDR: keepHDR,
                                       progress: progress, framePreview: framePreview, completion: completion)
                }
            }
        )
    }

    private func runSecondStep(
        upscaledURL: URL,
        factor: Int,
        precision: RIFEInterpolator.Precision,
        exportShortSide: Int?,
        slowMotion: Bool,
        keepHDR: Bool,
        progress: @escaping (Double, String) -> Void,
        framePreview: @escaping (CVPixelBuffer, Int) -> Void,
        completion: @escaping (Result<URL, Error>) -> Void
    ) {
        let secondStep = InterpolationProcessor()
        lock.lock(); interpolator = secondStep; lock.unlock()
        let share = upscaleShare

        progress(share, tr("Paso 2/2 · Cargando interpolación ×\(factor)…", "Step 2/2 · Loading ×\(factor) interpolation…"))

        // El primer paso ya aplicó el recorte, por eso aquí se interpola el archivo completo.
        secondStep.process(
            inputURL: upscaledURL,
            timeRange: nil,
            factor: factor,
            precision: precision,
            upscaleModel: nil,
            exportShortSide: exportShortSide,
            slowMotion: slowMotion,
            keepHDR: keepHDR,
            progress: { value, text in
                progress(share + value * (1 - share), tr("Paso 2/2 · ", "Step 2/2 · ") + text)
            },
            framePreview: framePreview,
            completion: { [weak self] result in
                self?.lock.lock(); self?.interpolator = nil; self?.lock.unlock()
                try? FileManager.default.removeItem(at: upscaledURL)
                completion(result)
            }
        )
    }
}
