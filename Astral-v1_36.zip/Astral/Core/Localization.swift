import Foundation
import SwiftUI

/// Elige el texto según el idioma guardado. Es seguro llamarla desde cualquier hilo
/// (los procesadores de vídeo la usan para sus mensajes de progreso).
/// Español e inglés van en la propia llamada; el resto de idiomas se buscan en `Translations`
/// usando el texto en inglés (si no hay traducción, se muestra el inglés).
func tr(_ es: String, _ en: String) -> String {
    switch AppLanguage.current {
    case .es: return es
    case .en: return en
    case let other: return Translations.translate(en, to: other.rawValue)
    }
}

/// ¿`text` es ese mismo mensaje (es/en) en cualquiera de los idiomas de la app?
/// Sirve para reconocer los mensajes de estado "de reposo" al cambiar de idioma.
func isTr(_ text: String, _ es: String, _ en: String) -> Bool {
    if text == es || text == en { return true }
    return AppLanguage.allCases.contains { lang in
        lang != .es && lang != .en && Translations.translate(en, to: lang.rawValue) == text
    }
}

enum AppLanguage: String, CaseIterable, Identifiable {
    case es, en, pt, fr, de, it, ja, ko, zh
    var id: String { rawValue }

    /// Nombre del idioma en su propio idioma (así se reconoce aunque la app esté en otro).
    var displayName: String {
        switch self {
        case .es: return "Español"
        case .en: return "English"
        case .pt: return "Português"
        case .fr: return "Français"
        case .de: return "Deutsch"
        case .it: return "Italiano"
        case .ja: return "日本語"
        case .ko: return "한국어"
        case .zh: return "简体中文"
        }
    }

    /// Idioma del iPhone si la app lo tiene; si no, español.
    static var systemDefault: AppLanguage {
        for preferred in Locale.preferredLanguages {
            let code = String(preferred.prefix(2)).lowercased()
            // El chino de la app es el simplificado: con un iPhone en chino tradicional se sigue con el siguiente idioma.
            if code == "zh", preferred.contains("Hant") || preferred.contains("TW") || preferred.contains("HK") || preferred.contains("MO") { continue }
            if let match = AppLanguage(rawValue: code) { return match }
        }
        return .es
    }

    /// Idioma activo (guardado o, si aún no se eligió, el del sistema).
    static var current: AppLanguage {
        if let raw = UserDefaults.standard.string(forKey: "astral.language"), let saved = AppLanguage(rawValue: raw) {
            return saved
        }
        return systemDefault
    }
}

/// Guarda el idioma elegido y lo recuerda entre sesiones. No reinicia la app:
/// las vistas que observan `AppLanguageStore.shared` se redibujan solas al cambiarlo.
@MainActor
final class AppLanguageStore: ObservableObject {
    static let shared = AppLanguageStore()
    @Published var language: AppLanguage {
        didSet { UserDefaults.standard.set(language.rawValue, forKey: "astral.language") }
    }
    private init() {
        language = AppLanguage.current
    }
}

/// Textos fijos de la interfaz (pestañas, botones, títulos de sección, ajustes): español e inglés aquí y
/// el resto de idiomas en `Translations`. Los mensajes de estado y de error se traducen con `tr(es, en)`.
enum L: String {
    case tabImage, tabBackground, tabColor
    case settingsTitle, settingsLanguage
    case cacheTitle, cacheButton, cacheFootnote
    case cancelButton
    case selectVideo, selectImage
    case modelSectionTitle
    case interpolateFactorTitle, interpolateFactorFast, interpolateFactorSmooth
    case precisionTitle, precisionFast, precisionHigh
    case saveToFiles
    case selectVideoPlaceholderTitle
    case selectImagePlaceholderTitle
    case tryAnyway
    case deviceOnlyNote
    case beforeLabel, afterLabel

    private static let table: [L: (es: String, en: String)] = [
        .tabImage: ("IMAGEN", "IMAGE"),
        .tabBackground: ("ELIMINACIÓN DE FONDO", "BACKGROUND REMOVAL"),
        .tabColor: ("COLOR", "COLOR"),
        .settingsTitle: ("AJUSTES", "SETTINGS"),
        .settingsLanguage: ("IDIOMA", "LANGUAGE"),
        .cacheTitle: ("CACHÉ TEMPORAL", "TEMPORARY CACHE"),
        .cacheButton: ("Borrar caché", "Clear cache"),
        .cacheFootnote: (
            "Los resultados no se guardan solos, a menos que actives «Guardar en Fotos al terminar». Guarda tus resultados antes de borrar la caché.",
            "Results aren't saved automatically unless you turn on “Save to Photos when done”. Save your results before clearing the cache."
        ),
        .cancelButton: ("Cancelar", "Cancel"),
        .selectVideo: ("Seleccionar video", "Select video"),
        .selectImage: ("Seleccionar imagen", "Select image"),
        .modelSectionTitle: ("MODELO", "MODEL"),
        .interpolateFactorTitle: ("FACTOR DE INTERPOLACIÓN", "INTERPOLATION FACTOR"),
        .interpolateFactorFast: ("más rápido", "faster"),
        .interpolateFactorSmooth: ("más fluido", "smoother"),
        .precisionTitle: ("PRECISIÓN", "PRECISION"),
        .precisionFast: ("Rápida", "Fast"),
        .precisionHigh: ("Alta", "High"),
        .saveToFiles: ("Guardar en Archivos", "Save to Files"),
        .selectVideoPlaceholderTitle: ("Selecciona un video", "Select a video"),
        .selectImagePlaceholderTitle: ("Selecciona una imagen", "Select an image"),
        .tryAnyway: ("Intentar de todos modos", "Try anyway"),
        .deviceOnlyNote: ("Todo se procesa en el dispositivo", "Everything is processed on your device"),
        .beforeLabel: ("ANTES", "BEFORE"),
        .afterLabel: ("DESPUÉS", "AFTER"),
    ]

    @MainActor
    var text: String {
        guard let pair = Self.table[self] else { return rawValue }
        switch AppLanguageStore.shared.language {
        case .es: return pair.es
        case .en: return pair.en
        case let other: return Translations.translate(pair.en, to: other.rawValue)
        }
    }
}
