import Foundation
import SwiftUI
import PhotosUI
import CoreImage
import CoreVideo
import AVFoundation
import UIKit

/// Qué hace la pestaña "Mejora de video". Se elige en el menú desplegable.
enum EnhanceMode: String, CaseIterable, Identifiable {
    case quality, fps, both
    var id: String { rawValue }

    var title: String {
        switch self {
        case .quality: return tr("Mejorar calidad", "Improve quality")
        case .fps: return tr("Aumentar fps", "Raise fps")
        case .both: return tr("Mejorar calidad y Aumentar fps", "Improve quality and Raise fps")
        }
    }

    var icon: String {
        switch self {
        case .quality: return "sparkles"
        case .fps: return "film.stack"
        case .both: return "sparkles.rectangle.stack"
        }
    }
}

/// Pestaña "Mejora de video": junta el escalado (Real-ESRGAN) y la interpolación (RIFE) en un solo flujo.
/// - Solo "Mejorar calidad"  → VideoProcessor
/// - Solo "Aumentar fps"     → InterpolationProcessor
/// - Ambas                   → CombinedPipeline (primero escala todo el video y luego interpola ese resultado)
@MainActor
final class EnhanceViewModel: ObservableObject {
    @Published var inputURL: URL?
    @Published var outputURL: URL?
    @Published var progress: Double = 0 {
        didSet { reportContinuationProgress() }
    }
    @Published var status = tr("Selecciona un video", "Select a video")
    @Published var isProcessing = false {
        didSet {
            guard oldValue, !isProcessing, !isBatchRunning else { return }
            // Se comprueba en el siguiente turno: el resultado se asigna justo después de apagar isProcessing.
            DispatchQueue.main.async { [weak self] in
                guard let self, !self.isProcessing, !self.isBatchRunning else { return }
                BackgroundContinuation.shared.end(success: self.outputURL != nil)
            }
        }
    }
    @Published var liveFrame: CGImage?
    @Published var liveFrameNumber = 0

    // Qué se hace. nil = todavía no eligió: no se muestran opciones ni se puede comenzar.
    @Published var mode: EnhanceMode?
    var doUpscale: Bool { mode == .quality || mode == .both }
    var doInterpolate: Bool { mode == .fps || mode == .both }

    // Opciones de "Mejorar calidad"
    @Published var selectedModel: RealESRGAN.Model = .general

    // Opciones de "Aumentar fps"
    @Published var factor = 2
    @Published var precision: RIFEInterpolator.Precision = .fp16
    @Published var slowMotion = false

    // Común
    @Published var exportQuality: ExportQuality = .automatic
    /// Exportar en HDR (solo tiene efecto si el video original es HDR).
    @Published var keepHDR = false
    /// Intensidad de limpieza del modelo General (0, 25, 50, 75 o 100 %).
    @Published var cleanupStrength = RealESRGAN.defaultCleanup

    /// Trabajo guardado de una sesión anterior que se puede reanudar (nil = no hay).
    @Published var pendingJob: ResumeJob?
    /// El procesamiento está en pausa porque la app pasó a segundo plano; continúa solo al volver.
    @Published var isPausedInBackground = false

    @Published var resultTrimStart: Double = 0
    /// Factor de cámara lenta del resultado actual (1 = sin cámara lenta). Lo usa el comparador antes/después.
    @Published var resultSlowFactor: Int = 1

    // Datos del video elegido (para la línea "Resultado")
    @Published var sourceWidth = 0
    @Published var sourceHeight = 0
    @Published var sourceFps: Double = 0

    @Published var videoDuration: Double = 0
    @Published var trimStart: Double = 0
    @Published var trimEnd: Double = 0

    /// nil = vídeo completo.
    var trimRange: CMTimeRange? {
        guard videoDuration > 0, trimEnd > trimStart,
              trimStart > 0.05 || trimEnd < videoDuration - 0.05 else { return nil }
        return CMTimeRange(
            start: CMTime(seconds: trimStart, preferredTimescale: 600),
            duration: CMTime(seconds: trimEnd - trimStart, preferredTimescale: 600)
        )
    }

    // MARK: - Resultado esperado

    /// Cámara lenta solo existe junto con "Aumentar fps".
    private var effectiveSlowMotion: Bool { doInterpolate && slowMotion }

    /// El modelo elegido no puede con un video tan grande (se calcula antes de empezar).
    var isTooLarge: Bool {
        doUpscale && sourceWidth > 0
            && RealESRGAN.exceedsSafeLimit(width: sourceWidth, height: sourceHeight, scale: selectedModel.scale)
    }

    /// Tamaño final del archivo exportado, o nil si aún no se conoce el video.
    var resultSize: (width: Int, height: Int)? {
        guard mode != nil, sourceWidth > 0, sourceHeight > 0 else { return nil }
        var width = sourceWidth
        var height = sourceHeight
        if doUpscale {
            width *= selectedModel.scale
            height *= selectedModel.scale
        }
        let shortSide = exportQuality.shortSide(sourceShortSide: min(sourceWidth, sourceHeight))
        return ExportQuality.fittedSize(width: width, height: height, shortSide: shortSide)
    }

    /// fps del archivo exportado. En cámara lenta los fps se mantienen y es la duración la que crece.
    var resultFps: Double {
        guard sourceFps > 0 else { return 0 }
        if doInterpolate && !slowMotion { return sourceFps * Double(factor) }
        return sourceFps
    }

    private static func fpsText(_ value: Double) -> String {
        if abs(value - value.rounded()) < 0.05 { return "\(Int(value.rounded())) fps" }
        return String(format: "%.2f fps", value)
    }

    /// Ejemplo: "Resultado: 2560×1440 · 60 fps". nil si todavía no hay video.
    var resultSummary: String? {
        guard mode != nil else { return nil }
        if isTooLarge { return tr("Demasiado grande para este modelo", "Too large for this model") }
        guard let size = resultSize, sourceFps > 0 else { return nil }
        var text = tr("Resultado", "Result") + ": \(size.width)×\(size.height) · " + Self.fpsText(resultFps)
        if effectiveSlowMotion { text += " · " + tr("dura ×\(factor)", "lasts ×\(factor)") }
        return text
    }

    // MARK: - Carga del video

    private func loadMetadata(of url: URL) async {
        let asset = AVURLAsset(url: url)
        let seconds = (try? await asset.load(.duration)).map { CMTimeGetSeconds($0) } ?? 0
        videoDuration = seconds.isFinite ? max(seconds, 0) : 0
        trimStart = 0
        trimEnd = videoDuration

        sourceWidth = 0
        sourceHeight = 0
        sourceFps = 0
        let tracks = (try? await asset.loadTracks(withMediaType: .video)) ?? []
        guard let track = tracks.first else { return }
        let size = (try? await track.load(.naturalSize)) ?? .zero
        let transform = (try? await track.load(.preferredTransform)) ?? .identity
        let nominal = (try? await track.load(.nominalFrameRate)) ?? 0
        // Con la rotación aplicada: así coincide con lo que se ve en Fotos.
        let rotated = size.applying(transform)
        sourceWidth = Int(abs(rotated.width).rounded())
        sourceHeight = Int(abs(rotated.height).rounded())
        sourceFps = nominal > 0 ? Double(nominal) : 24
    }

    init() {
        pendingJob = ResumeStore.loadPending()
    }

    private struct ActiveRun {
        var job: ResumeJob
        var inputURL: URL
        var persistent: Bool
        var segmentURLs: [URL]
    }
    private var activeRun: ActiveRun?
    private var runCancelled = false
    private var pausedByBackground = false
    private var isPreparing = false
    private var isStitching = false
    /// Cada parte lleva un número: las respuestas de partes ya canceladas o pausadas se ignoran.
    private var segmentToken = 0

    private var processor: VideoProcessor?
    private var interpolator: InterpolationProcessor?
    private var pipeline: CombinedPipeline?
    private let previewContext = CIContext(options: [.cacheIntermediates: false])

    @Published var batchTotal = 0
    @Published var batchIndex = 0
    @Published var batchResults: [URL] = []
    @Published var batchFailures = 0
    @Published var isBatchRunning = false
    private var batchCancelled = false

    /// Procesa varios vídeos uno tras otro con los ajustes actuales.
    func startBatch(_ items: [PhotosPickerItem]) {
        guard !items.isEmpty, !isProcessing, !isBatchRunning else { return }
        isBatchRunning = true
        batchCancelled = false
        batchTotal = items.count
        batchIndex = 0
        batchResults = []
        batchFailures = 0
        UIApplication.shared.isIdleTimerDisabled = true
        beginContinuationIfNeeded()
        Task {
            for (offset, item) in items.enumerated() {
                if batchCancelled { break }
                batchIndex = offset + 1
                let previous = inputURL
                await importVideo(from: item)
                if batchCancelled { break }
                guard let current = inputURL, current != previous else { batchFailures += 1; continue }
                start()
                while isProcessing { try? await Task.sleep(nanoseconds: 300_000_000) }
                if let output = outputURL {
                    batchResults.append(output)
                } else if !batchCancelled {
                    batchFailures += 1
                }
            }
            isBatchRunning = false
            UIApplication.shared.isIdleTimerDisabled = false
            BackgroundContinuation.shared.end(success: batchFailures < batchTotal)
        }
    }

    func importVideo(from item: PhotosPickerItem) async {
        guard !isProcessing else { return }
        status = tr("Cargando video…", "Loading video…")
        do {
            let imported = try await item.loadTransferable(type: ImportedMovie.self)
            guard let imported else { status = tr("No se pudo cargar el video", "Could not load the video"); return }
            let previousInput = inputURL
            inputURL = imported.url
            if previousInput != imported.url { CacheManager.removeIfTemporary(previousInput) }
            outputURL = nil
            liveFrame = nil
            liveFrameNumber = 0
            progress = 0
            await loadMetadata(of: imported.url)
            status = tr("Video seleccionado", "Video selected")
        } catch {
            status = tr("No se pudo cargar el video: \(error.localizedDescription)", "Could not load the video: \(error.localizedDescription)")
        }
    }

    // MARK: - Procesamiento

    func start() {
        guard let sourceURL = inputURL, !isProcessing, mode != nil else { return }
        guard !isTooLarge else { status = resultSummary ?? ""; return }

        let slow = effectiveSlowMotion
        let shortSide = exportQuality.shortSide(sourceShortSide: min(sourceWidth, sourceHeight))
        let range = trimRange
        let rangeStart = range.map { CMTimeGetSeconds($0.start) } ?? 0
        let rangeEnd = range.map { CMTimeGetSeconds(CMTimeRangeGetEnd($0)) } ?? videoDuration
        let total = max(rangeEnd - rangeStart, 0)

        // Aviso de poco espacio antes de empezar (el resultado dura más si es cámara lenta).
        if let size = resultSize, let free = DiskSpace.availableBytes() {
            let inputBytes = Int64((try? sourceURL.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
            let need = DiskSpace.estimatedNeed(
                width: size.width, height: size.height, outputSeconds: total * (slow ? Double(factor) : 1),
                interpolating: doInterpolate, parts: total > 0 ? ResumeJob.segmentCount(for: total) : 1, inputBytes: inputBytes
            )
            if free < need {
                let needText = DiskSpace.text(need)
                let freeText = DiskSpace.text(free)
                status = tr(
                    "Espacio insuficiente: este video necesita unos \(needText) libres y tu iPhone tiene \(freeText). Libera espacio o borra la caché y vuelve a intentarlo.",
                    "Not enough free space: this video needs about \(needText) free and your iPhone has \(freeText). Free up some space or clear the cache, then try again."
                )
                return
            }
        }

        resultTrimStart = rangeStart
        resultSlowFactor = slow ? factor : 1
        isProcessing = true
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        progress = 0
        runCancelled = false
        pausedByBackground = false
        isPausedInBackground = false
        beginContinuationIfNeeded()

        let job = ResumeJob(
            id: UUID().uuidString, inputFile: "",
            rangeStart: rangeStart, rangeEnd: rangeEnd,
            segmentCount: total > 0 ? ResumeJob.segmentCount(for: total) : 1, doneSegments: 0,
            upscale: doUpscale, interpolate: doInterpolate, slowMotion: slow,
            modelRaw: selectedModel.rawValue, factor: factor, precisionRaw: precision.rawValue,
            exportQualityRaw: exportQuality.rawValue, exportShortSide: shortSide, keepHDR: keepHDR,
            sourceFps: sourceFps, sourceWidth: sourceWidth, sourceHeight: sourceHeight,
            videoDuration: videoDuration, trimmed: range != nil, cleanup: cleanupStrength
        )
        activeRun = ActiveRun(job: job, inputURL: sourceURL, persistent: false, segmentURLs: [])

        guard job.segmentCount > 1 else { runSegment(); return }

        // Video largo: se trabaja por partes y se guarda una copia del original para poder reanudar.
        isPreparing = true
        status = tr("Preparando vídeo…", "Preparing video…")
        Task {
            let name = await Task.detached(priority: .userInitiated) {
                ResumeStore.prepare(job: job, copying: sourceURL)
            }.value
            isPreparing = false
            if runCancelled {
                ResumeStore.clear(job.id)
                finishCancelled()
                return
            }
            if let name, var run = activeRun {
                run.job.inputFile = name
                run.inputURL = ResumeStore.inputURL(run.job)
                run.persistent = true
                activeRun = run
                ResumeStore.save(run.job)
            }
            runSegment()
        }
    }

    private func makePreviewHandler() -> (CVPixelBuffer, Int) -> Void {
        return { [weak self] pixelBuffer, frameNumber in
            guard let self else { return }
            // Con la app en segundo plano no se dibuja la vista previa (nadie la ve y no hay GPU).
            guard ComputePolicy.allowGPU else { return }
            autoreleasepool {
                let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
                let maxDimension: CGFloat = 900
                let longest = max(ciImage.extent.width, ciImage.extent.height)
                let scale = min(1, maxDimension / max(longest, 1))
                let previewImage = scale < 1 ? ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale)) : ciImage
                if let cg = self.previewContext.createCGImage(previewImage, from: previewImage.extent) {
                    DispatchQueue.main.async {
                        self.liveFrame = cg
                        self.liveFrameNumber = frameNumber
                    }
                }
            }
        }
    }

    /// Procesa la parte que toca (la siguiente a la última completada).
    private func runSegment() {
        guard let run = activeRun else { return }
        let job = run.job
        let index = job.doneSegments
        let count = job.segmentCount
        segmentToken += 1
        let token = segmentToken

        let range = job.timeRange(forSegment: index)
        let model = RealESRGAN.Model(rawValue: job.modelRaw) ?? selectedModel
        let chosenPrecision = RIFEInterpolator.Precision(rawValue: job.precisionRaw) ?? .fp16
        let prefix = count > 1 ? tr("Parte \(index + 1)/\(count) · ", "Part \(index + 1)/\(count) · ") : ""

        let progressHandler: (Double, String) -> Void = { [weak self] value, text in
            DispatchQueue.main.async {
                guard let self, self.segmentToken == token else { return }
                self.progress = (Double(index) + value) / Double(count)
                self.status = prefix + text
            }
        }
        let completionHandler: (Result<URL, Error>) -> Void = { [weak self] result in
            DispatchQueue.main.async { self?.segmentFinished(result, token: token) }
        }
        let previewHandler = makePreviewHandler()

        if job.upscale && job.interpolate {
            status = prefix + tr("Paso 1/2 · Cargando \(model.displayName)…", "Step 1/2 · Loading \(model.displayName)…")
            let pipeline = CombinedPipeline()
            self.pipeline = pipeline
            pipeline.run(
                inputURL: run.inputURL,
                timeRange: range,
                model: model,
                cleanup: job.cleanup ?? RealESRGAN.defaultCleanup,
                factor: job.factor,
                precision: chosenPrecision,
                exportShortSide: job.exportShortSide,
                slowMotion: job.slowMotion,
                keepHDR: job.keepHDR,
                progress: progressHandler,
                framePreview: previewHandler,
                completion: completionHandler
            )
        } else if job.upscale {
            status = prefix + tr("Cargando \(model.displayName)…", "Loading \(model.displayName)…")
            let processor = VideoProcessor()
            self.processor = processor
            processor.process(
                inputURL: run.inputURL,
                timeRange: range,
                model: model,
                cleanup: job.cleanup ?? RealESRGAN.defaultCleanup,
                exportShortSide: job.exportShortSide,
                keepHDR: job.keepHDR,
                progress: progressHandler,
                framePreview: previewHandler,
                completion: completionHandler
            )
        } else {
            status = prefix + tr("Cargando interpolación ×\(job.factor)…", "Loading ×\(job.factor) interpolation…")
            let interpolator = InterpolationProcessor()
            self.interpolator = interpolator
            interpolator.process(
                inputURL: run.inputURL,
                timeRange: range,
                factor: job.factor,
                precision: chosenPrecision,
                upscaleModel: nil,
                exportShortSide: job.exportShortSide,
                slowMotion: job.slowMotion,
                keepHDR: job.keepHDR,
                progress: progressHandler,
                framePreview: previewHandler,
                completion: completionHandler
            )
        }
    }

    private func segmentFinished(_ result: Result<URL, Error>, token: Int) {
        // Respuesta de una parte que ya se canceló o se pausó: se descarta.
        guard token == segmentToken, var run = activeRun else {
            if case .success(let url) = result { try? FileManager.default.removeItem(at: url) }
            return
        }
        processor = nil
        interpolator = nil
        pipeline = nil

        switch result {
        case .success(let url):
            if runCancelled {
                try? FileManager.default.removeItem(at: url)
                finishCancelled()
                return
            }
            if run.job.segmentCount == 1 {
                completeRun(with: url)
                return
            }
            // Parte terminada: se guarda en la carpeta del trabajo y se anota el avance.
            let index = run.job.doneSegments
            let destination = ResumeStore.segmentURL(run.job, index)
            try? FileManager.default.removeItem(at: destination)
            do {
                try FileManager.default.moveItem(at: url, to: destination)
            } catch {
                do {
                    try FileManager.default.copyItem(at: url, to: destination)
                    try? FileManager.default.removeItem(at: url)
                } catch {
                    failRun(error)
                    return
                }
            }
            run.job.doneSegments = index + 1
            run.segmentURLs.append(destination)
            activeRun = run
            if run.persistent { ResumeStore.save(run.job) }
            progress = Double(run.job.doneSegments) / Double(run.job.segmentCount)
            if run.job.doneSegments >= run.job.segmentCount {
                stitchAndFinish()
            } else {
                runSegment()
            }
        case .failure(let error):
            if runCancelled {
                finishCancelled()
            } else {
                failRun(error)
            }
        }
    }

    private func stitchAndFinish() {
        guard let run = activeRun else { return }
        isStitching = true
        progress = 0.99
        status = tr("Uniendo las partes…", "Joining the parts…")
        let job = run.job
        let urls = run.segmentURLs
        let input = run.inputURL
        Task {
            do {
                let output = try await SegmentStitcher.stitch(job: job, segmentURLs: urls, inputURL: input)
                isStitching = false
                completeRun(with: output)
            } catch {
                isStitching = false
                // Las partes siguen guardadas: se puede intentar de nuevo con "Reanudar".
                if run.persistent { pendingJob = ResumeStore.loadPending() }
                activeRun = nil
                isProcessing = false
                status = error.localizedDescription
            }
        }
    }

    private func completeRun(with url: URL) {
        if let run = activeRun, run.persistent { ResumeStore.clear(run.job.id) }
        activeRun = nil
        isProcessing = false
        isPausedInBackground = false
        outputURL = url
        status = tr("Listo — usa Guardar en Archivos para exportar", "Done — use Save to Files to export")
        autoSaveToPhotos(url)
    }

    private func failRun(_ error: Error) {
        if let run = activeRun, run.persistent { ResumeStore.clear(run.job.id) }
        activeRun = nil
        isProcessing = false
        isPausedInBackground = false
        status = error.localizedDescription
    }

    private func finishCancelled() {
        if let run = activeRun, run.persistent { ResumeStore.clear(run.job.id) }
        activeRun = nil
        isProcessing = false
        isPausedInBackground = false
        pausedByBackground = false
        status = UpscaleError.cancelled.localizedDescription
    }

    // MARK: - Pausa al salir de la app y reanudar

    /// iOS no deja usar la GPU con la app en segundo plano: se pausa de forma ordenada y se continúa al volver.
    func pauseForBackground() {
        guard isProcessing, activeRun != nil, !pausedByBackground, !isPreparing, !isStitching else { return }
        pausedByBackground = true
        segmentToken += 1
        processor?.cancel()
        interpolator?.cancel()
        pipeline?.cancel()
        processor = nil
        interpolator = nil
        pipeline = nil
        isPausedInBackground = true
        status = tr("En pausa — vuelve a Astral para continuar", "Paused — come back to Astral to continue")
        NotificationManager.notifyPaused()
    }

    func resumeAfterBackground() {
        guard pausedByBackground, activeRun != nil else { return }
        pausedByBackground = false
        isPausedInBackground = false
        beginContinuationIfNeeded()
        runSegment()
    }

    // MARK: - Segundo plano (iOS 26 o posterior)

    private var isInBackground = false

    /// La app pasa a segundo plano.
    /// - Si iOS aceptó la tarea de procesamiento continuo: el trabajo sigue, sin GPU (CPU + Neural Engine).
    ///   La parte en curso se reinicia con esa configuración (como mucho se repiten unos 15 s de video).
    /// - Si no (iOS anterior, tarea rechazada…): se pausa como siempre y se retoma al volver.
    func sceneEnteredBackground() {
        isInBackground = true
        let continues = BackgroundContinuation.shared.isActive
        if continues { ComputePolicy.allowGPU = false }
        guard isProcessing, activeRun != nil, !pausedByBackground, !isPreparing, !isStitching else { return }
        if continues {
            restartCurrentSegment()
        } else {
            pauseForBackground()
        }
    }

    /// La app vuelve a primer plano: la GPU se puede usar otra vez (desde la siguiente parte) y se reanuda si estaba en pausa.
    func sceneBecameActive() {
        isInBackground = false
        ComputePolicy.allowGPU = true
        resumeAfterBackground()
    }

    private func restartCurrentSegment() {
        segmentToken += 1
        processor?.cancel()
        interpolator?.cancel()
        pipeline?.cancel()
        processor = nil
        interpolator = nil
        pipeline = nil
        runSegment()
    }

    /// Pide a iOS que deje terminar el trabajo con la app en segundo plano (muestra su propia barra de progreso).
    private func beginContinuationIfNeeded() {
        BackgroundContinuation.shared.begin(
            title: isBatchRunning ? tr("Procesando tu lote de videos", "Processing your video batch") : tr("Mejorando tu video", "Enhancing your video"),
            subtitle: tr("Sigue trabajando en segundo plano", "Still working in the background")
        ) { [weak self] in
            // iOS terminó la tarea (tiempo, batería, el usuario la detuvo…): se pausa de forma ordenada para retomar al volver.
            guard let self, self.isInBackground else { return }
            self.pauseForBackground()
        }
    }

    private func reportContinuationProgress() {
        let overall: Double
        if isBatchRunning, batchTotal > 0 {
            overall = (Double(max(batchIndex - 1, 0)) + progress) / Double(batchTotal)
        } else {
            overall = progress
        }
        BackgroundContinuation.shared.report(overall)
    }

    /// Continúa un trabajo guardado de una sesión anterior desde la última parte completada.
    func resumePending() {
        guard let job = pendingJob, !isProcessing, !isBatchRunning else { return }
        let input = ResumeStore.inputURL(job)
        guard FileManager.default.fileExists(atPath: input.path) else {
            ResumeStore.clear(job.id)
            pendingJob = nil
            return
        }
        let previous = inputURL
        inputURL = input
        if previous != input { CacheManager.removeIfTemporary(previous) }
        let restoredMode: EnhanceMode = job.upscale && job.interpolate ? .both : (job.upscale ? .quality : .fps)
        mode = restoredMode
        selectedModel = RealESRGAN.Model(rawValue: job.modelRaw) ?? selectedModel
        factor = job.factor
        precision = RIFEInterpolator.Precision(rawValue: job.precisionRaw) ?? .fp16
        slowMotion = job.slowMotion
        exportQuality = ExportQuality(rawValue: job.exportQualityRaw) ?? .automatic
        keepHDR = job.keepHDR
        cleanupStrength = job.cleanup ?? RealESRGAN.defaultCleanup
        sourceWidth = job.sourceWidth
        sourceHeight = job.sourceHeight
        sourceFps = job.sourceFps
        videoDuration = job.videoDuration
        trimStart = job.rangeStart
        trimEnd = job.rangeEnd
        resultTrimStart = job.rangeStart
        resultSlowFactor = job.slowMotion ? job.factor : 1
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        pendingJob = nil
        isProcessing = true
        runCancelled = false
        pausedByBackground = false
        isPausedInBackground = false
        beginContinuationIfNeeded()
        progress = Double(job.doneSegments) / Double(job.segmentCount)
        let done = (0..<job.doneSegments).map { ResumeStore.segmentURL(job, $0) }
        activeRun = ActiveRun(job: job, inputURL: input, persistent: true, segmentURLs: done)
        if job.doneSegments >= job.segmentCount { stitchAndFinish() } else { runSegment() }
    }

    func discardPending() {
        if let job = pendingJob { ResumeStore.clear(job.id) }
        pendingJob = nil
    }

    /// Si "Guardar en Fotos al terminar" está activo, guarda el resultado (también en lotes, que procesan con start()).
    private func autoSaveToPhotos(_ url: URL) {
        guard AutoSave.isOn else { return }
        Task {
            do {
                try await PhotoSaver.saveVideo(at: url)
                if outputURL == url { status = tr("Listo — guardado en Fotos", "Done — saved to Photos") }
            } catch {
                if outputURL == url { status = error.localizedDescription }
            }
        }
    }

    func cancel() {
        guard !isStitching else { return }
        if isBatchRunning { batchCancelled = true }
        runCancelled = true
        status = tr("Cancelando…", "Cancelling…")
        processor?.cancel()
        interpolator?.cancel()
        pipeline?.cancel()
        if isPreparing { return }   // la tarea de preparación termina el trabajo
        if processor == nil && interpolator == nil && pipeline == nil && activeRun != nil {
            // En pausa: no hay nada en marcha que avise, se cierra aquí.
            finishCancelled()
        }
    }

    func relocalizeIdleStatus() {
        guard !isProcessing else { return }
        if isTr(status, "Selecciona un video", "Select a video") { status = tr("Selecciona un video", "Select a video") }
        if isTr(status, "Video seleccionado", "Video selected") { status = tr("Video seleccionado", "Video selected") }
    }

    // MARK: - Presets

    func makeSection() -> EnhanceSection {
        EnhanceSection(doUpscale: doUpscale, doInterpolate: doInterpolate, modelRaw: selectedModel.rawValue,
                       factor: factor, precisionRaw: precision.rawValue, slowMotion: slowMotion,
                       exportQualityRaw: exportQuality.rawValue, cleanup: cleanupStrength)
    }

    func apply(_ section: EnhanceSection) {
        guard !isProcessing, !isBatchRunning else { return }
        if let model = RealESRGAN.Model(rawValue: section.modelRaw), RealESRGAN.Model.videoModels.contains(model) { selectedModel = model }
        switch (section.doUpscale, section.doInterpolate) {
        case (true, true): mode = .both
        case (true, false): mode = .quality
        case (false, true): mode = .fps
        default: mode = nil
        }
        factor = [2, 4].contains(section.factor) ? section.factor : 2
        precision = RIFEInterpolator.Precision(rawValue: section.precisionRaw) ?? .fp16
        slowMotion = section.slowMotion
        exportQuality = ExportQuality(rawValue: section.exportQualityRaw) ?? .automatic
        cleanupStrength = RealESRGAN.cleanupSteps.contains(section.cleanup ?? 0) && section.cleanup != nil ? section.cleanup! : RealESRGAN.defaultCleanup
    }
}
