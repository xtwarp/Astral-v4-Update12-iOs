import SwiftUI

/// Política de privacidad en lenguaje sencillo. Se abre desde la bienvenida y desde Ajustes.
struct PrivacyPolicyView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var themeStore = ThemeStore.shared
    @ObservedObject private var languageStore = AppLanguageStore.shared

    private struct PolicySection: Identifiable {
        let id = UUID()
        let title: String
        let body: String
    }

    private var sections: [PolicySection] {
        [
            PolicySection(
                title: tr("Resumen", "Summary"),
                body: tr("Astral procesa todo en tu dispositivo. Tus videos y fotos no se suben a ningún servidor y la app no recopila datos personales.",
                         "Astral processes everything on your device. Your videos and photos are not uploaded to any server and the app does not collect personal data.")
            ),
            PolicySection(
                title: tr("Qué usa la app", "What the app uses"),
                body: tr("Los videos y fotos que eliges para procesar, los resultados que genera y tus ajustes (tema, idioma, presets y, si los activas, guardar en Fotos y las notificaciones). Todo se guarda solo en tu iPhone.",
                         "The videos and photos you choose to process, the results it creates, and your settings (theme, language, presets and, if you turn them on, saving to Photos and notifications). Everything is stored only on your iPhone.")
            ),
            PolicySection(
                title: tr("Qué no hace", "What it doesn't do"),
                body: tr("No sube tus archivos a internet, no pide cuenta ni registro, no usa analíticas ni rastreo, no muestra anuncios y no comparte información con terceros.",
                         "It doesn't upload your files to the internet, doesn't ask for an account or sign-up, doesn't use analytics or tracking, doesn't show ads and doesn't share information with third parties.")
            ),
            PolicySection(
                title: tr("Permisos de Fotos", "Photos permissions"),
                body: tr("Para elegir fotos y videos, Astral usa el selector de iOS, así que solo recibe lo que tú seleccionas. Para guardar un resultado en Fotos, iOS te pide permiso únicamente para añadir contenido.",
                         "To choose photos and videos, Astral uses the iOS picker, so it only receives what you select. To save a result to Photos, iOS asks for permission to add content only.")
            ),
            PolicySection(
                title: tr("Notificaciones", "Notifications"),
                body: tr("Son opcionales. Si las activas en Ajustes, la app muestra avisos locales (por ejemplo, cuando termina de procesar). Se generan en tu iPhone, sin ningún servidor, y puedes desactivarlas cuando quieras.",
                         "They are optional. If you turn them on in Settings, the app shows local alerts (for example, when processing finishes). They are generated on your iPhone, without any server, and you can turn them off at any time.")
            ),
            PolicySection(
                title: tr("Dónde quedan tus archivos", "Where your files stay"),
                body: tr("Los resultados se guardan en la carpeta de la app en tu iPhone y puedes exportarlos a Fotos o Archivos cuando quieras. Si un video largo se interrumpe, la app conserva en su almacenamiento una copia del original y las partes ya procesadas hasta que lo reanudes, lo descartes o termine. En Ajustes puedes borrar la caché y los resultados guardados. Si desinstalas la app, se borra todo lo que guardó.",
                         "Results are stored in the app's folder on your iPhone, and you can export them to Photos or Files whenever you like. If a long video is interrupted, the app keeps a copy of the original and the parts already processed in its storage until you resume, discard it, or it finishes. In Settings you can clear the cache and the saved results. If you uninstall the app, everything it stored is deleted.")
            ),
            PolicySection(
                title: tr("Modelos de IA", "AI models"),
                body: tr("Los modelos vienen incluidos en la app y funcionan sin conexión. Sus autores y licencias aparecen en Ajustes › Créditos y licencias.",
                         "The models come included in the app and work offline. Their authors and licenses appear in Settings › Credits & licenses.")
            ),
            PolicySection(
                title: tr("Contacto", "Contact"),
                body: tr("Si me escribes a astralapp@proton.me, recibiré tu mensaje y tu dirección de correo. Los uso solo para responderte.",
                         "If you write to astralapp@proton.me, I will receive your message and your email address. I use them only to reply to you.")
            ),
            PolicySection(
                title: tr("Cambios", "Changes"),
                body: tr("Si esta política cambia, se actualizará aquí dentro de la app.",
                         "If this policy changes, it will be updated here inside the app.")
            )
        ]
    }

    var body: some View {
        ZStack {
            NeonBackground().ignoresSafeArea()
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text(tr("POLÍTICA DE PRIVACIDAD", "PRIVACY POLICY"))
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(Theme.ink(0.6))
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(Theme.ink(0.7))
                            .frame(width: 34, height: 34)
                            .background(Theme.fill(0.055), in: Circle())
                    }
                }
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 10) {
                        ForEach(sections) { section in
                            VStack(alignment: .leading, spacing: 5) {
                                Text(section.title)
                                    .font(.system(size: 14, weight: .bold, design: .rounded))
                                    .foregroundStyle(LocalStyle.mint)
                                Text(section.body)
                                    .font(.system(size: 13.5, weight: .regular, design: .rounded))
                                    .foregroundStyle(Theme.ink(0.8))
                                    .lineSpacing(2)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            .padding(14)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
                        }

                    }
                    .padding(.bottom, 12)
                }
            }
            .padding(16)
        }
        .preferredColorScheme(themeStore.theme.palette.scheme)
    }
}
