import SwiftUI

@main
struct RealESRGANVideoUpscalerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
