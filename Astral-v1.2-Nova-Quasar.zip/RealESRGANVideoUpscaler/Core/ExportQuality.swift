import Foundation

/// Resolución máxima de exportación (lado corto del vídeo). Solo reduce; nunca agranda.
enum ExportQuality: Int, CaseIterable, Identifiable {
    case original = 0
    case p720 = 720
    case p1080 = 1080
    case p1440 = 1440
    case p2160 = 2160

    var id: Int { rawValue }

    /// nil = sin límite (se exporta tal como sale del proceso).
    var shortSide: Int? { self == .original ? nil : rawValue }

    var label: String {
        switch self {
        case .original: return tr("Original", "Original")
        case .p720: return "720p"
        case .p1080: return "1080p"
        case .p1440: return "1440p (2K)"
        case .p2160: return "2160p (4K)"
        }
    }

    var caption: String {
        self == .original
            ? tr("Sin cambios de tamaño", "No size change")
            : tr("Reduce si el vídeo es mayor; no agranda", "Downsizes if larger; never enlarges")
    }
}
