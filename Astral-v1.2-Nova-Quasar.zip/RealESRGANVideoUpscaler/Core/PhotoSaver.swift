import Foundation
import Photos
import SwiftUI
import CoreTransferable
import UniformTypeIdentifiers
import ImageIO

enum PhotoSaveError: LocalizedError {
    case denied, encodingFailed

    var errorDescription: String? {
        switch self {
        case .denied:
            return tr("Permite el acceso a Fotos en Ajustes para poder guardar.", "Allow access to Photos in Settings to save.")
        case .encodingFailed:
            return tr("No se pudo preparar la imagen para guardarla.", "Could not prepare the image for saving.")
        }
    }
}

/// Guarda resultados directamente en la fototeca (solo permiso de añadir).
enum PhotoSaver {
    private static func authorize() async throws {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else { throw PhotoSaveError.denied }
    }

    static func saveVideo(at url: URL) async throws {
        try await authorize()
        try await PHPhotoLibrary.shared().performChanges {
            let options = PHAssetResourceCreationOptions()
            options.shouldMoveFile = false
            PHAssetCreationRequest.forAsset().addResource(with: .video, fileURL: url, options: options)
        }
    }

    /// Se guarda como PNG para conservar la transparencia y la calidad.
    static func saveImage(_ image: CGImage) async throws {
        guard let data = pngData(image) else { throw PhotoSaveError.encodingFailed }
        try await authorize()
        try await PHPhotoLibrary.shared().performChanges {
            PHAssetCreationRequest.forAsset().addResource(with: .photo, data: data, options: nil)
        }
    }

    /// Guarda varios archivos (vídeos o imágenes) en una sola operación, p. ej. el resultado de un lote.
    static func saveFiles(_ urls: [URL]) async throws {
        guard !urls.isEmpty else { return }
        try await authorize()
        let videoExtensions: Set<String> = ["mp4", "mov", "m4v"]
        try await PHPhotoLibrary.shared().performChanges {
            for url in urls {
                let options = PHAssetResourceCreationOptions()
                options.shouldMoveFile = false
                let type: PHAssetResourceType = videoExtensions.contains(url.pathExtension.lowercased()) ? .video : .photo
                PHAssetCreationRequest.forAsset().addResource(with: type, fileURL: url, options: options)
            }
        }
    }

    static func pngData(_ image: CGImage) -> Data? {
        let data = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(destination, image, nil)
        return CGImageDestinationFinalize(destination) ? data as Data : nil
    }
}

/// Imagen compartible como PNG (con transparencia).
struct ShareableImage: Transferable {
    let image: CGImage

    static var transferRepresentation: some TransferRepresentation {
        DataRepresentation(exportedContentType: .png) { item in
            guard let data = PhotoSaver.pngData(item.image) else { throw PhotoSaveError.encodingFailed }
            return data
        }
    }
}

// MARK: - Barra de resultado: Guardar en Fotos | Compartir

struct ShareBarLabel: View {
    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "square.and.arrow.up")
            Text(tr("Compartir", "Share")).lineLimit(1)
        }
        .font(.system(size: 14, weight: .semibold, design: .rounded))
        .foregroundStyle(.white)
        .frame(width: 124, height: 50)
        .background(Color.white.opacity(0.14))
    }
}

struct ResultActionBar<Share: View>: View {
    let save: () async throws -> Void
    let share: Share

    @State private var message: String?
    @State private var isSaving = false

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 2) {
                Button {
                    guard !isSaving else { return }
                    isSaving = true
                    message = nil
                    Task {
                        do {
                            try await save()
                            message = tr("Guardado en Fotos", "Saved to Photos")
                        } catch {
                            message = error.localizedDescription
                        }
                        isSaving = false
                    }
                } label: {
                    HStack(spacing: 8) {
                        if isSaving {
                            ProgressView().tint(.black)
                        } else {
                            Image(systemName: "square.and.arrow.down")
                        }
                        Text(tr("Guardar en Fotos", "Save to Photos")).lineLimit(1).minimumScaleFactor(0.8)
                    }
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(.black)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(LocalStyle.gradient)
                }
                share
            }
            .clipShape(RoundedRectangle(cornerRadius: 13))
            .shadow(color: LocalStyle.mint.opacity(0.25), radius: 8)

            if let message {
                Text(message).font(.caption).foregroundStyle(.white.opacity(0.6))
            }
        }
    }
}
