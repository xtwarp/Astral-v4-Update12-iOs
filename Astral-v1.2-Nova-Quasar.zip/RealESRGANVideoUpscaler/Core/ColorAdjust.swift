import Foundation
import CoreImage
import CoreGraphics

/// Ajustes de color aplicados con Core Image (imágenes y vídeo).
struct ColorSettings: Equatable {
    var exposure = 0.0       // EV: -2 … 2
    var brightness = 0.0     // -0.3 … 0.3
    var contrast = 1.0       // 0.6 … 1.6
    var saturation = 1.0     // 0 … 2
    var vibrance = 0.0       // -1 … 1
    var temperature = 0.0    // -1 (frío) … 1 (cálido)
    var tint = 0.0           // -1 (verde) … 1 (magenta)
    var highlights = 0.0     // 0 … 1: recupera luces altas
    var shadows = 0.0        // 0 … 1: levanta sombras
    var sharpness = 0.0      // 0 … 1.5
    var vignette = 0.0       // 0 … 1
    var denoise = 0.0        // 0 … 1: reducción de ruido ligera (sin IA)

    var isNeutral: Bool { self == ColorSettings() }

    func apply(to input: CIImage) -> CIImage {
        let extent = input.extent
        var image = input

        if denoise > 0 {
            image = image.applyingFilter("CINoiseReduction", parameters: [
                "inputNoiseLevel": 0.01 + 0.07 * denoise,
                "inputSharpness": 0.4
            ])
        }
        if exposure != 0 {
            image = image.applyingFilter("CIExposureAdjust", parameters: ["inputEV": exposure])
        }
        if temperature != 0 || tint != 0 {
            let red = 1 + 0.2 * temperature
            let blue = 1 - 0.2 * temperature
            let green = 1 - 0.12 * tint
            image = image.applyingFilter("CIColorMatrix", parameters: [
                "inputRVector": CIVector(x: red, y: 0, z: 0, w: 0),
                "inputGVector": CIVector(x: 0, y: green, z: 0, w: 0),
                "inputBVector": CIVector(x: 0, y: 0, z: blue, w: 0),
                "inputAVector": CIVector(x: 0, y: 0, z: 0, w: 1),
                "inputBiasVector": CIVector(x: 0, y: 0, z: 0, w: 0)
            ])
        }
        if highlights != 0 || shadows != 0 {
            image = image.applyingFilter("CIHighlightShadowAdjust", parameters: [
                "inputHighlightAmount": 1 - highlights,
                "inputShadowAmount": shadows
            ])
        }
        if brightness != 0 || contrast != 1 || saturation != 1 {
            image = image.applyingFilter("CIColorControls", parameters: [
                "inputBrightness": brightness,
                "inputContrast": contrast,
                "inputSaturation": saturation
            ])
        }
        if vibrance != 0 {
            image = image.applyingFilter("CIVibrance", parameters: ["inputAmount": vibrance])
        }
        if sharpness > 0 {
            image = image.applyingFilter("CISharpenLuminance", parameters: ["inputSharpness": sharpness])
        }
        if vignette > 0 {
            image = image.applyingFilter("CIVignette", parameters: ["inputIntensity": vignette, "inputRadius": 1.5])
        }
        return image.cropped(to: extent)
    }
}

/// Estilos listos: rellenan los controles y luego se pueden afinar a mano.
enum ColorLook: String, CaseIterable, Identifiable {
    case original, vivid, warm, cool, cinematic, mono, vintage

    var id: String { rawValue }

    var title: String {
        switch self {
        case .original: return tr("Original", "Original")
        case .vivid: return tr("Vívido", "Vivid")
        case .warm: return tr("Cálido", "Warm")
        case .cool: return tr("Frío", "Cool")
        case .cinematic: return tr("Cine", "Cinematic")
        case .mono: return tr("B/N", "B&W")
        case .vintage: return tr("Vintage", "Vintage")
        }
    }

    var settings: ColorSettings {
        var s = ColorSettings()
        switch self {
        case .original: break
        case .vivid: s.contrast = 1.1; s.saturation = 1.2; s.vibrance = 0.3
        case .warm: s.temperature = 0.35; s.saturation = 1.05
        case .cool: s.temperature = -0.35
        case .cinematic: s.contrast = 1.18; s.saturation = 0.88; s.temperature = 0.12; s.shadows = 0.15; s.vignette = 0.35
        case .mono: s.saturation = 0; s.contrast = 1.15
        case .vintage: s.saturation = 0.78; s.contrast = 0.95; s.brightness = 0.03; s.temperature = 0.3; s.vignette = 0.4
        }
        return s
    }
}
