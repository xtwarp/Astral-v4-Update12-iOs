#!/bin/bash
# Descarga opcional: modelos RIFE 4.25 (Core ML) para la pestaña INTERPOLAR.
# Se publican en el release "rife-models" de este mismo repositorio al correr
# el workflow "Convert RIFE 4.25 to Core ML". Si aún no existen, este script
# avisa y continúa: la app compila igual, solo sin la pestaña de interpolación.
set +e
OUT="RealESRGANVideoUpscaler/Resources"
mkdir -p "$OUT"
REPO="${GITHUB_REPOSITORY:-}"
if [ -z "$REPO" ]; then
  echo "Sin GITHUB_REPOSITORY: se omite la descarga de modelos RIFE."
  exit 0
fi
BASE="https://github.com/${REPO}/releases/download/rife-models"

download_one() {
  local precision="$1" dims="$2" orientation="$3"
  local pkg="$OUT/RIFE_${precision}_${orientation}.mlpackage"
  if [ -d "$pkg" ]; then
    echo "RIFE ya presente: $precision $orientation"
    return 0
  fi
  local asset="RIFE_425_${precision}_${dims}.mlpackage.zip"
  local zip="$OUT/$asset"
  echo "Descargando $asset..."
  if ! curl -L --fail --retry 2 "$BASE/$asset" -o "$zip"; then
    echo "AVISO: no se pudo descargar $asset (¿ya corriste el workflow de conversión?). Se omite."
    rm -f "$zip"
    return 0
  fi
  unzip -oq "$zip" -d "$OUT"
  rm -f "$zip"
  local extracted="$OUT/RIFE_425_${precision}_${dims}.mlpackage"
  if [ ! -d "$extracted" ]; then
    echo "AVISO: el zip de $asset no contenía el .mlpackage esperado. Se omite."
    return 0
  fi
  mv "$extracted" "$pkg"
  echo "RIFE listo: $precision $orientation"
}

# Debe coincidir con los tamaños usados al convertir (ver .github/workflows/convert-rife.yml -> sizes)
for precision in fp16 fp32; do
  download_one "$precision" "1920x1152" "Landscape"
  download_one "$precision" "1152x1920" "Portrait"
done

echo "===== Modelos RIFE presentes ====="
find "$OUT" -maxdepth 1 -iname 'RIFE_*' -print
exit 0
