import SwiftUI

/// Etiqueta «✦ PRO»: chispa delante y PRO detrás. Marca las opciones que requieren Astral Pro.
struct ProBadge: View {
    var compact = false

    var body: some View {
        HStack(spacing: compact ? 2 : 3) {
            Image(systemName: "sparkles").font(.system(size: compact ? 7 : 10, weight: .bold))
            Text("PRO").font(.system(size: compact ? 8 : 10.5, weight: .heavy, design: .rounded)).tracking(0.6)
        }
        .foregroundStyle(LocalStyle.mint)
        .padding(.horizontal, compact ? 5 : 7)
        .padding(.vertical, compact ? 2 : 3)
        .background(LocalStyle.mint.opacity(0.16), in: Capsule())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Pro")
    }
}

/// Botón «Desbloquear» para las filas de ajustes que son de pago.
struct UnlockChip: View {
    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: "lock.open.fill").font(.system(size: 11, weight: .bold))
            Text(tr("Desbloquear", "Unlock")).font(.system(size: 12, weight: .bold, design: .rounded))
        }
        .foregroundStyle(Theme.onAccent)
        .padding(.horizontal, 11)
        .padding(.vertical, 7)
        .background(LocalStyle.mint, in: RoundedRectangle(cornerRadius: 10))
    }
}

/// Fila de ajuste de pago para quien no tiene Pro: título y detalle atenuados, y «Desbloquear» a la derecha.
struct LockedSettingRow: View {
    let title: String
    let detail: String
    let reason: String
    @ObservedObject private var access = ProAccess.shared

    var body: some View {
        Button { access.requestPaywall(reason: reason) } label: {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.system(size: 14, weight: .semibold, design: .rounded))
                    Text(detail).font(.caption2)
                }
                .foregroundStyle(Theme.ink(0.5))
                .multilineTextAlignment(.leading)
                Spacer(minLength: 8)
                UnlockChip()
            }
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityHint(tr("Abre la suscripción Pro", "Opens the Pro subscription"))
    }
}

/// «Te quedan 2 fotos hoy · Se reinicia a las 12:00 a. m.» con acceso a quitar los límites. Solo se ve sin Pro.
struct QuotaBanner: View {
    let kind: QuotaKind
    @ObservedObject private var access = ProAccess.shared
    @ObservedObject private var quota = UsageQuota.shared
    @ObservedObject private var language = AppLanguageStore.shared

    private var remainingText: String {
        switch kind {
        case .photos:
            let n = quota.remainingPhotos
            return n == 1 ? tr("Te queda 1 foto hoy", "1 photo left today")
                          : tr("Te quedan \(n) fotos hoy", "\(n) photos left today")
        case .video:
            let n = Int(quota.remainingVideoSeconds.rounded(.down))
            return tr("Te quedan \(n) s de video hoy", "\(n) s of video left today")
        case .background:
            let n = quota.remainingBackgrounds
            return n == 1 ? tr("Te queda 1 eliminación de fondo hoy", "1 background removal left today")
                          : tr("Te quedan \(n) eliminaciones de fondo hoy", "\(n) background removals left today")
        }
    }

    var body: some View {
        if !access.isPro {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 1) {
                    Text(remainingText)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(Theme.ink())
                    Text(tr("Se reinicia a las \(quota.resetTimeText)", "Resets at \(quota.resetTimeText)"))
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundStyle(Theme.ink(0.5))
                }
                Spacer(minLength: 8)
                Button { access.requestPaywall(reason: nil) } label: {
                    HStack(spacing: 5) {
                        ProBadge()
                        Text(tr("Quitar límites", "Remove limits"))
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundStyle(LocalStyle.mint)
                    }
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .frame(maxWidth: .infinity)
            .background(LocalStyle.mint.opacity(0.10), in: RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(LocalStyle.mint.opacity(0.25), lineWidth: 1))
        }
    }
}

/// Imágenes de ejemplo de la bienvenida con la línea de antes/después deslizándose sola, y un fundido suave
/// de una pareja de imágenes a la siguiente (sin cortes secos). Con «Reducir movimiento» se queda quieta.
struct ProHeroCompare: View {
    private let pairs = DemoImages.pairs
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var index = 0
    @State private var split: CGFloat = 0.5
    @State private var started = false

    private let timer = Timer.publish(every: 6, on: .main, in: .common).autoconnect()

    var body: some View {
        if pairs.isEmpty {
            EmptyView()
        } else {
            GeometryReader { proxy in
                let width = proxy.size.width
                let height = proxy.size.height
                ZStack {
                    ForEach(Array(pairs.enumerated()), id: \.offset) { offset, pair in
                        ZStack {
                            Image(uiImage: pair.after)
                                .resizable().scaledToFill()
                                .frame(width: width, height: height).clipped()
                            Image(uiImage: pair.before)
                                .resizable().scaledToFill()
                                .frame(width: width, height: height).clipped()
                                .mask(alignment: .leading) { Rectangle().frame(width: width * split) }
                        }
                        .opacity(offset == index ? 1 : 0)
                    }

                    Rectangle()
                        .fill(Color.white)
                        .frame(width: 2, height: height)
                        .position(x: width * split, y: height / 2)
                    Circle()
                        .fill(Color.white)
                        .frame(width: 26, height: 26)
                        .overlay(Image(systemName: "arrow.left.and.right").font(.system(size: 11, weight: .bold)).foregroundStyle(Color.black.opacity(0.75)))
                        .position(x: width * split, y: height / 2)

                    VStack {
                        HStack {
                            label(tr("ANTES", "BEFORE"))
                            Spacer()
                            label(tr("DESPUÉS", "AFTER"))
                        }
                        .padding(10)
                        Spacer()
                    }
                }
                .frame(width: width, height: height)
            }
            .frame(height: 200)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Theme.ink(0.12), lineWidth: 1))
            .accessibilityHidden(true)
            .onAppear {
                guard !started else { return }
                started = true
                guard !reduceMotion else { return }
                split = 0.15
                withAnimation(.easeInOut(duration: 2.4).repeatForever(autoreverses: true)) { split = 0.85 }
            }
            .onReceive(timer) { _ in
                guard !reduceMotion, pairs.count > 1 else { return }
                withAnimation(.easeInOut(duration: 0.9)) { index = (index + 1) % pairs.count }
            }
        }
    }

    private func label(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 10, weight: .heavy, design: .rounded))
            .tracking(0.8)
            .foregroundStyle(.white)
            .padding(.horizontal, 9).padding(.vertical, 5)
            .background(.black.opacity(0.5), in: Capsule())
    }
}

/// Aviso cuando un video es más largo que los segundos gratis que quedan hoy.
struct VideoQuotaPrompt: Identifiable {
    let id = UUID()
    let selected: Int
    let remaining: Int
}
