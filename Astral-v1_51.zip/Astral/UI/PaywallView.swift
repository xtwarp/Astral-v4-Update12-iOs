import SwiftUI
import StoreKit

/// Pantalla de suscripción de Astral Pro: antes/después animado, beneficios, planes con precio y duración,
/// prueba gratis (solo si Apple confirma que la cuenta puede usarla), comprar, restaurar, administrar y enlaces legales.
struct PaywallView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @ObservedObject private var store = StoreManager.shared
    @ObservedObject private var access = ProAccess.shared
    @ObservedObject private var themeStore = ThemeStore.shared
    @ObservedObject private var languageStore = AppLanguageStore.shared
    @State private var selectedID: String?
    @State private var showPolicy = false
    @State private var showManage = false

    private let termsURL = URL(string: "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/")!

    private var selectedProduct: Product? {
        store.products.first { $0.id == selectedID } ?? store.products.last
    }

    var body: some View {
        ZStack {
            NeonBackground().ignoresSafeArea()
            VStack(alignment: .leading, spacing: 12) {
                header
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 18) {
                        ProHeroCompare()
                        featuresCard
                        if store.isSubscribed || access.isPro {
                            activeCard
                        } else {
                            plansSection
                        }
                        if !store.message.isEmpty {
                            Text(store.message)
                                .font(.caption)
                                .foregroundStyle(LocalStyle.mint)
                                .multilineTextAlignment(.center)
                                .frame(maxWidth: .infinity)
                        }
                        secondaryButtons
                        legalSection
                    }
                    .padding(.bottom, 12)
                }
            }
            .padding(16)
        }
        .preferredColorScheme(themeStore.theme.palette.scheme)
        .manageSubscriptionsSheet(isPresented: $showManage)
        .sheet(isPresented: $showPolicy) { PrivacyPolicyView() }
        .task { if store.loadState != .loaded { await store.loadProducts() } }
        .onChange(of: store.isSubscribed) { _, subscribed in
            guard subscribed else { return }
            Task {
                try? await Task.sleep(nanoseconds: 1_800_000_000)
                dismiss()
            }
        }
        .onDisappear { access.paywallReason = nil }
    }

    private var header: some View {
        HStack {
            Spacer()
            Button { dismiss() } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(Theme.ink(0.7))
                    .frame(width: 34, height: 34)
                    .background(Theme.fill(0.055), in: Circle())
            }
            .accessibilityLabel(tr("Cerrar", "Close"))
        }
    }

    // MARK: - Título y beneficios

    /// Título, subtítulo y beneficios juntos en una sola tarjeta, con una línea que los separa.
    private var featuresCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            titleBlock
            Divider().overlay(Theme.ink(0.12))
            benefits
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(LocalStyle.mint.opacity(0.22), lineWidth: 1))
    }

    private func sectionLabel(_ text: String) -> some View {
        Text(text.uppercased())
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .tracking(1)
            .foregroundStyle(Theme.ink(0.45))
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var titleBlock: some View {
        VStack(alignment: .leading, spacing: 6) {
            if let reason = access.paywallReason {
                Text(reason)
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(LocalStyle.mint)
            }
            HStack(spacing: 8) {
                Text("Astral")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .foregroundStyle(Theme.ink())
                ProBadge()
                    .scaleEffect(1.15, anchor: .leading)
            }
            Text(tr("Sin límites diarios. Explota tu creatividad.", "No daily limits. Unleash your creativity."))
                .font(.system(size: 14, weight: .medium, design: .rounded))
                .foregroundStyle(Theme.ink(0.65))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var benefits: some View {
        VStack(alignment: .leading, spacing: 12) {
            benefit("infinity", tr("Fotos, video y fondos sin límite", "Unlimited photos, video and backgrounds"))
            benefit("wand.and.stars", tr("Aurora ×4, 120 fps y todos los modelos", "Aurora ×4, 120 fps and all models"))
            benefit("slider.horizontal.3", tr("Avanzado: HDR, precisión alta y más", "Advanced: HDR, high precision and more"))
            benefit("sparkles", tr("Acceso anticipado a futuras funciones y modelos", "Early access to future features and models"))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func benefit(_ icon: String, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(LocalStyle.mint)
                .frame(width: 22)
            Text(text)
                .font(.system(size: 14, weight: .medium, design: .rounded))
                .foregroundStyle(Theme.ink(0.9))
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    // MARK: - Suscripción activa

    private var activeCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                Image(systemName: "checkmark.seal.fill").foregroundStyle(LocalStyle.mint)
                Text(tr("Suscripción activa", "Subscription active"))
                    .font(.system(size: 17, weight: .bold, design: .rounded))
                    .foregroundStyle(Theme.ink())
            }
            if let date = store.expirationDate {
                let formatted = date.formatted(date: .long, time: .omitted)
                Text(tr("Activa hasta el \(formatted)", "Active until \(formatted)"))
                    .font(.footnote)
                    .foregroundStyle(Theme.ink(0.6))
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
    }

    // MARK: - Planes

    @ViewBuilder
    private var plansSection: some View {
        switch store.loadState {
        case .idle, .loading:
            HStack(spacing: 10) {
                ProgressView()
                Text(tr("Cargando planes…", "Loading plans…"))
                    .font(.subheadline)
                    .foregroundStyle(Theme.ink(0.6))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 24)
        case .failed:
            VStack(spacing: 10) {
                Text(tr("No se pudieron cargar los planes. Revisa tu conexión e inténtalo de nuevo.",
                        "Could not load the plans. Check your connection and try again."))
                    .font(.subheadline)
                    .foregroundStyle(Theme.ink(0.7))
                    .multilineTextAlignment(.center)
                Button { Task { await store.loadProducts() } } label: {
                    Text(tr("Reintentar", "Try again"))
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(LocalStyle.mint)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
        case .loaded:
            VStack(spacing: 10) {
                sectionLabel(tr("Elige tu plan", "Choose your plan"))
                VStack(spacing: 8) {
                    ForEach(store.products, id: \.id) { product in
                        planCard(product)
                    }
                }
                subscribeButton
            }
        }
    }

    private func planCard(_ product: Product) -> some View {
        let selected = (selectedProduct?.id == product.id)
        let hasTrial = store.trialEligibleIDs.contains(product.id)
        return Button { selectedID = product.id } label: {
            HStack(spacing: 12) {
                Image(systemName: selected ? "largecircle.fill.circle" : "circle")
                    .font(.system(size: 20))
                    .foregroundStyle(selected ? LocalStyle.mint : Theme.ink(0.4))
                VStack(alignment: .leading, spacing: 3) {
                    Text(product.displayName)
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .foregroundStyle(Theme.ink())
                    if hasTrial {
                        Text(tr("Prueba gratis", "Free trial"))
                            .font(.system(size: 11, weight: .bold, design: .rounded))
                            .foregroundStyle(LocalStyle.mint)
                    } else if let percent = savingsPercent(for: product) {
                        Text(tr("Ahorra \(percent) %", "Save \(percent)%"))
                            .font(.system(size: 11, weight: .bold, design: .rounded))
                            .foregroundStyle(LocalStyle.mint)
                    }
                }
                Spacer(minLength: 8)
                Text(product.priceWithPeriod)
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(Theme.ink(0.85))
                    .multilineTextAlignment(.trailing)
            }
            .padding(14)
            .frame(maxWidth: .infinity)
            .background(selected ? Theme.fill(0.07) : Theme.fill(0.04), in: RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(selected ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Theme.ink(0.1)), lineWidth: selected ? 2 : 1)
            )
        }
        .buttonStyle(.plain)
    }

    /// Solo en el plan más largo y si de verdad sale más barato que pagar el más corto por el mismo tiempo.
    private func savingsPercent(for product: Product) -> Int? {
        guard store.products.count > 1,
              let shortest = store.products.first, let longest = store.products.last,
              product.id == longest.id, shortest.id != longest.id,
              shortest.approximateDays > 0 else { return nil }
        let equivalent = shortest.price * Decimal(longest.approximateDays) / Decimal(shortest.approximateDays)
        guard equivalent > 0 else { return nil }
        let saved = (1 - NSDecimalNumber(decimal: longest.price / equivalent).doubleValue) * 100
        return saved >= 5 ? Int(saved.rounded()) : nil
    }

    private var selectedTrialLine: String? {
        selectedProduct.flatMap { store.trialLine(for: $0) }
    }

    private var subscribeButton: some View {
        let enabled = selectedProduct != nil && !store.isWorking
        let trial = selectedTrialLine
        return VStack(spacing: 8) {
            Button {
                guard let product = selectedProduct else { return }
                Task { await store.purchase(product) }
            } label: {
                HStack(spacing: 8) {
                    if store.isWorking { ProgressView().tint(Theme.onAccent) }
                    Text(trial != nil ? tr("Empezar prueba gratis", "Start free trial") : tr("Suscribirse", "Subscribe"))
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                }
                .foregroundStyle(Theme.onAccent)
                .frame(maxWidth: .infinity)
                .frame(height: 50)
                .background(LocalStyle.gradient, in: RoundedRectangle(cornerRadius: 14))
            }
            .disabled(!enabled)
            .opacity(enabled ? 1 : 0.5)

            if let trial {
                Text(trial)
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(Theme.ink(0.7))
            }
        }
        .padding(.top, 2)
    }

    // MARK: - Restaurar, administrar, legal

    private var secondaryButtons: some View {
        Button { showManage = true } label: {
            Text(tr("Administrar suscripción", "Manage subscription"))
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(Theme.ink(0.75))
                .frame(maxWidth: .infinity, minHeight: 44)
                .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
        }
    }

    private var legalSection: some View {
        VStack(spacing: 10) {
            Divider().overlay(Theme.ink(0.1))
            if let product = selectedProduct, selectedTrialLine != nil, !store.isSubscribed {
                let price = product.priceWithPeriod
                Text(tr("Si no cancelas al menos 24 horas antes de que termine la prueba gratis, se te cobrará \(price) y la suscripción se renovará sola.",
                        "If you don't cancel at least 24 hours before the free trial ends, you'll be charged \(price) and the subscription renews automatically."))
                    .font(.caption)
                    .foregroundStyle(Theme.ink(0.6))
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Text(tr("El pago se carga a tu cuenta de Apple al confirmar la compra. La suscripción se renueva sola, salvo que la canceles al menos 24 horas antes de que termine el periodo en curso. Puedes administrarla o cancelarla en Ajustes del iPhone › tu nombre › Suscripciones.",
                    "Payment is charged to your Apple Account when you confirm the purchase. The subscription renews automatically unless you cancel it at least 24 hours before the end of the current period. You can manage or cancel it in iPhone Settings › your name › Subscriptions."))
                .font(.caption)
                .foregroundStyle(Theme.ink(0.5))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 18) {
                Button { openURL(termsURL) } label: {
                    Text(tr("Términos de uso", "Terms of Use"))
                }
                Button { showPolicy = true } label: {
                    Text(tr("Política de privacidad", "Privacy policy"))
                }
            }
            .font(.caption.weight(.semibold))
            .foregroundStyle(LocalStyle.mint)
        }
        .padding(.top, 4)
    }
}
