import SwiftUI

/// Política de privacidad en lenguaje sencillo. Se abre desde la bienvenida y desde Ajustes.
struct PrivacyPolicyView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var themeStore = ThemeStore.shared
    @ObservedObject private var languageStore = AppLanguageStore.shared

    private struct PolicySection: Identifiable {
        let id = UUID()
        let title: String
        let body: String
    }

    private var sections: [PolicySection] {
        [
            PolicySection(
                title: tr("Resumen", "Summary"),
                body: tr("Astral procesa todo en tu dispositivo. Tus videos y fotos no se suben a ningún servidor y la app no recopila datos personales.",
                         "Astral processes everything on your device. Your videos and photos are not uploaded to any server and the app does not collect personal data.")
            ),
            PolicySection(
                title: tr("Qué usa la app", "What the app uses"),
                body: tr("Los videos y fotos que eliges para procesar, los resultados que genera y tus ajustes (tema, idioma, presets y, si los activas, guardar en Fotos y las notificaciones). Todo se guarda solo en tu iPhone.",
                         "The videos and photos you choose to process, the results it creates, and your settings (theme, language, presets and, if you turn them on, saving to Photos and notifications). Everything is stored only on your iPhone.")
            ),
            PolicySection(
                title: tr("Qué no hace", "What it doesn't do"),
                body: tr("No sube tus archivos a internet, no pide cuenta ni registro, no usa analíticas ni rastreo, no muestra anuncios y no comparte información con terceros.",
                         "It doesn't upload your files to the internet, doesn't ask for an account or sign-up, doesn't use analytics or tracking, doesn't show ads and doesn't share information with third parties.")
            ),
            PolicySection(
                title: tr("Permisos de Fotos", "Photos permissions"),
                body: tr("Para elegir fotos y videos, Astral usa el selector de iOS, así que solo recibe lo que tú seleccionas. Para guardar un resultado en Fotos, iOS pide permiso únicamente para añadir contenido. La opción «Guardar en Fotos al terminar» viene desactivada.",
                         "To choose photos and videos, Astral uses the iOS picker, so it only receives what you select. To save a result to Photos, iOS asks for permission to add content only. “Save to Photos when done” is off by default.")
            ),
            PolicySection(
                title: tr("Notificaciones", "Notifications"),
                body: tr("Son opcionales y vienen desactivadas. Si las activas en Ajustes, la app muestra avisos locales (por ejemplo, cuando termina de procesar). Se generan en tu iPhone, sin ningún servidor, y puedes desactivarlas cuando quieras.",
                         "They are optional and off by default. If you turn them on in Settings, the app shows local alerts (for example, when processing finishes). They are generated on your iPhone, without any server, and you can turn them off at any time.")
            ),
            PolicySection(
                title: tr("Dónde quedan tus archivos", "Where your files stay"),
                body: tr("Los resultados se crean como archivos temporales en el almacenamiento de la app en tu iPhone y no se guardan en Fotos salvo que actives esa opción en Ajustes; tú decides si los guardas en Fotos o los compartes. Si un video largo se interrumpe, la app conserva en su almacenamiento una copia del original y las partes ya procesadas hasta que lo reanudes, lo descartes, lo canceles o termine; «Borrar caché» no elimina esa copia. En Ajustes, «Borrar caché» elimina los archivos temporales. Si desinstalas la app, se borra todo lo que guardó, salvo los contadores de uso diario (ver «Límites diarios»), que el Llavero de iOS puede conservar.",
                         "Results are created as temporary files in the app's storage on your iPhone, and they aren't saved to Photos unless you turn that option on in Settings; you decide whether to save them to Photos or share them. If a long video is interrupted, the app keeps a copy of the original and the parts already processed in its storage until you resume, discard or cancel it, or it finishes; “Clear cache” doesn't delete that copy. In Settings, “Clear cache” removes the temporary files. If you uninstall the app, everything it stored is deleted, except the daily usage counters (see “Daily limits”), which the iOS Keychain may keep.")
            ),
            PolicySection(
                title: tr("Compartir", "Sharing"),
                body: tr("Si usas Compartir, el resultado va a la app o al destino que elijas en la hoja de iOS, y a partir de ahí rige la política de esa app. Astral no comparte nada por su cuenta.",
                         "If you use Share, the result goes to the app or destination you pick in the iOS share sheet, and that app's own policy applies from there. Astral doesn't share anything on its own.")
            ),
            PolicySection(
                title: tr("Suscripción", "Subscription"),
                body: tr("Astral ofrece una suscripción de renovación automática dentro de la app. Apple la procesa mediante StoreKit con tu Apple ID: Astral no ve ni guarda tu tarjeta ni tus datos de pago, y no necesitas crear una cuenta. El precio y la duración de cada plan se muestran en la app antes de confirmar. El pago se carga a tu cuenta de Apple al confirmar la compra, y la suscripción se renueva sola, salvo que la canceles al menos 24 horas antes de que termine el periodo en curso; la renovación se cobra dentro de las 24 horas previas al final del periodo. Puedes gestionarla o cancelarla en cualquier momento en Ajustes del iPhone › tu nombre › Suscripciones; seguirás teniendo acceso hasta que termine el periodo ya pagado. La app solo consulta a Apple, en tu iPhone, si tu suscripción está activa para habilitar sus funciones; no envía esa información a ningún servidor propio. Puedes recuperarla en un iPhone nuevo con «Restaurar compras» en Ajustes. Si se ofrece una prueba gratis, Apple decide si tu cuenta puede usarla y solo la concede una vez por cuenta de Apple; Astral no lleva ningún registro propio de ella. Los cobros y los reembolsos los maneja Apple (reportaproblem.apple.com).",
                         "Astral offers an auto-renewing subscription inside the app. Apple processes it through StoreKit with your Apple ID: Astral never sees or stores your card or payment details, and you don't need to create an account. The price and length of each plan are shown in the app before you confirm. Payment is charged to your Apple Account when you confirm the purchase, and the subscription renews automatically unless you cancel it at least 24 hours before the end of the current period; the renewal is charged within the 24 hours before the period ends. You can manage or cancel it at any time in iPhone Settings › your name › Subscriptions; you keep access until the end of the period you already paid for. The app only asks Apple, on your iPhone, whether your subscription is active so it can unlock its features; it doesn't send that information to any server of its own. You can recover it on a new iPhone with “Restore purchases” in Settings. If a free trial is offered, Apple decides whether your Apple Account can use it and grants it only once per Apple Account; Astral keeps no record of its own. Charges and refunds are handled by Apple (reportaproblem.apple.com).")
            ),
            PolicySection(
                title: tr("Límites diarios", "Daily limits"),
                body: tr("En el plan gratuito, Astral limita el uso diario (fotos, segundos de video y fondos quitados). Para contarlo, la app guarda en tu iPhone solo los contadores del día y la fecha del último uso, en el Llavero de iOS y en sus propios ajustes. Estos datos no salen de tu iPhone y no contienen información personal. Como el Llavero puede conservar esos contadores aunque desinstales la app, reinstalarla no reinicia el límite del día. Con una suscripción activa no hay límites diarios.",
                         "On the free plan, Astral limits daily use (photos, seconds of video and background removals). To count it, the app stores on your iPhone only the day's counters and the date of the last use, in the iOS Keychain and in its own settings. This data never leaves your iPhone and contains no personal information. Because the Keychain can keep these counters even if you uninstall the app, reinstalling it does not reset the day's limit. With an active subscription there are no daily limits.")
            ),
            PolicySection(
                title: tr("Modelos de IA", "AI models"),
                body: tr("Los modelos vienen incluidos en la app y funcionan sin conexión. Sus autores y licencias aparecen en Ajustes › Créditos y licencias. Quitar fondo usa el reconocimiento de sujetos del propio iOS (Vision), también en tu dispositivo y sin conexión.",
                         "The models are included in the app and work offline. Their authors and licenses are listed in Settings › Credits & licenses. Background removal uses iOS's own subject recognition (Vision), also on your device and offline.")
            ),
            PolicySection(
                title: tr("Contacto", "Contact"),
                body: tr("Si me escribes a astralapp@proton.me, recibiré tu mensaje y tu dirección de correo. Los uso solo para responderte. La app únicamente abre tu aplicación de correo con un mensaje nuevo; no adjunta ningún dato tuyo ni de tu dispositivo.",
                         "If you write to astralapp@proton.me, I will receive your message and your email address. I use them only to reply to you. The app only opens your email app with a new message; it doesn't attach any data about you or your device.")
            ),
            PolicySection(
                title: tr("Cambios", "Changes"),
                body: tr("Si esta política cambia, se actualizará aquí dentro de la app.",
                         "If this policy changes, it will be updated here inside the app.")
            )
        ]
    }

    var body: some View {
        ZStack {
            NeonBackground().ignoresSafeArea()
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text(tr("POLÍTICA DE PRIVACIDAD", "PRIVACY POLICY"))
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(Theme.ink(0.6))
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(Theme.ink(0.7))
                            .frame(width: 34, height: 34)
                            .background(Theme.fill(0.055), in: Circle())
                    }
                    .accessibilityLabel(tr("Cerrar", "Close"))
                }
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 10) {
                        ForEach(sections) { section in
                            VStack(alignment: .leading, spacing: 5) {
                                Text(section.title)
                                    .font(.system(size: 14, weight: .bold, design: .rounded))
                                    .foregroundStyle(LocalStyle.mint)
                                Text(section.body)
                                    .font(.system(size: 13.5, weight: .regular, design: .rounded))
                                    .foregroundStyle(Theme.ink(0.8))
                                    .lineSpacing(2)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            .padding(14)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
                        }

                    }
                    .padding(.bottom, 12)
                }
            }
            .padding(16)
        }
        .preferredColorScheme(themeStore.theme.palette.scheme)
    }
}
