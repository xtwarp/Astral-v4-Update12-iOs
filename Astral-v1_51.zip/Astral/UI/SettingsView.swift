import SwiftUI
import UIKit

struct SettingsView: View {
    let keepURLs: [URL]
    let isBusy: Bool

    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var languageStore = AppLanguageStore.shared
    @ObservedObject private var themeStore = ThemeStore.shared
    @ObservedObject private var store = StoreManager.shared
    @ObservedObject private var access = ProAccess.shared
    @State private var showPaywall = false
    @State private var cacheBytes: Int64 = 0
    @State private var message = ""
    @State private var showCredits = false
    @State private var showPolicy = false
    @AppStorage("astral.onboardingDone") private var onboardingDone = true
    @AppStorage(AutoSave.key) private var autoSavePhotos = false
    @AppStorage(NotifyOnFinish.key) private var notifyOnFinish = false
    @State private var notifyDenied = false
    @Environment(\.openURL) private var openURL
    @State private var supportMessage = ""
    @State private var showAdvanced = false
    @State private var showCache = false

    private let supportEmail = "astralapp@proton.me"

    var body: some View {
        ZStack {
            NeonBackground().ignoresSafeArea()
            ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text(L.settingsTitle.text)
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(Theme.ink(0.6))
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(Theme.ink(0.7))
                            .frame(width: 34, height: 34)
                            .background(Theme.fill(0.055), in: Circle())
                    }
                    .accessibilityLabel(tr("Cerrar", "Close"))
                }

                themeCard

                // Idioma + guardar en Fotos + notificar: todo dentro de un solo apartado plegable.
                AdvancedDisclosure(icon: "slider.horizontal.3", isExpanded: $showAdvanced, isModified: autoSavePhotos || notifyOnFinish) {
                    languageContent
                    sectionDivider
                    autoSaveRow
                    sectionDivider
                    notifyRow
                }

                // Caché temporal: otro apartado plegable, aparte.
                AdvancedDisclosure(title: tr("Caché", "Cache"), icon: "externaldrive", isExpanded: $showCache) {
                    cacheContent
                }

                if TesterMode.isEnabled {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("TESTER").font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
                        Toggle(isOn: $access.simulatePro) {
                            Text(tr("Simular Pro", "Simulate Pro")).font(.system(size: 14, weight: .semibold, design: .rounded))
                        }
                        .tint(LocalStyle.mint)
                        settingsRow(icon: "arrow.counterclockwise.circle", title: tr("Reiniciar contadores diarios", "Reset daily counters")) {
                            UsageQuota.shared.resetForTesting()
                        }
                    }
                    .padding(12)
                    .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 13))
                }

                Text(tr("Acerca de", "About"))
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundStyle(Theme.ink())
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 10)

                settingsRow(icon: "star.circle", title: tr("Suscripción", "Subscription"),
                            detail: store.isSubscribed ? tr("Activa", "Active") : nil) { showPaywall = true }

                settingsRow(icon: "arrow.clockwise.circle", title: tr("Restaurar compras", "Restore purchases")) {
                    Task { await store.restore() }
                }
                .disabled(store.isWorking)

                if !store.message.isEmpty {
                    Text(store.message)
                        .font(.caption)
                        .foregroundStyle(LocalStyle.mint)
                }


                settingsRow(icon: "doc.text", title: tr("Créditos y licencias", "Credits & licenses")) { showCredits = true }

                settingsRow(icon: "hand.raised", title: tr("Política de privacidad", "Privacy policy")) { showPolicy = true }

                settingsRow(icon: "sparkles", title: tr("Ver la bienvenida otra vez", "Show the welcome again")) {
                    onboardingDone = false
                    dismiss()
                }

                Spacer(minLength: 0)

                supportLink
            }
            .padding(16)
            }
        }
        .preferredColorScheme(themeStore.theme.palette.scheme)
        .presentationDetents([.medium, .large])
        .sheet(isPresented: $showCredits) { CreditsView() }
        .sheet(isPresented: $showPolicy) { PrivacyPolicyView() }
        .sheet(isPresented: $showPaywall) { PaywallView() }
        .onAppear {
            store.message = ""
            refresh()
        }
    }

    private func formatBytes(_ bytes: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        formatter.allowsNonnumericFormatting = false   // "0 KB" en lugar de "Zero KB"
        return formatter.string(fromByteCount: bytes)
    }

    private var themeCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(tr("TEMA", "THEME"))
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(Theme.ink(0.45))
            HStack(spacing: 8) {
                ForEach(AppTheme.allCases) { option in
                    themeOption(option)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
    }

    /// Mini muestra del tema (su fondo y su acento) con el nombre debajo.
    private func themeOption(_ option: AppTheme) -> some View {
        let palette = option.palette
        let selected = themeStore.theme == option
        return Button {
            withAnimation(.easeInOut(duration: 0.2)) { themeStore.theme = option }
        } label: {
            VStack(spacing: 7) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10).fill(palette.base)
                    if palette.blobOpacity > 0 {
                        Circle().fill(Color(red: 0.0, green: 0.85, blue: 1.0)).frame(width: 26, height: 26)
                            .blur(radius: 9).opacity(palette.blobOpacity * 1.6).offset(x: 14, y: -6)
                        Circle().fill(Color(red: 0.75, green: 0.2, blue: 1.0)).frame(width: 26, height: 26)
                            .blur(radius: 9).opacity(palette.blobOpacity * 1.6).offset(x: -14, y: 8)
                    }
                    Capsule()
                        .fill(LinearGradient(colors: [palette.mint, palette.cyan], startPoint: .leading, endPoint: .trailing))
                        .frame(width: 34, height: 9)
                }
                .frame(height: 50)
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Theme.ink(0.15), lineWidth: 1))

                VStack(spacing: 1) {
                    Text(option.displayName)
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                    Text(option.detail)
                        .font(.system(size: 9, weight: .medium, design: .rounded))
                        .lineLimit(1).minimumScaleFactor(0.8)
                        .opacity(0.6)
                }
                .foregroundStyle(Theme.ink())
            }
            .padding(6)
            .frame(maxWidth: .infinity)
            .background(selected ? Theme.fill(0.07) : Color.clear, in: RoundedRectangle(cornerRadius: 13))
            .overlay(
                RoundedRectangle(cornerRadius: 13)
                    .stroke(selected ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.clear), lineWidth: 2)
            )
        }
    }

    private var languageContent: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(L.settingsLanguage.text)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(Theme.ink(0.45))
            Menu {
                ForEach(AppLanguage.allCases) { lang in
                    Button {
                        languageStore.language = lang
                    } label: {
                        if lang == languageStore.language {
                            Label(lang.displayName, systemImage: "checkmark")
                        } else {
                            Text(lang.displayName)
                        }
                    }
                }
            } label: {
                ZStack {
                    Text(languageStore.language.displayName)
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundStyle(Theme.ink())
                        .frame(maxWidth: .infinity)
                    HStack {
                        Spacer()
                        Image(systemName: "chevron.down")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(Theme.ink(0.6))
                    }
                }
                .padding(.horizontal, 14)
                .frame(maxWidth: .infinity)
                .frame(height: 46)
                .background(Theme.fill(0.07), in: RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(LocalStyle.mint.opacity(0.35), lineWidth: 1))
            }
            .menuOrder(.fixed)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var sectionDivider: some View {
        Rectangle().fill(Theme.ink(0.08)).frame(height: 1)
    }

    /// Contenido del apartado "Caché": tamaño actual, botón para borrarla, resultado y nota.
    private var cacheContent: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(L.cacheTitle.text)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(Theme.ink(0.45))
            Text(formatBytes(cacheBytes))
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .foregroundStyle(Theme.ink())
            let enabled = !isBusy && cacheBytes > 0
            Button {
                let freed = CacheManager.remove(CacheManager.temporaryFiles(), keeping: keepURLs)
                message = tr("Liberado", "Freed") + ": \(formatBytes(freed))"
                refresh()
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "trash")
                    Text(L.cacheButton.text).font(.subheadline.weight(.semibold))
                }
                .foregroundStyle(Theme.onAccent)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(LocalStyle.gradient, in: RoundedRectangle(cornerRadius: 13))
            }
            .disabled(!enabled)
            .opacity(enabled ? 1 : 0.4)

            if !message.isEmpty {
                Text(message)
                    .font(.caption)
                    .foregroundStyle(LocalStyle.mint)
            }

            Text(L.cacheFootnote.text)
                .font(.caption)
                .foregroundStyle(Theme.ink(0.45))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    /// Interruptor "Guardar en Fotos al terminar": sin texto de encendido/apagado, solo el interruptor.
    private var autoSaveRow: some View {
        HStack {
            Image(systemName: "square.and.arrow.down")
            Text(tr("Guardar en Fotos al terminar", "Save to Photos when done"))
                .font(.subheadline.weight(.semibold))
                .lineLimit(2)
                .minimumScaleFactor(0.8)
            Spacer(minLength: 8)
            Toggle("", isOn: $autoSavePhotos)
                .labelsHidden()
                .tint(LocalStyle.mint)
        }
        .foregroundStyle(Theme.ink())
        .frame(maxWidth: .infinity)
        .frame(minHeight: 40)
    }

    /// Interruptor "Notificar al terminar": pide permiso de notificaciones la primera vez que se activa.
    private var notifyRow: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: "bell")
                Text(tr("Notificar al terminar", "Notify when done"))
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
                Spacer(minLength: 8)
                Toggle("", isOn: Binding(
                    get: { notifyOnFinish },
                    set: { newValue in
                        if newValue {
                            Task {
                                let granted = await NotificationManager.requestPermission()
                                notifyOnFinish = granted
                                notifyDenied = !granted
                            }
                        } else {
                            notifyOnFinish = false
                            notifyDenied = false
                        }
                    }
                ))
                .labelsHidden()
                .tint(LocalStyle.mint)
            }
            .foregroundStyle(Theme.ink())
            .frame(maxWidth: .infinity)
            .frame(minHeight: 40)

            if notifyDenied {
                Button { NotificationManager.openSystemSettings() } label: {
                    Text(tr("Activa las notificaciones de Astral en Ajustes", "Turn on Astral notifications in Settings"))
                        .font(.caption)
                        .foregroundStyle(LocalStyle.mint)
                        .multilineTextAlignment(.leading)
                }
            }
        }
    }

    /// Correo de soporte en azul: al tocarlo abre el correo con un mensaje nuevo para el desarrollador.
    private var supportLink: some View {
        VStack(spacing: 6) {
            Button {
                let subject = "Astral".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "Astral"
                guard let url = URL(string: "mailto:\(supportEmail)?subject=\(subject)") else { return }
                openURL(url) { accepted in
                    if !accepted {
                        UIPasteboard.general.string = supportEmail
                        supportMessage = tr("Correo copiado al portapapeles", "Email copied to the clipboard")
                    }
                }
            } label: {
                (Text(tr("Soporte", "Support") + ": ").foregroundColor(Theme.ink(0.6))
                 + Text(supportEmail).foregroundColor(Color(red: 0.25, green: 0.58, blue: 1)))
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
            }
            if !supportMessage.isEmpty {
                Text(supportMessage).font(.caption).foregroundStyle(LocalStyle.mint)
            }
        }
        .padding(.top, 6)
    }

    private func settingsRow(icon: String, title: String, detail: String? = nil, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(LocalStyle.mint)
                    .frame(width: 30, height: 30)
                    .background(LocalStyle.mint.opacity(0.14), in: RoundedRectangle(cornerRadius: 9))
                Text(title).font(.system(size: 15, weight: .semibold, design: .rounded))
                Spacer()
                if let detail {
                    Text(detail)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(LocalStyle.mint)
                }
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).opacity(0.4)
            }
            .foregroundStyle(Theme.ink())
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity)
            .frame(height: 52)
            .background(Theme.fill(0.075), in: RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(LocalStyle.mint.opacity(0.25), lineWidth: 1))
        }
    }

    private func refresh() {
        cacheBytes = CacheManager.size(of: CacheManager.temporaryFiles().filter { url in
            !keepURLs.contains { $0.resolvingSymlinksInPath().path == url.resolvingSymlinksInPath().path }
        })
    }
}
