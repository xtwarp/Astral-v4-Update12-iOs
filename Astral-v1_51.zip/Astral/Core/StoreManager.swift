import Foundation
import StoreKit

/// Suscripciones con StoreKit 2. Todo ocurre en el iPhone: la app solo le pregunta a Apple si hay una suscripción activa.
/// Para bloquear una función más adelante basta con leer `StoreManager.shared.isSubscribed`.
@MainActor
final class StoreManager: ObservableObject {
    static let shared = StoreManager()

    /// IDs de producto: deben ser idénticos a los que crees en App Store Connect (Suscripciones, en un solo grupo).
    static let productIDs: [String] = [
        "com.hugovela.Astral.pro.monthly",
        "com.hugovela.Astral.pro.yearly"
    ]

    enum LoadState { case idle, loading, loaded, failed }

    @Published private(set) var products: [Product] = []
    @Published private(set) var loadState: LoadState = .idle
    @Published private(set) var isSubscribed = false
    @Published private(set) var activeProductID: String?
    @Published private(set) var expirationDate: Date?
    @Published private(set) var isWorking = false
    @Published var message = ""
    /// Planes con prueba gratis a los que ESTA cuenta de Apple todavía puede acceder. Lo decide Apple, nunca la app:
    /// una cuenta que ya usó la prueba del grupo (aunque reinstale, cambie de iPhone o restaure) sale como no elegible.
    @Published private(set) var trialEligibleIDs: Set<String> = []

    private var started = false
    private var updatesTask: Task<Void, Never>?

    private init() {}

    /// Arranca al abrir la app: escucha las transacciones que llegan fuera de una compra (renovaciones, compras
    /// aprobadas más tarde, reembolsos), revisa la suscripción actual y carga los planes.
    func start() async {
        if !started {
            started = true
            updatesTask = Task { [weak self] in
                for await update in Transaction.updates {
                    guard let self else { return }
                    await self.handle(update)
                }
            }
        }
        await refreshEntitlements()
        if products.isEmpty { await loadProducts() }
    }

    // MARK: - Planes

    func loadProducts() async {
        loadState = .loading
        do {
            let loaded = try await Product.products(for: Self.productIDs)
            products = loaded.sorted { $0.approximateDays < $1.approximateDays }
            loadState = loaded.isEmpty ? .failed : .loaded
            await refreshTrialEligibility()
        } catch {
            loadState = .failed
        }
    }

    /// Pregunta a Apple, plan por plan, si esta cuenta puede usar la prueba gratis. Si algo falla, no se ofrece prueba.
    func refreshTrialEligibility() async {
        var eligible: Set<String> = []
        for product in products {
            guard let info = product.subscription,
                  let offer = info.introductoryOffer,
                  offer.paymentMode == .freeTrial else { continue }
            if await info.isEligibleForIntroOffer { eligible.insert(product.id) }
        }
        trialEligibleIDs = eligible
    }

    /// «3 días gratis, luego $19.99 / año». nil si este plan no tiene prueba o esta cuenta ya no puede usarla.
    func trialLine(for product: Product) -> String? {
        guard !isSubscribed,
              trialEligibleIDs.contains(product.id),
              let offer = product.subscription?.introductoryOffer,
              offer.paymentMode == .freeTrial else { return nil }
        let price = product.priceWithPeriod
        let period = offer.period
        switch (period.unit, period.value) {
        case (.day, 1): return tr("1 día gratis, luego \(price)", "1 day free, then \(price)")
        case (.day, let days): return tr("\(days) días gratis, luego \(price)", "\(days) days free, then \(price)")
        case (.week, 1): return tr("1 semana gratis, luego \(price)", "1 week free, then \(price)")
        default:
            var components = DateComponents()
            let unit: NSCalendar.Unit
            switch period.unit {
            case .day: components.day = period.value; unit = .day
            case .week: components.day = period.value * 7; unit = .day
            case .month: components.month = period.value; unit = .month
            case .year: components.year = period.value; unit = .year
            @unknown default: return nil
            }
            let formatter = DateComponentsFormatter()
            formatter.unitsStyle = .full
            formatter.allowedUnits = unit
            guard let length = formatter.string(from: components) else { return nil }
            return tr("\(length) gratis, luego \(price)", "\(length) free, then \(price)")
        }
    }

    // MARK: - Estado de la suscripción

    /// Mira las transacciones vigentes (Apple las guarda en el iPhone, así que también funciona sin conexión).
    func refreshEntitlements() async {
        var best: Transaction?
        for await result in Transaction.currentEntitlements {
            guard case .verified(let transaction) = result,
                  Self.productIDs.contains(transaction.productID),
                  transaction.revocationDate == nil else { continue }
            if let expiration = transaction.expirationDate, expiration <= Date() { continue }
            let candidate = transaction.expirationDate ?? .distantFuture
            if best == nil || candidate > (best?.expirationDate ?? .distantFuture) { best = transaction }
        }
        isSubscribed = best != nil
        activeProductID = best?.productID
        expirationDate = best?.expirationDate
        if !products.isEmpty { await refreshTrialEligibility() }
    }

    private func handle(_ update: VerificationResult<Transaction>) async {
        guard case .verified(let transaction) = update else { return }
        await transaction.finish()
        await refreshEntitlements()
    }

    // MARK: - Compra y restauración

    func purchase(_ product: Product) async {
        guard !isWorking else { return }
        isWorking = true
        message = ""
        defer { isWorking = false }
        do {
            switch try await product.purchase() {
            case .success(let verification):
                switch verification {
                case .verified(let transaction):
                    await transaction.finish()
                    await refreshEntitlements()
                case .unverified:
                    message = tr("No se pudo verificar la compra.", "The purchase could not be verified.")
                }
            case .pending:
                message = tr("Compra pendiente de aprobación.", "Purchase pending approval.")
            case .userCancelled:
                break
            @unknown default:
                break
            }
        } catch {
            message = tr("No se pudo completar la compra: \(error.localizedDescription)",
                         "The purchase could not be completed: \(error.localizedDescription)")
        }
    }

    /// «Restaurar compras»: sincroniza con la App Store (puede pedir iniciar sesión con el Apple ID).
    func restore() async {
        guard !isWorking else { return }
        isWorking = true
        message = ""
        defer { isWorking = false }
        do {
            try await AppStore.sync()
            await refreshEntitlements()
            message = isSubscribed
                ? tr("Suscripción restaurada.", "Subscription restored.")
                : tr("No se encontró ninguna suscripción activa en esta cuenta de Apple.",
                     "No active subscription was found for this Apple Account.")
        } catch {
            if let storeError = error as? StoreKitError, case .userCancelled = storeError { return }
            message = tr("No se pudieron restaurar las compras: \(error.localizedDescription)",
                         "Could not restore purchases: \(error.localizedDescription)")
        }
    }
}

// MARK: - Textos de precio y periodo

extension Product {
    /// «$9.99 / mes»: el precio ya viene en la moneda y el formato de la tienda del usuario.
    var priceWithPeriod: String {
        guard let period = subscription?.subscriptionPeriod else { return displayPrice }
        let price = displayPrice
        if period.value == 1 {
            switch period.unit {
            case .day: return tr("\(price) / día", "\(price) / day")
            case .week: return tr("\(price) / semana", "\(price) / week")
            case .month: return tr("\(price) / mes", "\(price) / month")
            case .year: return tr("\(price) / año", "\(price) / year")
            @unknown default: return price
            }
        }
        var components = DateComponents()
        let unit: NSCalendar.Unit
        switch period.unit {
        case .day: components.day = period.value; unit = .day
        case .week: components.day = period.value * 7; unit = .day
        case .month: components.month = period.value; unit = .month
        case .year: components.year = period.value; unit = .year
        @unknown default: return price
        }
        let formatter = DateComponentsFormatter()
        formatter.unitsStyle = .full
        formatter.allowedUnits = unit
        return price + " / " + (formatter.string(from: components) ?? "\(period.value)")
    }

    /// Duración del plan en días (para comparar planes).
    var approximateDays: Int {
        guard let period = subscription?.subscriptionPeriod else { return 0 }
        switch period.unit {
        case .day: return period.value
        case .week: return period.value * 7
        case .month: return period.value * 30
        case .year: return period.value * 365
        @unknown default: return period.value
        }
    }
}
