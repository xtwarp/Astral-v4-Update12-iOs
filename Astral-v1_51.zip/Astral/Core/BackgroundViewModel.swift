import Foundation
import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import ImageIO
import UIKit

@MainActor
final class BackgroundViewModel: ObservableObject {
    @Published var inputImage: CGImage?
    @Published var outputImage: CGImage?
    @Published var isProcessing = false
    @Published var status = tr("Selecciona una imagen", "Select an image")

    @Published var batchTotal = 0
    @Published var batchIndex = 0
    @Published var batchResults: [URL] = []
    @Published var batchFailures = 0
    @Published var isBatchRunning = false
    private let cancelFlag = CancelFlag()

    private let remover = BackgroundRemover()

    var isBusy: Bool { isProcessing || isBatchRunning }

    /// Gasta una eliminación de fondo de la cuota diaria (solo sin Pro y solo cuando terminó bien).
    private func commitBackgroundQuota() {
        if !ProAccess.shared.isPro { UsageQuota.shared.commitBackgrounds(1) }
    }

    /// Plan gratuito: ¿quedan eliminaciones de fondo hoy? Si no, abre la suscripción.
    private func canStartWithCurrentPlan() -> Bool {
        guard !ProAccess.shared.isPro else { return true }
        if UsageQuota.shared.remainingBackgrounds < 1 {
            status = ProAccess.limitReason(.background)
            ProAccess.shared.requestPaywall(reason: ProAccess.limitReason(.background))
            return false
        }
        return true
    }

    func relocalizeIdleStatus() {
        guard !isBusy else { return }
        if isTr(status, "Selecciona una imagen", "Select an image") { status = tr("Selecciona una imagen", "Select an image") }
        if isTr(status, "Imagen seleccionada", "Image selected") { status = tr("Imagen seleccionada", "Image selected") }
    }

    func importImage(from item: PhotosPickerItem) async {
        guard !isBusy else { return }
        status = tr("Cargando imagen…", "Loading image…")
        do {
            guard let data = try await item.loadTransferable(type: Data.self),
                  let image = BackgroundRemover.loadImage(from: data) else {
                status = tr("No se pudo cargar la imagen", "Could not load the image")
                return
            }
            inputImage = image
            outputImage = nil
            status = tr("Imagen seleccionada", "Image selected")
        } catch {
            status = tr("No se pudo cargar la imagen: \(error.localizedDescription)", "Could not load the image: \(error.localizedDescription)")
        }
    }

    func start() {
        guard let source = inputImage, !isBusy else { return }
        guard canStartWithCurrentPlan() else { return }
        isProcessing = true
        outputImage = nil
        status = tr("Quitando el fondo…", "Removing the background…")
        let engine = remover
        Task {
            do {
                let result = try await Task.detached(priority: .userInitiated) {
                    try engine.cutout(source)
                }.value
                outputImage = result
                commitBackgroundQuota()
                status = tr("Listo — guarda el resultado en Archivos", "Done — save the result to Files")
                if AutoSave.isOn {
                    do {
                        try await PhotoSaver.saveImage(result)
                        status = tr("Listo — guardado en Fotos", "Done — saved to Photos")
                    } catch {
                        status = error.localizedDescription
                    }
                }
            } catch {
                status = error.localizedDescription
            }
            isProcessing = false
        }
    }

    // MARK: - Lote

    func startBatch(_ items: [PhotosPickerItem]) {
        guard !items.isEmpty, !isBusy else { return }
        guard canStartWithCurrentPlan() else { return }
        isBatchRunning = true
        cancelFlag.value = false
        batchTotal = items.count
        batchIndex = 0
        batchResults = []
        batchFailures = 0
        UIApplication.shared.isIdleTimerDisabled = true
        let flag = cancelFlag
        let engine = remover
        Task {
            var stoppedByLimit = false
            for (offset, item) in items.enumerated() {
                if flag.value { break }
                if !ProAccess.shared.isPro && UsageQuota.shared.remainingBackgrounds < 1 { stoppedByLimit = true; break }
                batchIndex = offset + 1
                status = tr("Procesando imagen \(offset + 1)/\(items.count)…", "Processing image \(offset + 1)/\(items.count)…")
                do {
                    guard let data = try await item.loadTransferable(type: Data.self) else { batchFailures += 1; continue }
                    let url = try await Task.detached(priority: .userInitiated) {
                        try BackgroundViewModel.cutoutToTemporaryPNG(data: data, engine: engine, flag: flag)
                    }.value
                    batchResults.append(url)
                    commitBackgroundQuota()
                    if AutoSave.isOn { try? await PhotoSaver.saveFiles([url]) }
                } catch {
                    if !flag.value { batchFailures += 1 }
                }
            }
            isBatchRunning = false
            UIApplication.shared.isIdleTimerDisabled = false
            if flag.value {
                status = tr("Lote cancelado", "Batch cancelled")
            } else if stoppedByLimit {
                status = tr("Límite diario alcanzado: se procesaron \(batchResults.count) de \(items.count).",
                            "Daily limit reached: \(batchResults.count) of \(items.count) were processed.")
            } else {
                status = tr("Lote terminado", "Batch finished")
            }
        }
    }

    func cancelBatch() {
        cancelFlag.value = true
        status = tr("Cancelando…", "Cancelling…")
    }

    nonisolated private static func cutoutToTemporaryPNG(data: Data, engine: BackgroundRemover, flag: CancelFlag) throws -> URL {
        guard let image = BackgroundRemover.loadImage(from: data) else { throw UpscaleError.exportFailed }
        let result = try engine.cutout(image) { flag.value }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Result_\(UUID().uuidString).png")
        guard let destination = CGImageDestinationCreateWithURL(url as CFURL, UTType.png.identifier as CFString, 1, nil) else {
            throw UpscaleError.exportFailed
        }
        CGImageDestinationAddImage(destination, result, nil)
        guard CGImageDestinationFinalize(destination) else { throw UpscaleError.exportFailed }
        return url
    }
}
