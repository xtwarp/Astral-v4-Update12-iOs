import Foundation
import CoreML
import CoreVideo
import CoreGraphics
import ImageIO
import UniformTypeIdentifiers

final class RealESRGAN {
    enum Model: String, CaseIterable, Identifiable {
        case animevideo = "animevideo"
        case general = "general"
        case anime6B = "anime_6B"
        case x4plus = "x4plus"
        /// Aurora ×2 — 2xHFA2kCompact (Philip Hofmann, CC BY 4.0). Anime ×2, arquitectura Compact.
        case nova = "hfa2k_compact"
        /// Aurora ×4 — animerd v1 (musl, CC0-1.0). Anime ×4, arquitectura Compact.
        case quasar = "animerd"

        static let videoModels: [Model] = [.general, .nova, .animevideo, .quasar]
        static let imageModels: [Model] = [.general, .nova, .anime6B, .x4plus, .quasar]

        var id: String { rawValue }
        var displayName: String {
            switch self {
            case .animevideo: return "Real-ESRGAN AnimeVideo v3"
            case .general: return "Real-ESRGAN General x4"
            case .anime6B: return "Real-ESRGAN Anime 6B"
            case .x4plus: return "Real-ESRGAN x4plus"
            case .nova: return "Aurora ×2 (2xHFA2kCompact)"
            case .quasar: return "Aurora ×4 (animerd v1)"
            }
        }
        var shortName: String {
            switch self {
            case .animevideo: return "Anime"
            case .general: return "General"
            case .anime6B: return "Anime"
            case .x4plus: return "Plus"
            case .nova: return "Aurora"
            case .quasar: return "Aurora"
            }
        }
        /// Nombre para resúmenes (presets): Aurora comparte nombre en ×2 y ×4, así que lleva la escala.
        var summaryName: String {
            switch self {
            case .nova, .quasar: return "\(shortName) ×\(scale)"
            default: return shortName
            }
        }
        /// Para qué sirve cada modelo; se muestra bajo el selector.
        var blurb: String {
            switch self {
            case .animevideo: return tr("Especializado en anime, tardado pero muy eficiente.", "Specialized in anime, slow but very efficient.")
            case .general: return tr("Anime y vida real, tardado pero equilibrado.", "Anime and real life, slow but balanced.")
            case .anime6B: return tr("Ilustraciones y arte anime. El más detallado, pero lento.", "Anime illustrations and art. Most detailed, but slow.")
            case .x4plus: return tr("Fotos reales con mucho detalle. Pesado.", "Real photos with lots of detail. Heavy.")
            case .nova: return tr("Anime, también funciona con vida real, ligero e ideal para videos largos.", "Anime, also works on real life, light and ideal for long videos.")
            case .quasar: return tr("Anime, también funciona con vida real, ligero e ideal para videos largos.", "Anime, also works on real life, light and ideal for long videos.")
            }
        }
        var caption: String { "×\(scale)" }
        var scale: Int {
            switch self {
            case .nova: return 2
            default: return 4
            }
        }
    }

    /// Intensidad de limpieza del modelo General (mezcla con su modelo hermano "wdn", como hace Real-ESRGAN).
    /// 100 % = el modelo General normal; 0 % = el modelo "wdn", que conserva más ruido y textura.
    static let cleanupSteps = [0, 25, 50, 75, 100]
    static let defaultCleanup = 100

    /// El control solo aparece si las mezclas vienen incluidas en la app (las genera el workflow convert-sr).
    static let cleanupAvailable: Bool = cleanupSteps.filter { $0 != defaultCleanup }.allSatisfy {
        Bundle.main.url(forResource: "RealESRGAN_general_dn\($0)_522_fp16", withExtension: "mlmodelc") != nil
    }

    static let safeWorkingBytes: Int64 = 700 * 1024 * 1024

    static func exceedsSafeLimit(width: Int, height: Int, scale: Int) -> Bool {
        Int64(width * scale) * Int64(height * scale) * 16 > safeWorkingBytes
    }

    static let tileSize = 512
    static let overlap = 32
    static let prePad = 10
    static let modelSize = tileSize + prePad

    let modelKind: Model
    private let model: MLModel
    private let inputName: String
    private let outputName: String

    init(model: Model, cleanup: Int = RealESRGAN.defaultCleanup) throws {
        self.modelKind = model
        let resourceName: String
        if model == .general, cleanup != Self.defaultCleanup, Self.cleanupSteps.contains(cleanup) {
            resourceName = "RealESRGAN_general_dn\(cleanup)_522_fp16"
        } else {
            resourceName = "RealESRGAN_\(model.rawValue)_522_fp16"
        }
        guard let url = Bundle.main.url(forResource: resourceName, withExtension: "mlmodelc") else {
            throw UpscaleError.modelMissing(tr("el modelo Real-ESRGAN \(model.displayName)", "the Real-ESRGAN \(model.displayName) model"))
        }

        let configuration = MLModelConfiguration()
        configuration.computeUnits = ComputePolicy.units

        do {
            self.model = try MLModel(contentsOf: url, configuration: configuration)
        } catch {
            throw UpscaleError.coreML(tr("No se pudo cargar \(model.displayName): \(error.localizedDescription)", "Could not load \(model.displayName): \(error.localizedDescription)"))
        }

        guard let input = self.model.modelDescription.inputDescriptionsByName.keys.first,
              let output = self.model.modelDescription.outputDescriptionsByName.keys.first else {
            throw UpscaleError.coreML(tr("No se encontraron las entradas/salidas del modelo.", "The model's inputs/outputs were not found."))
        }
        inputName = input
        outputName = output
    }

    func upscale(pixelBuffer: CVPixelBuffer, isCancelled: () -> Bool) throws -> CVPixelBuffer {
        let frame = try PixelBufferTools.rgbFloatArray(from: pixelBuffer)
        let values = try upscaleRGB(frame.values, width: frame.width, height: frame.height, isCancelled: isCancelled)
        return try PixelBufferTools.makeBGRA(
            values: values,
            width: frame.width * modelKind.scale,
            height: frame.height * modelKind.scale
        )
    }

    func upscale(cgImage: CGImage, allowLarge: Bool = false, isCancelled: () -> Bool) throws -> CGImage {
        if !allowLarge, Self.exceedsSafeLimit(width: cgImage.width, height: cgImage.height, scale: modelKind.scale) {
            throw UpscaleError.frameTooLarge(width: cgImage.width, height: cgImage.height)
        }
        let frame = try Self.rgbFloatArray(from: cgImage)
        let values = try upscaleRGB(frame.values, width: frame.width, height: frame.height, isCancelled: isCancelled)
        return try Self.makeCGImage(values: values, width: frame.width * modelKind.scale, height: frame.height * modelKind.scale)
    }

    private func tileStarts(total: Int) -> [Int] {
        guard total > Self.tileSize else { return [0] }
        let stride = Self.tileSize - Self.overlap
        var result: [Int] = []
        var position = 0
        while position < total {
            if position + Self.tileSize >= total {
                result.append(total - Self.tileSize)
                break
            }
            result.append(position)
            position += stride
        }
        return result
    }

    private func reflectIndex(_ index: Int, limit: Int) -> Int {
        guard limit > 1 else { return 0 }
        let period = 2 * (limit - 1)
        var value = index % period
        if value < 0 { value += period }
        if value >= limit { value = period - value }
        return value
    }

    private func makeModelInput(source: [Float], width: Int, height: Int, x0: Int, y0: Int, tileWidth: Int, tileHeight: Int) throws -> MLMultiArray {
        let prePaddedWidth = tileWidth + Self.prePad
        let prePaddedHeight = tileHeight + Self.prePad
        guard prePaddedWidth <= Self.modelSize, prePaddedHeight <= Self.modelSize else {
            throw UpscaleError.coreML(tr("El tile supera el tamaño de entrada del modelo.", "The tile exceeds the model's input size."))
        }

        let size = Self.modelSize
        let array = try MLMultiArray(shape: [1, 3, NSNumber(value: size), NSNumber(value: size)], dataType: .float32)
        let ptr = array.dataPointer.bindMemory(to: Float32.self, capacity: 3 * size * size)
        let plane = size * size

        // Mismos índices reflejados de siempre, pero calculados una sola vez por columna y por fila (no por píxel).
        var columns = [Int](repeating: 0, count: size)
        for x in 0..<size {
            let px = reflectIndex(x, limit: prePaddedWidth)
            columns[x] = x0 + min(reflectIndex(px, limit: tileWidth), tileWidth - 1)
        }

        source.withUnsafeBufferPointer { src in
            columns.withUnsafeBufferPointer { cols in
                for y in 0..<size {
                    let py = reflectIndex(y, limit: prePaddedHeight)
                    let sy = min(reflectIndex(py, limit: tileHeight), tileHeight - 1)
                    let rowBase = (y0 + sy) * width
                    let dstRow = y * size
                    for x in 0..<size {
                        let s = (rowBase + cols[x]) * 3
                        let dst = dstRow + x
                        ptr[dst] = src[s]
                        ptr[plane + dst] = src[s + 1]
                        ptr[2 * plane + dst] = src[s + 2]
                    }
                }
            }
        }
        return array
    }

    private func predict(_ input: MLMultiArray) throws -> MLMultiArray {
        do {
            let provider = try MLDictionaryFeatureProvider(dictionary: [inputName: MLFeatureValue(multiArray: input)])
            let result = try model.prediction(from: provider)
            guard let output = result.featureValue(for: outputName)?.multiArrayValue else {
                throw UpscaleError.coreML(tr("El modelo no devolvió un MLMultiArray.", "The model did not return an MLMultiArray."))
            }
            return output
        } catch let error as UpscaleError {
            throw error
        } catch {
            throw UpscaleError.coreML(error.localizedDescription)
        }
    }

    /// Forma y pasos de la salida del modelo, validados una vez para poder leerla sin copiarla.
    private struct OutputLayout {
        let width: Int
        let height: Int
        let strideChannel: Int
        let strideY: Int
        let strideX: Int
        let isFloat16: Bool

        init(_ output: MLMultiArray) throws {
            let shape = output.shape.map(\NSNumber.intValue)
            guard shape.count == 4, shape[0] == 1, shape[1] == 3 else {
                throw UpscaleError.coreML(tr("Forma de salida inesperada: \(output.shape)", "Unexpected output shape: \(output.shape)"))
            }
            let strides = output.strides.map(\NSNumber.intValue)
            guard shape[2] > 0, shape[3] > 0, strides.count == 4 else {
                throw UpscaleError.coreML(tr("Salida del modelo inválida.", "Invalid model output."))
            }
            switch output.dataType {
            case .float32: isFloat16 = false
            case .float16: isFloat16 = true
            default:
                throw UpscaleError.coreML(tr("Tipo de salida no compatible: \(output.dataType)", "Unsupported output type: \(output.dataType)"))
            }
            height = shape[2]
            width = shape[3]
            strideChannel = strides[1]
            strideY = strides[2]
            strideX = strides[3]
        }
    }

    /// Acumuladores de la imagen final. Solo los toca la cola de mezcla (una tarea a la vez) y, al terminar, el hilo principal.
    private final class Accumulator {
        var color: [Float]
        var weight: [Float]
        init(pixels: Int) {
            color = [Float](repeating: 0, count: pixels * 3)
            weight = [Float](repeating: 0, count: pixels)
        }
    }

    /// Suma un tile ya calculado a la imagen final (mismas ventanas de mezcla y mismas cuentas que siempre).
    private static func blend(
        output: MLMultiArray, layout: OutputLayout, into acc: Accumulator,
        weightsX: [Double], weightsY: [Double],
        x0: Int, y0: Int, edgeX: Int, edgeY: Int, endX: Int, endY: Int,
        outWidth: Int, outHeight: Int
    ) {
        let lastY = max(edgeY + 1, endY)
        let lastX = max(edgeX + 1, endX)
        let sc = layout.strideChannel, sy = layout.strideY, sx = layout.strideX
        acc.color.withUnsafeMutableBufferPointer { color in
            acc.weight.withUnsafeMutableBufferPointer { weights in
                @inline(__always) func run(_ read: (Int) -> Float) {
                    for oy in edgeY..<lastY {
                        let globalY = y0 + oy
                        if globalY >= outHeight || oy >= layout.height { continue }
                        let wy = weightsY[oy]
                        for ox in edgeX..<lastX {
                            let globalX = x0 + ox
                            if globalX >= outWidth || ox >= layout.width { continue }
                            let weight = Float(max(weightsX[ox] * wy, 0.02))
                            let base = oy * sy + ox * sx
                            let dstPixel = globalY * outWidth + globalX
                            let dst = dstPixel * 3
                            color[dst] += read(base) * weight
                            color[dst + 1] += read(base + sc) * weight
                            color[dst + 2] += read(base + 2 * sc) * weight
                            weights[dstPixel] += weight
                        }
                    }
                }
                if layout.isFloat16 {
                    let ptr = output.dataPointer.bindMemory(to: UInt16.self, capacity: output.count)
                    run { Float(Float16(bitPattern: ptr[$0])) }
                } else {
                    let ptr = output.dataPointer.bindMemory(to: Float32.self, capacity: output.count)
                    run { ptr[$0] }
                }
            }
        }
    }

    /// Ventana coseno 1D de un tile (antes se calculaba con cos() para cada píxel).
    private static func windowTable(count: Int, span: Int) -> [Double] {
        let denominator = Double(max(span - 1, 1))
        return (0..<count).map { index in
            let center = min(max(Double(index) / denominator, 0), 1)
            return 0.5 - 0.5 * cos(2.0 * Double.pi * center)
        }
    }

    private func upscaleRGB(_ source: [Float], width: Int, height: Int, isCancelled: () -> Bool) throws -> [Float] {
        let scale = modelKind.scale
        let outWidth = width * scale
        let outHeight = height * scale
        let acc = Accumulator(pixels: outWidth * outHeight)

        // Mientras el modelo calcula el siguiente tile, la CPU mezcla el anterior. Solo hay una mezcla en vuelo a la vez.
        let blendQueue = DispatchQueue(label: "astral.blend", qos: .userInitiated)
        let pending = DispatchGroup()
        defer { pending.wait() }

        for y0 in tileStarts(total: height) {
            for x0 in tileStarts(total: width) {
                if isCancelled() { throw UpscaleError.cancelled }
                let tileWidth = min(Self.tileSize, width - x0)
                let tileHeight = min(Self.tileSize, height - y0)
                let input = try makeModelInput(source: source, width: width, height: height, x0: x0, y0: y0, tileWidth: tileWidth, tileHeight: tileHeight)
                let output = try predict(input)
                let layout = try OutputLayout(output)

                guard layout.width >= tileWidth * scale, layout.height >= tileHeight * scale else {
                    throw UpscaleError.coreML(tr("El modelo devolvió un tamaño inesperado.", "The model returned an unexpected size."))
                }

                let edgeX = x0 > 0 ? Self.overlap * scale / 2 : 0
                let edgeY = y0 > 0 ? Self.overlap * scale / 2 : 0
                let endX = min(tileWidth * scale, layout.width) - (x0 + tileWidth < width ? Self.overlap * scale / 2 : 0)
                let endY = min(tileHeight * scale, layout.height) - (y0 + tileHeight < height ? Self.overlap * scale / 2 : 0)
                let weightsX = Self.windowTable(count: max(edgeX + 1, endX), span: tileWidth * scale)
                let weightsY = Self.windowTable(count: max(edgeY + 1, endY), span: tileHeight * scale)
                let originX = x0 * scale
                let originY = y0 * scale

                pending.wait()   // la mezcla anterior termina antes de lanzar otra (así no se acumulan salidas en memoria)
                if isCancelled() { throw UpscaleError.cancelled }
                blendQueue.async(group: pending) {
                    Self.blend(output: output, layout: layout, into: acc, weightsX: weightsX, weightsY: weightsY,
                               x0: originX, y0: originY, edgeX: edgeX, edgeY: edgeY, endX: endX, endY: endY,
                               outWidth: outWidth, outHeight: outHeight)
                }
            }
        }
        pending.wait()

        var result = acc.color
        acc.color = []   // libera la referencia para no duplicar la imagen en memoria
        let weights = acc.weight
        acc.weight = []
        result.withUnsafeMutableBufferPointer { color in
            weights.withUnsafeBufferPointer { w in
                for i in 0..<w.count {
                    let weight = max(w[i], 1e-8)
                    color[i * 3] /= weight
                    color[i * 3 + 1] /= weight
                    color[i * 3 + 2] /= weight
                }
            }
        }
        return result
    }

    private static func rgbFloatArray(from image: CGImage) throws -> RGBFrame {
        let width = image.width
        let height = image.height
        var values = [Float](repeating: 0, count: width * height * 3)
        guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) else { throw UpscaleError.coreML(tr("No se pudo crear el espacio de color.", "Could not create the color space.")) }
        var rgba = [UInt8](repeating: 0, count: width * height * 4)
        guard let context = CGContext(data: &rgba, width: width, height: height, bitsPerComponent: 8, bytesPerRow: width * 4, space: colorSpace, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            throw UpscaleError.coreML(tr("No se pudo preparar la imagen.", "Could not prepare the image."))
        }
        context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
        values.withUnsafeMutableBufferPointer { out in
            rgba.withUnsafeBufferPointer { px in
                for i in 0..<(width * height) {
                    out[i * 3] = Float(px[i * 4]) / 255
                    out[i * 3 + 1] = Float(px[i * 4 + 1]) / 255
                    out[i * 3 + 2] = Float(px[i * 4 + 2]) / 255
                }
            }
        }
        return RGBFrame(values: values, width: width, height: height)
    }

    private static func makeCGImage(values: [Float], width: Int, height: Int) throws -> CGImage {
        var rgba = [UInt8](repeating: 255, count: width * height * 4)
        rgba.withUnsafeMutableBufferPointer { px in
            values.withUnsafeBufferPointer { v in
                for i in 0..<(width * height) {
                    px[i * 4] = toByte(v[i * 3])
                    px[i * 4 + 1] = toByte(v[i * 3 + 1])
                    px[i * 4 + 2] = toByte(v[i * 3 + 2])
                }
            }
        }
        guard let provider = CGDataProvider(data: Data(rgba) as CFData),
              let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
              let image = CGImage(width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: width * 4, space: colorSpace, bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue), provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent) else {
            throw UpscaleError.coreML(tr("No se pudo crear la imagen resultante.", "Could not create the resulting image."))
        }
        return image
    }

    private static func toByte(_ value: Float) -> UInt8 {
        UInt8((min(max(value, 0), 1) * 255).rounded())
    }
}
