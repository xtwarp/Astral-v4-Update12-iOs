import Foundation
import Security

/// Límites diarios del plan gratuito. Es el único lugar donde viven los números: para ajustarlos basta cambiarlos aquí.
enum FreeLimits {
    static let photosPerDay = 2
    static let videoSecondsPerDay: Double = 10
    static let backgroundsPerDay = 2
}

/// Lo que se ha usado hoy. Son solo números: no contiene fotos, videos ni datos personales.
struct UsageSnapshot: Codable, Equatable {
    var day: String
    var photos = 0
    var videoSeconds = 0.0
    var backgrounds = 0
    var lastSeen: Date
}

/// Contadores del plan gratuito. Se guardan en el Llavero de iOS (sobreviven a desinstalar la app, así reinstalar no reinicia el
/// límite) con una copia en UserDefaults por si el Llavero no está disponible. Solo se descuenta cuando un proceso termina bien.
@MainActor
final class UsageQuota: ObservableObject {
    static let shared = UsageQuota()

    @Published private(set) var snapshot: UsageSnapshot

    private static let service = "com.hugovela.Astral.usage"
    private static let account = "daily"
    private static let defaultsKey = "astral.usage.daily"

    private init() {
        snapshot = Self.load() ?? UsageSnapshot(day: Self.dayKey(Date()), lastSeen: Date())
    }

    // MARK: - Día actual

    private static func dayKey(_ date: Date) -> String {
        let parts = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", parts.year ?? 0, parts.month ?? 0, parts.day ?? 0)
    }

    /// Instante que se usa como "ahora". Si alguien atrasa el reloj del iPhone para reiniciar el límite, se sigue en el último
    /// día visto (solo si la diferencia es pequeña, para no castigar a quien se equivocó con la fecha por mucho tiempo).
    private var effectiveNow: Date {
        let now = Date()
        if snapshot.lastSeen > now, snapshot.lastSeen.timeIntervalSince(now) < 3 * 86_400 { return snapshot.lastSeen }
        return now
    }

    /// Uso de hoy sin modificar nada (si el día cambió, empieza de cero).
    private func today() -> UsageSnapshot {
        let now = effectiveNow
        let key = Self.dayKey(now)
        return snapshot.day == key ? snapshot : UsageSnapshot(day: key, lastSeen: now)
    }

    // MARK: - Consultas

    var remainingPhotos: Int { max(FreeLimits.photosPerDay - today().photos, 0) }
    var remainingBackgrounds: Int { max(FreeLimits.backgroundsPerDay - today().backgrounds, 0) }
    var remainingVideoSeconds: Double { max(FreeLimits.videoSecondsPerDay - today().videoSeconds, 0) }

    /// Hora a la que se reinician los límites (la próxima medianoche del iPhone).
    var nextResetDate: Date {
        let calendar = Calendar.current
        let start = calendar.startOfDay(for: effectiveNow)
        return calendar.date(byAdding: .day, value: 1, to: start) ?? start.addingTimeInterval(86_400)
    }

    var resetTimeText: String {
        nextResetDate.formatted(date: .omitted, time: .shortened)
    }

    /// Fuerza a las vistas a releer los contadores (al volver a la app, por si pasó la medianoche).
    func touch() { objectWillChange.send() }

    // MARK: - Descuentos (solo cuando el proceso terminó bien)

    func commitPhotos(_ count: Int = 1) {
        var current = today()
        current.photos += max(count, 0)
        save(current)
    }

    func commitBackgrounds(_ count: Int = 1) {
        var current = today()
        current.backgrounds += max(count, 0)
        save(current)
    }

    func commitVideoSeconds(_ seconds: Double) {
        var current = today()
        current.videoSeconds += max(seconds, 0)
        save(current)
    }

    /// Solo para compilaciones de pruebas.
    func resetForTesting() {
        save(UsageSnapshot(day: Self.dayKey(Date()), lastSeen: Date()))
    }

    private func save(_ value: UsageSnapshot) {
        var next = value
        next.lastSeen = max(Date(), value.lastSeen)
        snapshot = next
        guard let data = try? JSONEncoder().encode(next) else { return }
        Self.keychainWrite(data)
        UserDefaults.standard.set(data, forKey: Self.defaultsKey)
    }

    // MARK: - Llavero

    private static func load() -> UsageSnapshot? {
        if let data = keychainRead(), let value = try? JSONDecoder().decode(UsageSnapshot.self, from: data) { return value }
        if let data = UserDefaults.standard.data(forKey: defaultsKey),
           let value = try? JSONDecoder().decode(UsageSnapshot.self, from: data) { return value }
        return nil
    }

    private static func baseQuery() -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: account]
    }

    private static func keychainRead() -> Data? {
        var query = baseQuery()
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess else { return nil }
        return item as? Data
    }

    private static func keychainWrite(_ data: Data) {
        let update: [String: Any] = [kSecValueData as String: data]
        let status = SecItemUpdate(baseQuery() as CFDictionary, update as CFDictionary)
        if status == errSecItemNotFound {
            var add = baseQuery()
            add[kSecValueData as String] = data
            // Solo en este iPhone (no se sincroniza con iCloud) y disponible aunque la app se abra con el teléfono bloqueado.
            add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            SecItemAdd(add as CFDictionary, nil)
        }
    }
}
