import Foundation
import SwiftUI
import Combine

/// Compilaciones de pruebas: solo existen cuando el workflow marca `AstralTesterBuild` en el Info.plist.
/// En la compilación normal (la que se publica) la clave no existe y nada de esto se puede activar.
enum TesterMode {
    static var isEnabled: Bool {
        (Bundle.main.object(forInfoDictionaryKey: "AstralTesterBuild") as? Bool) == true
    }
}

/// Qué es gratis y qué es Pro, y si la persona tiene Pro ahora mismo.
/// Pro viene únicamente de una suscripción verificada por Apple (o del interruptor de las compilaciones de pruebas).
@MainActor
final class ProAccess: ObservableObject {
    static let shared = ProAccess()

    /// Pantalla de suscripción abierta desde cualquier punto de la app.
    @Published var showPaywall = false
    @Published var paywallReason: String?
    @Published private var storeSubscribed = false
    /// Solo tiene efecto en compilaciones de pruebas.
    @Published var simulatePro: Bool {
        didSet { UserDefaults.standard.set(simulatePro, forKey: Self.simulateKey) }
    }

    private static let simulateKey = "astral.tester.simulatePro"
    private var bag = Set<AnyCancellable>()

    var isPro: Bool { storeSubscribed || (TesterMode.isEnabled && simulatePro) }

    private init() {
        simulatePro = UserDefaults.standard.bool(forKey: Self.simulateKey)
        StoreManager.shared.$isSubscribed
            .sink { [weak self] value in self?.storeSubscribed = value }
            .store(in: &bag)
    }

    func requestPaywall(reason: String? = nil) {
        paywallReason = reason
        showPaywall = true
    }

    // MARK: - Reglas del plan gratuito

    static let freeVideoModels: Set<RealESRGAN.Model> = [.general, .nova]
    static let freeImageModels: Set<RealESRGAN.Model> = [.general, .nova]

    func isLocked(videoModel model: RealESRGAN.Model) -> Bool { !isPro && !Self.freeVideoModels.contains(model) }
    func isLocked(imageModel model: RealESRGAN.Model) -> Bool { !isPro && !Self.freeImageModels.contains(model) }
    /// Gratis: solo ×2.
    func isLocked(factor: Int) -> Bool { !isPro && factor != 2 }
    /// Salida fija (60 y 120 fps): Pro.
    var fixedFpsLocked: Bool { !isPro }
    /// Gratis: solo precisión rápida.
    func isLocked(precision: RIFEInterpolator.Precision) -> Bool { !isPro && precision != .fp16 }
    var slowMotionLocked: Bool { !isPro }
    var hdrLocked: Bool { !isPro }

    /// Mensajes para los avisos de límite.
    static func limitReason(_ kind: QuotaKind) -> String {
        switch kind {
        case .photos: return tr("Hoy ya usaste tus fotos gratis.", "You've used your free photos for today.")
        case .video: return tr("Hoy ya usaste tus segundos de video gratis.", "You've used your free video seconds for today.")
        case .background: return tr("Hoy ya usaste tus eliminaciones de fondo gratis.", "You've used your free background removals for today.")
        }
    }

    static var proOptionReason: String {
        tr("Esta opción es parte de Astral Pro.", "This option is part of Astral Pro.")
    }
}

enum QuotaKind { case photos, video, background }
