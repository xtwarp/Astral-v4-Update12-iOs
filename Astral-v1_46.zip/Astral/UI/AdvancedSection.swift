import SwiftUI

/// Apartado plegable "Avanzado": esconde los ajustes que casi nadie necesita tocar.
/// Un punto de color junto al título avisa si alguno de esos ajustes ya no tiene su valor por defecto.
struct AdvancedDisclosure<Content: View>: View {
    /// Título del apartado: "Avanzado" por defecto; Ajustes lo reutiliza también para "Caché".
    var title: String = tr("Avanzado", "Advanced")
    @Binding var isExpanded: Bool
    var isModified: Bool = false
    /// `true` cuando va dentro de otra tarjeta: sin fondo propio.
    var plain: Bool = false
    @ViewBuilder var content: () -> Content

    var body: some View {
        VStack(spacing: 0) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { isExpanded.toggle() }
            } label: {
                HStack(spacing: 8) {
                    Text(title)
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(Theme.ink(0.85))
                    if isModified {
                        Circle().fill(LocalStyle.mint).frame(width: 7, height: 7)
                    }
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Theme.ink(0.45))
                        .rotationEffect(.degrees(isExpanded ? 90 : 0))
                }
                .padding(.horizontal, plain ? 0 : 14)
                .frame(height: plain ? 34 : 46)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if isExpanded {
                VStack(alignment: .leading, spacing: 14) {
                    content()
                }
                .padding(.horizontal, plain ? 0 : 14)
                .padding(.bottom, plain ? 4 : 14)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .background(plain ? AnyShapeStyle(Color.clear) : AnyShapeStyle(Theme.fill(0.055)), in: RoundedRectangle(cornerRadius: 13))
    }
}

/// Hoja "Más herramientas": cada herramienta explica en una línea para qué sirve.
struct MoreToolsSheet: View {
    struct Item: Identifiable {
        let tab: ContentView.Tab
        let icon: String
        let title: String
        let detail: String
        var id: String { tab.rawValue }
    }

    let items: [Item]
    let current: ContentView.Tab
    let onSelect: (ContentView.Tab) -> Void

    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var themeStore = ThemeStore.shared
    @ObservedObject private var language = AppLanguageStore.shared

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text(tr("Más herramientas", "More tools"))
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundStyle(Theme.ink())
                Spacer()
                Button(tr("Cerrar", "Close")) { dismiss() }
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(LocalStyle.mint)
            }

            ForEach(items) { item in
                Button {
                    onSelect(item.tab)
                    dismiss()
                } label: {
                    HStack(spacing: 14) {
                        Image(systemName: item.icon)
                            .font(.system(size: 18, weight: .bold))
                            .foregroundStyle(Theme.onAccent)
                            .frame(width: 44, height: 44)
                            .background(LocalStyle.gradient, in: RoundedRectangle(cornerRadius: 11))
                        VStack(alignment: .leading, spacing: 3) {
                            Text(item.title)
                                .font(.system(size: 15, weight: .bold, design: .rounded))
                                .foregroundStyle(Theme.ink())
                            Text(item.detail)
                                .font(.system(size: 12, weight: .medium, design: .rounded))
                                .foregroundStyle(Theme.ink(0.55))
                                .multilineTextAlignment(.leading)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 6)
                        Image(systemName: current == item.tab ? "checkmark.circle.fill" : "chevron.right")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(current == item.tab ? LocalStyle.mint : Theme.ink(0.35))
                    }
                    .padding(12)
                    .frame(maxWidth: .infinity)
                    .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
                }
                .buttonStyle(.plain)
            }
            Spacer(minLength: 0)
        }
        .padding(18)
        .presentationDetents([.height(380)])
        .presentationDragIndicator(.visible)
        .preferredColorScheme(themeStore.theme.palette.scheme)
    }
}
