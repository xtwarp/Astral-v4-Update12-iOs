import SwiftUI

@main
struct AstralApp: App {
    /// false hasta que el usuario termina las pantallas de bienvenida (también se puede repetir desde Ajustes).
    @AppStorage("astral.onboardingDone") private var onboardingDone = false

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                if !onboardingDone {
                    OnboardingView(onFinish: {
                        withAnimation(.easeInOut(duration: 0.35)) { onboardingDone = true }
                    })
                    .transition(.opacity)
                    .zIndex(1)
                }
            }
        }
    }
}
