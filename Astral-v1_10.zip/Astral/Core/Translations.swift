import Foundation

/// Traducciones de la interfaz a los idiomas adicionales (francés, alemán, portugués e italiano).
/// La clave es el texto en inglés; los huecos `{0}`, `{1}`… son valores que se rellenan al mostrar el texto
/// (por ejemplo "Processing frame {0}/{1}"). Si falta una traducción, se muestra el inglés.
/// Para añadir un idioma: agrega su código en `AppLanguage` y una columna a cada fila de `rows`.
enum Translations {
    /// Orden de las columnas de `rows` (la columna 0 es el inglés).
    static let columns: [String: Int] = ["fr": 1, "de": 2, "pt": 3, "it": 4]

    private static let exact: [String: [String]] = {
        var map: [String: [String]] = [:]
        for row in rows where !row[0].contains("{") { map[row[0]] = row }
        return map
    }()

    /// Plantillas con huecos, de la más específica (más texto fijo) a la más general.
    private static let templates: [(regex: NSRegularExpression, row: [String])] = {
        var list: [(NSRegularExpression, [String], Int)] = []
        let placeholder = try! NSRegularExpression(pattern: "\\{(\\d)\\}")
        for row in rows where row[0].contains("{") {
            let template = row[0] as NSString
            var pattern = "^"
            var cursor = 0
            var literal = 0
            for match in placeholder.matches(in: row[0], range: NSRange(location: 0, length: template.length)) {
                let text = template.substring(with: NSRange(location: cursor, length: match.range.location - cursor))
                literal += text.count
                pattern += NSRegularExpression.escapedPattern(for: text) + "(.+?)"
                cursor = match.range.location + match.range.length
            }
            let tail = template.substring(from: cursor)
            literal += tail.count
            pattern += NSRegularExpression.escapedPattern(for: tail) + "$"
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]) {
                list.append((regex, row, literal))
            }
        }
        return list.sorted { $0.2 > $1.2 }.map { (regex: $0.0, row: $0.1) }
    }()

    /// Traduce un texto en inglés al idioma `code`. Si no hay traducción, devuelve el inglés tal cual.
    static func translate(_ english: String, to code: String) -> String {
        guard let column = columns[code] else { return english }
        if let row = exact[english] { return row[column] }
        let source = english as NSString
        let full = NSRange(location: 0, length: source.length)
        for (regex, row) in templates {
            guard let match = regex.firstMatch(in: english, range: full) else { continue }
            var result = row[column]
            for index in 0..<match.numberOfRanges - 1 {
                let range = match.range(at: index + 1)
                guard range.location != NSNotFound else { continue }
                result = result.replacingOccurrences(of: "{\(index)}", with: source.substring(with: range))
            }
            return result
        }
        return english
    }

    // [inglés, francés, alemán, portugués, italiano]
    private static let rows: [[String]] = [
        ["Could not analyze the image: {0}", "Impossible d’analyser l’image : {0}", "Das Bild konnte nicht analysiert werden: {0}", "Não foi possível analisar a imagem: {0}", "Impossibile analizzare l’immagine: {0}"],
        ["No clear subject was detected in the image.", "Aucun sujet net n’a été détecté dans l’image.", "Im Bild wurde kein klares Motiv erkannt.", "Nenhum sujeito claro foi detectado na imagem.", "Nessun soggetto chiaro rilevato nell’immagine."],
        ["Could not separate the subject: {0}", "Impossible de séparer le sujet : {0}", "Das Motiv konnte nicht freigestellt werden: {0}", "Não foi possível separar o sujeito: {0}", "Impossibile separare il soggetto: {0}"],
        ["Select an image", "Sélectionnez une image", "Wähle ein Bild aus", "Selecione uma imagem", "Seleziona un’immagine"],
        ["Image selected", "Image sélectionnée", "Bild ausgewählt", "Imagem selecionada", "Immagine selezionata"],
        ["Loading image…", "Chargement de l’image…", "Bild wird geladen …", "Carregando imagem…", "Caricamento dell’immagine…"],
        ["Could not load the image", "Impossible de charger l’image", "Das Bild konnte nicht geladen werden", "Não foi possível carregar a imagem", "Impossibile caricare l’immagine"],
        ["Could not load the image: {0}", "Impossible de charger l’image : {0}", "Das Bild konnte nicht geladen werden: {0}", "Não foi possível carregar a imagem: {0}", "Impossibile caricare l’immagine: {0}"],
        ["Removing the background…", "Suppression de l’arrière-plan…", "Hintergrund wird entfernt …", "Removendo o fundo…", "Rimozione dello sfondo…"],
        ["Done — save the result to Files", "Terminé — enregistrez le résultat dans Fichiers", "Fertig — speichere das Ergebnis in Dateien", "Pronto — salve o resultado em Arquivos", "Fatto — salva il risultato in File"],
        ["Done — saved to Photos", "Terminé — enregistré dans Photos", "Fertig — in Fotos gesichert", "Pronto — salvo em Fotos", "Fatto — salvato in Foto"],
        ["Processing image {0}/{1}…", "Traitement de l’image {0}/{1}…", "Bild {0}/{1} wird verarbeitet …", "Processando imagem {0}/{1}…", "Elaborazione dell’immagine {0}/{1}…"],
        ["Batch cancelled", "Lot annulé", "Stapel abgebrochen", "Lote cancelado", "Lotto annullato"],
        ["Batch finished", "Lot terminé", "Stapel abgeschlossen", "Lote concluído", "Lotto completato"],
        ["Cancelling…", "Annulation…", "Wird abgebrochen …", "Cancelando…", "Annullamento…"],
        ["Original", "Original", "Original", "Original", "Originale"],
        ["Vivid", "Éclatant", "Lebhaft", "Vívido", "Vivido"],
        ["Warm", "Chaud", "Warm", "Quente", "Caldo"],
        ["Cool", "Froid", "Kühl", "Frio", "Freddo"],
        ["Cinematic", "Cinéma", "Filmisch", "Cinematográfico", "Cinematografico"],
        ["B&W", "N&B", "S/W", "P&B", "B/N"],
        ["Vintage", "Vintage", "Vintage", "Vintage", "Vintage"],
        ["Choose a photo or a video", "Choisissez une photo ou une vidéo", "Wähle ein Foto oder Video aus", "Escolha uma foto ou um vídeo", "Scegli una foto o un video"],
        ["Loading…", "Chargement…", "Wird geladen …", "Carregando…", "Caricamento…"],
        ["Could not load the video", "Impossible de charger la vidéo", "Das Video konnte nicht geladen werden", "Não foi possível carregar o vídeo", "Impossibile caricare il video"],
        ["Adjust the color and export", "Ajustez la couleur et exportez", "Passe die Farbe an und exportiere", "Ajuste a cor e exporte", "Regola il colore ed esporta"],
        ["Adjust the color and save", "Ajustez la couleur et enregistrez", "Passe die Farbe an und sichere", "Ajuste a cor e salve", "Regola il colore e salva"],
        ["Could not load: {0}", "Impossible de charger : {0}", "Laden nicht möglich: {0}", "Não foi possível carregar: {0}", "Impossibile caricare: {0}"],
        ["Exporting video…", "Exportation de la vidéo…", "Video wird exportiert …", "Exportando vídeo…", "Esportazione del video…"],
        ["Done — save or share the result", "Terminé — enregistrez ou partagez le résultat", "Fertig — sichere oder teile das Ergebnis", "Pronto — salve ou compartilhe o resultado", "Fatto — salva o condividi il risultato"],
        ["Step 1/2 · ", "Étape 1/2 · ", "Schritt 1/2 · ", "Etapa 1/2 · ", "Passo 1/2 · "],
        ["Step 2/2 · Loading {0}× interpolation…", "Étape 2/2 · Chargement de l’interpolation {0}×…", "Schritt 2/2 · {0}×-Interpolation wird geladen …", "Etapa 2/2 · Carregando interpolação {0}×…", "Passo 2/2 · Caricamento dell’interpolazione {0}×…"],
        ["Step 2/2 · ", "Étape 2/2 · ", "Schritt 2/2 · ", "Etapa 2/2 · ", "Passo 2/2 · "],
        ["Improve quality", "Améliorer la qualité", "Qualität verbessern", "Melhorar a qualidade", "Migliora la qualità"],
        ["Raise fps", "Augmenter les fps", "FPS erhöhen", "Aumentar os fps", "Aumenta gli fps"],
        ["Improve quality and Raise fps", "Améliorer la qualité et augmenter les fps", "Qualität verbessern und FPS erhöhen", "Melhorar a qualidade e aumentar os fps", "Migliora la qualità e aumenta gli fps"],
        ["Select a video", "Sélectionnez une vidéo", "Wähle ein Video aus", "Selecione um vídeo", "Seleziona un video"],
        ["Too large for this model", "Trop grand pour ce modèle", "Zu groß für dieses Modell", "Grande demais para este modelo", "Troppo grande per questo modello"],
        ["Result", "Résultat", "Ergebnis", "Resultado", "Risultato"],
        ["lasts ×{0}", "dure ×{0}", "dauert ×{0}", "dura ×{0}", "dura ×{0}"],
        ["Loading video…", "Chargement de la vidéo…", "Video wird geladen …", "Carregando vídeo…", "Caricamento del video…"],
        ["Video selected", "Vidéo sélectionnée", "Video ausgewählt", "Vídeo selecionado", "Video selezionato"],
        ["Could not load the video: {0}", "Impossible de charger la vidéo : {0}", "Das Video konnte nicht geladen werden: {0}", "Não foi possível carregar o vídeo: {0}", "Impossibile caricare il video: {0}"],
        ["Done — use Save to Files to export", "Terminé — utilisez Enregistrer dans Fichiers pour exporter", "Fertig — nutze „In Dateien sichern“ zum Exportieren", "Pronto — use Salvar em Arquivos para exportar", "Fatto — usa Salva in File per esportare"],
        ["Step 1/2 · Loading {0}…", "Étape 1/2 · Chargement de {0}…", "Schritt 1/2 · {0} wird geladen …", "Etapa 1/2 · Carregando {0}…", "Passo 1/2 · Caricamento di {0}…"],
        ["Loading {0}…", "Chargement de {0}…", "{0} wird geladen …", "Carregando {0}…", "Caricamento di {0}…"],
        ["Loading {0}× interpolation…", "Chargement de l’interpolation {0}×…", "{0}×-Interpolation wird geladen …", "Carregando interpolação {0}×…", "Caricamento dell’interpolazione {0}×…"],
        ["Automatic", "Automatique", "Automatisch", "Automático", "Automatico"],
        ["Same as original", "Identique à l’original", "Wie das Original", "Igual ao original", "Come l’originale"],
        ["As it comes out of processing", "Tel qu’il sort du traitement", "So, wie es aus der Verarbeitung kommt", "Do jeito que sai do processamento", "Così come esce dall’elaborazione"],
        ["Same resolution as your video", "Même résolution que votre vidéo", "Gleiche Auflösung wie dein Video", "Mesma resolução do seu vídeo", "Stessa risoluzione del tuo video"],
        ["Downsizes if larger; never enlarges", "Réduit si plus grand ; n’agrandit jamais", "Verkleinert, wenn größer; vergrößert nie", "Reduz se for maior; nunca amplia", "Riduce se più grande; non ingrandisce mai"],
        ["The {0}×{1} image is too large to safely process at {2}× on this iPhone. If you try anyway, the app may close due to lack of memory.", "L’image de {0}×{1} est trop grande pour être traitée en toute sécurité à {2}× sur cet iPhone. Si vous insistez, l’app peut se fermer par manque de mémoire.", "Das {0}×{1}-Bild ist zu groß, um es auf diesem iPhone sicher mit {2}× zu verarbeiten. Wenn du es trotzdem versuchst, kann die App wegen Speichermangels beendet werden.", "A imagem de {0}×{1} é grande demais para ser processada com segurança a {2}× neste iPhone. Se você tentar mesmo assim, o app pode fechar por falta de memória.", "L’immagine {0}×{1} è troppo grande per essere elaborata in sicurezza a {2}× su questo iPhone. Se insisti, l’app potrebbe chiudersi per mancanza di memoria."],
        ["Processing with {0}…", "Traitement avec {0}…", "Verarbeitung mit {0} …", "Processando com {0}…", "Elaborazione con {0}…"],
        ["Preparing video…", "Préparation de la vidéo…", "Video wird vorbereitet …", "Preparando vídeo…", "Preparazione del video…"],
        ["Processing frame {0}/{1}", "Traitement de l’image {0}/{1}", "Frame {0}/{1} wird verarbeitet", "Processando frame {0}/{1}", "Elaborazione del frame {0}/{1}"],
        ["Finished", "Terminé", "Fertig", "Concluído", "Completato"],
        ["VIDEO", "VIDÉO", "VIDEO", "VÍDEO", "VIDEO"],
        ["IMAGE", "IMAGE", "BILD", "IMAGEM", "IMMAGINE"],
        ["INTERPOLATE", "INTERPOLER", "INTERPOLIEREN", "INTERPOLAR", "INTERPOLA"],
        ["BACKGROUND REMOVAL", "SUPPRESSION D’ARRIÈRE-PLAN", "HINTERGRUND ENTFERNEN", "REMOÇÃO DE FUNDO", "RIMOZIONE SFONDO"],
        ["COLOR", "COULEUR", "FARBE", "COR", "COLORE"],
        ["ON-DEVICE", "SUR L’APPAREIL", "AUF DEM GERÄT", "NO APARELHO", "SUL DISPOSITIVO"],
        ["SETTINGS", "RÉGLAGES", "EINSTELLUNGEN", "AJUSTES", "IMPOSTAZIONI"],
        ["LANGUAGE", "LANGUE", "SPRACHE", "IDIOMA", "LINGUA"],
        ["TEMPORARY CACHE", "CACHE TEMPORAIRE", "TEMPORÄRER CACHE", "CACHE TEMPORÁRIO", "CACHE TEMPORANEA"],
        ["Clear cache", "Vider le cache", "Cache leeren", "Limpar cache", "Svuota la cache"],
        ["RESULTS SAVED IN THE APP", "RÉSULTATS ENREGISTRÉS DANS L’APP", "IN DER APP GESICHERTE ERGEBNISSE", "RESULTADOS SALVOS NO APP", "RISULTATI SALVATI NELL’APP"],
        ["Delete results", "Supprimer les résultats", "Ergebnisse löschen", "Excluir resultados", "Elimina i risultati"],
        ["Results aren't saved automatically: export them before clearing the cache. Files you're currently using are kept. Everything is processed only on your device.", "Les résultats ne sont pas enregistrés automatiquement : exportez-les avant de vider le cache. Les fichiers que vous utilisez actuellement sont conservés. Tout est traité uniquement sur votre appareil.", "Ergebnisse werden nicht automatisch gesichert: Exportiere sie, bevor du den Cache leerst. Dateien, die du gerade verwendest, bleiben erhalten. Alles wird nur auf deinem Gerät verarbeitet.", "Os resultados não são salvos automaticamente: exporte-os antes de limpar o cache. Os arquivos que você está usando agora são mantidos. Tudo é processado somente no seu aparelho.", "I risultati non vengono salvati automaticamente: esportali prima di svuotare la cache. I file che stai usando ora vengono mantenuti. Tutto viene elaborato solo sul tuo dispositivo."],
        ["Delete saved results?", "Supprimer les résultats enregistrés ?", "Gesicherte Ergebnisse löschen?", "Excluir os resultados salvos?", "Eliminare i risultati salvati?"],
        ["This deletes the videos in the “Astral Results” folder (Files › On My iPhone › Astral). Anything you already exported elsewhere is untouched.", "Cela supprime les vidéos du dossier « Astral Results » (Fichiers › Sur mon iPhone › Astral). Ce que vous avez déjà exporté ailleurs n’est pas touché.", "Dadurch werden die Videos im Ordner „Astral Results“ gelöscht (Dateien › Auf meinem iPhone › Astral). Was du bereits anderswo exportiert hast, bleibt unberührt.", "Isso exclui os vídeos da pasta “Astral Results” (Arquivos › No meu iPhone › Astral). O que você já exportou para outro lugar não é afetado.", "Questo elimina i video nella cartella “Astral Results” (File › Su iPhone › Astral). Quanto hai già esportato altrove non viene toccato."],
        ["Delete", "Supprimer", "Löschen", "Excluir", "Elimina"],
        ["Cancel", "Annuler", "Abbrechen", "Cancelar", "Annulla"],
        ["Select video", "Choisir une vidéo", "Video auswählen", "Selecionar vídeo", "Seleziona video"],
        ["Select image", "Choisir une image", "Bild auswählen", "Selecionar imagem", "Seleziona immagine"],
        ["Start", "Démarrer", "Starten", "Iniciar", "Avvia"],
        ["Upscale + interpolate", "Agrandir + interpoler", "Hochskalieren + interpolieren", "Ampliar + interpolar", "Ingrandisci + interpola"],
        ["Interpolate", "Interpoler", "Interpolieren", "Interpolar", "Interpola"],
        ["Interpolate + upscale", "Interpoler + agrandir", "Interpolieren + hochskalieren", "Interpolar + ampliar", "Interpola + ingrandisci"],
        ["MODEL", "MODÈLE", "MODELL", "MODELO", "MODELLO"],
        ["INTERPOLATION FACTOR", "FACTEUR D’INTERPOLATION", "INTERPOLATIONSFAKTOR", "FATOR DE INTERPOLAÇÃO", "FATTORE DI INTERPOLAZIONE"],
        ["faster", "plus rapide", "schneller", "mais rápido", "più veloce"],
        ["smoother", "plus fluide", "flüssiger", "mais fluido", "più fluido"],
        ["PRECISION", "PRÉCISION", "GENAUIGKEIT", "PRECISÃO", "PRECISIONE"],
        ["Fast", "Rapide", "Schnell", "Rápida", "Veloce"],
        ["High", "Élevée", "Hoch", "Alta", "Alta"],
        ["Also interpolate", "Interpoler aussi", "Auch interpolieren", "Interpolar também", "Interpola anche"],
        ["Upscales and, frame by frame, generates in-between frames with RIFE afterwards", "Agrandit puis, image par image, génère ensuite des images intermédiaires avec RIFE", "Skaliert hoch und erzeugt danach Bild für Bild Zwischenbilder mit RIFE", "Amplia e, quadro a quadro, gera depois quadros intermediários com RIFE", "Ingrandisce e, fotogramma per fotogramma, genera poi i fotogrammi intermedi con RIFE"],
        ["Also upscale", "Agrandir aussi", "Auch hochskalieren", "Ampliar também", "Ingrandisci anche"],
        ["Interpolates and, frame by frame, applies Real-ESRGAN afterwards", "Interpole puis, image par image, applique ensuite Real-ESRGAN", "Interpoliert und wendet danach Bild für Bild Real-ESRGAN an", "Interpola e, quadro a quadro, aplica depois o Real-ESRGAN", "Interpola e, fotogramma per fotogramma, applica poi Real-ESRGAN"],
        ["BEFORE / AFTER", "AVANT / APRÈS", "VORHER / NACHHER", "ANTES / DEPOIS", "PRIMA / DOPO"],
        ["Save to Files", "Enregistrer dans Fichiers", "In Dateien sichern", "Salvar em Arquivos", "Salva in File"],
        ["Share / Export", "Partager / Exporter", "Teilen / Exportieren", "Compartilhar / Exportar", "Condividi / Esporta"],
        ["Real-ESRGAN processes everything on your iPhone", "Real-ESRGAN traite tout sur votre iPhone", "Real-ESRGAN verarbeitet alles auf deinem iPhone", "O Real-ESRGAN processa tudo no seu iPhone", "Real-ESRGAN elabora tutto sul tuo iPhone"],
        ["RIFE generates in-between frames on your iPhone", "RIFE génère des images intermédiaires sur votre iPhone", "RIFE erzeugt Zwischenbilder auf deinem iPhone", "O RIFE gera quadros intermediários no seu iPhone", "RIFE genera i fotogrammi intermedi sul tuo iPhone"],
        ["Try anyway", "Essayer quand même", "Trotzdem versuchen", "Tentar mesmo assim", "Prova comunque"],
        ["Everything is processed on your device", "Tout est traité sur votre appareil", "Alles wird auf deinem Gerät verarbeitet", "Tudo é processado no seu aparelho", "Tutto viene elaborato sul tuo dispositivo"],
        ["BEFORE", "AVANT", "VORHER", "ANTES", "PRIMA"],
        ["AFTER", "APRÈS", "NACHHER", "DEPOIS", "DOPO"],
        ["Allow access to Photos in Settings to save.", "Autorisez l’accès à Photos dans Réglages pour pouvoir enregistrer.", "Erlaube den Zugriff auf Fotos in den Einstellungen, um sichern zu können.", "Permita o acesso a Fotos em Ajustes para poder salvar.", "Consenti l’accesso a Foto nelle Impostazioni per poter salvare."],
        ["Could not prepare the image for saving.", "Impossible de préparer l’image pour l’enregistrement.", "Das Bild konnte nicht zum Sichern vorbereitet werden.", "Não foi possível preparar a imagem para salvar.", "Impossibile preparare l’immagine per il salvataggio."],
        ["Share", "Partager", "Teilen", "Compartilhar", "Condividi"],
        ["Saved to Photos", "Enregistré dans Photos", "In Fotos gesichert", "Salvo em Fotos", "Salvato in Foto"],
        ["Save to Photos", "Enregistrer dans Photos", "In Fotos sichern", "Salvar em Fotos", "Salva in Foto"],
        ["Could not resize the frame for interpolation.", "Impossible de redimensionner l’image pour l’interpolation.", "Das Frame konnte für die Interpolation nicht skaliert werden.", "Não foi possível redimensionar o quadro para a interpolação.", "Impossibile ridimensionare il fotogramma per l’interpolazione."],
        ["slow motion", "ralenti", "Zeitlupe", "câmera lenta", "slow motion"],
        ["Video", "Vidéo", "Video", "Vídeo", "Video"],
        ["Image", "Image", "Bild", "Imagem", "Immagine"],
        ["no adjustments", "sans réglages", "keine Anpassungen", "sem ajustes", "nessuna regolazione"],
        ["adjusted", "ajustée", "angepasst", "ajustada", "regolata"],
        ["High precision", "Haute précision", "Hohe Genauigkeit", "Alta precisão", "Alta precisione"],
        ["slower", "plus lent", "langsamer", "mais lento", "più lento"],
        ["1920×1152 landscape or 1152×1920 portrait", "1920×1152 en paysage ou 1152×1920 en portrait", "1920×1152 im Querformat oder 1152×1920 im Hochformat", "1920×1152 na horizontal ou 1152×1920 na vertical", "1920×1152 in orizzontale o 1152×1920 in verticale"],
        ["the RIFE interpolation model ({0})", "le modèle d’interpolation RIFE ({0})", "das RIFE-Interpolationsmodell ({0})", "o modelo de interpolação RIFE ({0})", "il modello di interpolazione RIFE ({0})"],
        ["Could not load the interpolation model: {0}", "Impossible de charger le modèle d’interpolation : {0}", "Das Interpolationsmodell konnte nicht geladen werden: {0}", "Não foi possível carregar o modelo de interpolação: {0}", "Impossibile caricare il modello di interpolazione: {0}"],
        ["The two frames to interpolate have different sizes.", "Les deux images à interpoler ont des tailles différentes.", "Die beiden zu interpolierenden Frames haben unterschiedliche Größen.", "Os dois quadros a interpolar têm tamanhos diferentes.", "I due fotogrammi da interpolare hanno dimensioni diverse."],
        ["the RIFE interpolation model", "le modèle d’interpolation RIFE", "das RIFE-Interpolationsmodell", "o modelo de interpolação RIFE", "il modello di interpolazione RIFE"],
        ["The interpolation model returned no result.", "Le modèle d’interpolation n’a renvoyé aucun résultat.", "Das Interpolationsmodell hat kein Ergebnis geliefert.", "O modelo de interpolação não retornou nenhum resultado.", "Il modello di interpolazione non ha restituito alcun risultato."],
        ["Unexpected output shape: {0}", "Forme de sortie inattendue : {0}", "Unerwartete Ausgabeform: {0}", "Formato de saída inesperado: {0}", "Forma di output inattesa: {0}"],
        ["The interpolation model returned an unexpected size.", "Le modèle d’interpolation a renvoyé une taille inattendue.", "Das Interpolationsmodell hat eine unerwartete Größe geliefert.", "O modelo de interpolação retornou um tamanho inesperado.", "Il modello di interpolazione ha restituito una dimensione inattesa."],
        ["Invalid model output.", "Sortie du modèle invalide.", "Ungültige Modellausgabe.", "Saída do modelo inválida.", "Output del modello non valido."],
        ["Unsupported output type: {0}", "Type de sortie non pris en charge : {0}", "Nicht unterstützter Ausgabetyp: {0}", "Tipo de saída não compatível: {0}", "Tipo di output non supportato: {0}"],
        ["Anime and animation video. Fast and light.", "Vidéo anime et animation. Rapide et léger.", "Anime- und Animationsvideo. Schnell und leicht.", "Vídeo de anime e animação. Rápido e leve.", "Video anime e animazione. Veloce e leggero."],
        ["Real photos and video. Balanced.", "Photos et vidéos réelles. Équilibré.", "Echte Fotos und Videos. Ausgewogen.", "Fotos e vídeos reais. Equilibrado.", "Foto e video reali. Equilibrato."],
        ["Anime illustrations and art. Most detailed, but slow.", "Illustrations et art anime. Le plus détaillé, mais lent.", "Anime-Illustrationen und -Kunst. Am detailreichsten, aber langsam.", "Ilustrações e arte de anime. O mais detalhado, porém lento.", "Illustrazioni e arte anime. Il più dettagliato, ma lento."],
        ["Real photos with lots of detail. Heavy.", "Photos réelles très détaillées. Lourd.", "Echte Fotos mit vielen Details. Rechenintensiv.", "Fotos reais com muitos detalhes. Pesado.", "Foto reali con molti dettagli. Pesante."],
        ["Anime at double size. Light, ideal for long videos or older iPhones.", "Anime en taille double. Léger, idéal pour les longues vidéos ou les anciens iPhone.", "Anime in doppelter Größe. Leicht, ideal für lange Videos oder ältere iPhones.", "Anime em tamanho duplo. Leve, ideal para vídeos longos ou iPhones mais antigos.", "Anime a dimensione doppia. Leggero, ideale per video lunghi o iPhone meno recenti."],
        ["Anime at 4× size, with sharper lines.", "Anime en taille 4×, avec des lignes plus nettes.", "Anime in 4-facher Größe, mit schärferen Linien.", "Anime em tamanho 4×, com linhas mais nítidas.", "Anime a dimensione 4×, con linee più nitide."],
        ["the Real-ESRGAN {0} model", "le modèle Real-ESRGAN {0}", "das Real-ESRGAN-Modell {0}", "o modelo Real-ESRGAN {0}", "il modello Real-ESRGAN {0}"],
        ["Could not load {0}: {1}", "Impossible de charger {0} : {1}", "{0} konnte nicht geladen werden: {1}", "Não foi possível carregar {0}: {1}", "Impossibile caricare {0}: {1}"],
        ["The model's inputs/outputs were not found.", "Les entrées/sorties du modèle sont introuvables.", "Die Ein-/Ausgänge des Modells wurden nicht gefunden.", "As entradas/saídas do modelo não foram encontradas.", "Gli ingressi/uscite del modello non sono stati trovati."],
        ["The tile exceeds the model's input size.", "Le bloc dépasse la taille d’entrée du modèle.", "Die Kachel überschreitet die Eingabegröße des Modells.", "O bloco excede o tamanho de entrada do modelo.", "Il blocco supera la dimensione di input del modello."],
        ["The model did not return an MLMultiArray.", "Le modèle n’a pas renvoyé de MLMultiArray.", "Das Modell hat kein MLMultiArray geliefert.", "O modelo não retornou um MLMultiArray.", "Il modello non ha restituito un MLMultiArray."],
        ["The model returned an unexpected size.", "Le modèle a renvoyé une taille inattendue.", "Das Modell hat eine unerwartete Größe geliefert.", "O modelo retornou um tamanho inesperado.", "Il modello ha restituito una dimensione inattesa."],
        ["Could not create the color space.", "Impossible de créer l’espace colorimétrique.", "Der Farbraum konnte nicht erstellt werden.", "Não foi possível criar o espaço de cor.", "Impossibile creare lo spazio colore."],
        ["Could not prepare the image.", "Impossible de préparer l’image.", "Das Bild konnte nicht vorbereitet werden.", "Não foi possível preparar a imagem.", "Impossibile preparare l’immagine."],
        ["Could not create the resulting image.", "Impossible de créer l’image résultante.", "Das Ergebnisbild konnte nicht erstellt werden.", "Não foi possível criar a imagem resultante.", "Impossibile creare l’immagine risultante."],
        ["Neon", "Néon", "Neon", "Neon", "Neon"],
        ["Black", "Noir", "Schwarz", "Preto", "Nero"],
        ["Light", "Clair", "Hell", "Claro", "Chiaro"],
        ["The classic", "Le classique", "Der Klassiker", "O clássico", "Il classico"],
        ["Pure black", "Noir pur", "Reines Schwarz", "Preto puro", "Nero puro"],
        ["Light background", "Fond clair", "Heller Hintergrund", "Fundo claro", "Sfondo chiaro"],
        ["Could not open the video.", "Impossible d’ouvrir la vidéo.", "Das Video konnte nicht geöffnet werden.", "Não foi possível abrir o vídeo.", "Impossibile aprire il video."],
        ["{0} is missing from this build. Run the build again to include it.", "{0} est absent de cette version. Relancez la compilation pour l’inclure.", "{0} fehlt in diesem Build. Führe den Build erneut aus, um es einzubinden.", "{0} não está incluído nesta versão. Execute o build novamente para incluí-lo.", "{0} non è presente in questa build. Esegui di nuovo la build per includerlo."],
        ["The video uses an unsupported pixel format.", "La vidéo utilise un format de pixel non pris en charge.", "Das Video verwendet ein nicht unterstütztes Pixelformat.", "O vídeo usa um formato de pixel incompatível.", "Il video usa un formato pixel non supportato."],
        ["Processing cancelled.", "Traitement annulé.", "Verarbeitung abgebrochen.", "Processamento cancelado.", "Elaborazione annullata."],
        ["Could not read the video.", "Impossible de lire la vidéo.", "Das Video konnte nicht gelesen werden.", "Não foi possível ler o vídeo.", "Impossibile leggere il video."],
        ["Could not write the video.", "Impossible d’écrire la vidéo.", "Das Video konnte nicht geschrieben werden.", "Não foi possível gravar o vídeo.", "Impossibile scrivere il video."],
        ["Could not finalize the video file.", "Impossible de finaliser le fichier vidéo.", "Die Videodatei konnte nicht abgeschlossen werden.", "Não foi possível finalizar o arquivo de vídeo.", "Impossibile finalizzare il file video."],
        ["The {0}×{1} frame is too large to safely process at 4× on this iPhone.", "L’image vidéo de {0}×{1} est trop grande pour être traitée en toute sécurité à 4× sur cet iPhone.", "Das {0}×{1}-Frame ist zu groß, um es auf diesem iPhone sicher mit 4× zu verarbeiten.", "O quadro de {0}×{1} é grande demais para ser processado com segurança a 4× neste iPhone.", "Il fotogramma {0}×{1} è troppo grande per essere elaborato in sicurezza a 4× su questo iPhone."],
        ["The {0}×{1} video exceeds the maximum size for interpolation ({2}).", "La vidéo de {0}×{1} dépasse la taille maximale pour l’interpolation ({2}).", "Das {0}×{1}-Video überschreitet die maximale Größe für die Interpolation ({2}).", "O vídeo de {0}×{1} excede o tamanho máximo para interpolação ({2}).", "Il video {0}×{1} supera la dimensione massima per l’interpolazione ({2})."],
        ["Processing stalled (likely the iPhone's memory limit or heat). Try a shorter video, or close it and try again.", "Le traitement s’est bloqué (probablement à cause de la limite de mémoire ou de la chaleur de l’iPhone). Essayez une vidéo plus courte, ou fermez-la et réessayez.", "Die Verarbeitung ist hängen geblieben (wahrscheinlich wegen Speichergrenze oder Hitze des iPhones). Versuche ein kürzeres Video oder schließe es und versuche es erneut.", "O processamento travou (provavelmente pelo limite de memória ou pelo calor do iPhone). Tente um vídeo mais curto ou feche-o e tente de novo.", "L’elaborazione si è bloccata (probabilmente per il limite di memoria o il calore dell’iPhone). Prova con un video più breve, oppure chiudilo e riprova."],
        ["Advanced", "Avancé", "Erweitert", "Avançado", "Avanzate"],
        ["More tools", "Plus d’outils", "Weitere Werkzeuge", "Mais ferramentas", "Altri strumenti"],
        ["Close", "Fermer", "Schließen", "Fechar", "Chiudi"],
        ["VIDEO ENHANCEMENTS", "AMÉLIORATIONS VIDÉO", "VIDEO-VERBESSERUNGEN", "MELHORIAS DE VÍDEO", "MIGLIORAMENTI VIDEO"],
        ["Video enhance", "Amélioration vidéo", "Video-Verbesserung", "Melhoria de vídeo", "Miglioramento video"],
        ["Enhance image", "Améliorer l’image", "Bild verbessern", "Melhorar imagem", "Migliora immagine"],
        ["Remove background", "Supprimer l’arrière-plan", "Hintergrund entfernen", "Remover fundo", "Rimuovi sfondo"],
        ["Adjust color", "Ajuster la couleur", "Farbe anpassen", "Ajustar cor", "Regola il colore"],
        ["More quality and more fps in your videos", "Plus de qualité et plus de fps dans vos vidéos", "Mehr Qualität und mehr FPS in deinen Videos", "Mais qualidade e mais fps nos seus vídeos", "Più qualità e più fps nei tuoi video"],
        ["Upscale and sharpen photos up to 4×", "Agrandissez et affinez vos photos jusqu’à 4×", "Vergrößere und schärfe Fotos bis zu 4×", "Amplie e melhore fotos até 4×", "Ingrandisci e migliora le foto fino a 4×"],
        ["Keep only the subject, on a transparent background", "Ne gardez que le sujet, sur fond transparent", "Behalte nur das Motiv, auf transparentem Hintergrund", "Mantenha só o sujeito, com fundo transparente", "Mantieni solo il soggetto, su sfondo trasparente"],
        ["Looks and adjustments for photos and videos", "Styles et réglages pour photos et vidéos", "Looks und Anpassungen für Fotos und Videos", "Estilos e ajustes para fotos e vídeos", "Stili e regolazioni per foto e video"],
        ["MORE TOOLS", "PLUS D’OUTILS", "WEITERE WERKZEUGE", "MAIS FERRAMENTAS", "ALTRI STRUMENTI"],
        ["Choose what to do", "Choisissez quoi faire", "Wähle, was du tun möchtest", "Escolha o que fazer", "Scegli cosa fare"],
        ["Enhance + raise fps", "Améliorer + augmenter les fps", "Verbessern + FPS erhöhen", "Melhorar + aumentar os fps", "Migliora + aumenta gli fps"],
        ["Tap to choose what to do", "Touchez pour choisir quoi faire", "Tippe, um auszuwählen, was du tun möchtest", "Toque para escolher o que fazer", "Tocca per scegliere cosa fare"],
        ["Slow motion", "Ralenti", "Zeitlupe", "Câmera lenta", "Slow motion"],
        ["The video lasts ×{0} longer", "La vidéo dure ×{0} plus longtemps", "Das Video dauert ×{0} länger", "O vídeo dura ×{0} mais", "Il video dura ×{0} di più"],
        ["Keeps the duration and raises the fps", "Conserve la durée et augmente les fps", "Behält die Dauer bei und erhöht die FPS", "Mantém a duração e aumenta os fps", "Mantiene la durata e aumenta gli fps"],
        ["EXPORT RESOLUTION", "RÉSOLUTION D’EXPORTATION", "EXPORTAUFLÖSUNG", "RESOLUÇÃO DE EXPORTAÇÃO", "RISOLUZIONE DI ESPORTAZIONE"],
        ["Cancel batch", "Annuler le lot", "Stapel abbrechen", "Cancelar lote", "Annulla lotto"],
        ["Choose photo or video", "Choisir une photo ou une vidéo", "Foto oder Video auswählen", "Escolher foto ou vídeo", "Scegli foto o video"],
        ["Exporting…", "Exportation…", "Export läuft …", "Exportando…", "Esportazione…"],
        ["Export video", "Exporter la vidéo", "Video exportieren", "Exportar vídeo", "Esporta video"],
        ["Color adjustment", "Réglage des couleurs", "Farbanpassung", "Ajuste de cor", "Regolazione del colore"],
        ["Hold to see the original", "Maintenez pour voir l’original", "Gedrückt halten für das Original", "Segure para ver o original", "Tieni premuto per vedere l’originale"],
        ["LOOKS", "STYLES", "LOOKS", "ESTILOS", "STILI"],
        ["ADJUSTMENTS", "RÉGLAGES", "ANPASSUNGEN", "AJUSTES", "REGOLAZIONI"],
        ["Reset", "Réinitialiser", "Zurücksetzen", "Redefinir", "Ripristina"],
        ["Exposure", "Exposition", "Belichtung", "Exposição", "Esposizione"],
        ["Contrast", "Contraste", "Kontrast", "Contraste", "Contrasto"],
        ["Saturation", "Saturation", "Sättigung", "Saturação", "Saturazione"],
        ["Temperature", "Température", "Temperatur", "Temperatura", "Temperatura"],
        ["Brightness", "Luminosité", "Helligkeit", "Brilho", "Luminosità"],
        ["Vibrance", "Éclat", "Lebendigkeit", "Vibração", "Vividezza"],
        ["Tint", "Teinte", "Tönung", "Matiz", "Tinta"],
        ["Highlights", "Hautes lumières", "Lichter", "Realces", "Alte luci"],
        ["Shadows", "Ombres", "Schatten", "Sombras", "Ombre"],
        ["Noise reduction", "Réduction du bruit", "Rauschunterdrückung", "Redução de ruído", "Riduzione del rumore"],
        ["Sharpness", "Netteté", "Schärfe", "Nitidez", "Nitidezza"],
        ["Vignette", "Vignettage", "Vignette", "Vinheta", "Vignettatura"],
        ["Batch process", "Traitement par lots", "Stapelverarbeitung", "Processar em lote", "Elabora in batch"],
        ["trained on musl's HFA2k dataset", "entraîné sur le jeu de données HFA2k de musl", "trainiert mit musls HFA2k-Datensatz", "treinado com o conjunto de dados HFA2k de musl", "addestrato sul dataset HFA2k di musl"],
        ["Converted to Core ML (fp16) for use in this app.", "Converti en Core ML (fp16) pour cette app.", "Für diese App in Core ML (fp16) konvertiert.", "Convertido para Core ML (fp16) para uso neste app.", "Convertito in Core ML (fp16) per l’uso in questa app."],
        ["Frame interpolation", "Interpolation d’images", "Frame-Interpolation", "Interpolação de quadros", "Interpolazione dei fotogrammi"],
        ["Reference code", "Code de référence", "Referenzcode", "Código de referência", "Codice di riferimento"],
        ["CREDITS & LICENSES", "CRÉDITS ET LICENCES", "CREDITS UND LIZENZEN", "CRÉDITOS E LICENÇAS", "CREDITI E LICENZE"],
        ["Author", "Auteur", "Autor", "Autor", "Autore"],
        ["License", "Licence", "Lizenz", "Licença", "Licenza"],
        ["estimating…", "estimation…", "Schätzung …", "estimando…", "stima in corso…"],
        ["Welcome to", "Bienvenue dans", "Willkommen bei", "Boas-vindas ao", "Ti diamo il benvenuto in"],
        ["Astral enhances your videos and photos right on your iPhone. Increase the resolution, smooth the motion with more fps, remove backgrounds and adjust the color, all with artificial intelligence that works offline.", "Astral améliore vos vidéos et photos directement sur votre iPhone. Augmentez la résolution, fluidifiez le mouvement avec plus de fps, supprimez les arrière-plans et ajustez la couleur, le tout grâce à une intelligence artificielle qui fonctionne hors ligne.", "Astral verbessert deine Videos und Fotos direkt auf deinem iPhone. Erhöhe die Auflösung, glätte Bewegungen mit mehr FPS, entferne Hintergründe und passe die Farbe an – alles mit künstlicher Intelligenz, die offline funktioniert.", "O Astral melhora seus vídeos e fotos direto no seu iPhone. Aumente a resolução, suavize o movimento com mais fps, remova fundos e ajuste a cor, tudo com inteligência artificial que funciona offline.", "Astral migliora i tuoi video e le tue foto direttamente sul tuo iPhone. Aumenta la risoluzione, rendi il movimento più fluido con più fps, rimuovi gli sfondi e regola il colore, tutto con un’intelligenza artificiale che funziona offline."],
        ["Privacy", "Confidentialité", "Datenschutz", "Privacidade", "Privacy"],
        ["Your videos and photos never leave your iPhone. The AI models come inside the app and run on your device: nothing is uploaded to the internet, you don't need an account, and Astral doesn't collect personal data or use analytics or ads.\n\nTo save a result to Photos, iOS will ask for permission to add only. Results stay wherever you decide.", "Vos vidéos et photos ne quittent jamais votre iPhone. Les modèles d’IA sont inclus dans l’app et fonctionnent sur votre appareil : rien n’est envoyé sur internet, vous n’avez pas besoin de compte, et Astral ne collecte aucune donnée personnelle et n’utilise ni analyses ni publicités.\n\nPour enregistrer un résultat dans Photos, iOS vous demandera uniquement l’autorisation d’ajouter. Les résultats restent là où vous le décidez.", "Deine Videos und Fotos verlassen niemals dein iPhone. Die KI-Modelle sind in der App enthalten und laufen auf deinem Gerät: Es wird nichts ins Internet hochgeladen, du brauchst kein Konto, und Astral sammelt keine personenbezogenen Daten und verwendet weder Analysen noch Werbung.\n\nZum Sichern eines Ergebnisses in Fotos fragt iOS nur nach der Erlaubnis zum Hinzufügen. Die Ergebnisse bleiben dort, wo du es bestimmst.", "Seus vídeos e fotos nunca saem do seu iPhone. Os modelos de IA vêm dentro do app e funcionam no seu aparelho: nada é enviado para a internet, você não precisa criar uma conta e o Astral não coleta dados pessoais nem usa análises ou anúncios.\n\nPara salvar um resultado em Fotos, o iOS pedirá permissão somente para adicionar. Os resultados ficam onde você decidir.", "I tuoi video e le tue foto non lasciano mai il tuo iPhone. I modelli di IA sono inclusi nell’app e funzionano sul tuo dispositivo: non viene caricato nulla su internet, non serve un account e Astral non raccoglie dati personali né usa analisi o pubblicità.\n\nPer salvare un risultato in Foto, iOS chiederà solo l’autorizzazione ad aggiungere. I risultati restano dove decidi tu."],
        ["Read the privacy policy", "Lire la politique de confidentialité", "Datenschutzerklärung lesen", "Ler a política de privacidade", "Leggi l’informativa sulla privacy"],
        ["What you can do", "Ce que vous pouvez faire", "Das kannst du tun", "O que você pode fazer", "Cosa puoi fare"],
        ["Everything in one place", "Tout au même endroit", "Alles an einem Ort", "Tudo em um só lugar", "Tutto in un unico posto"],
        ["Video enhancement", "Amélioration vidéo", "Video-Verbesserung", "Melhoria de vídeo", "Miglioramento video"],
        ["Improve the quality, increase the fps and add slow motion.", "Améliorez la qualité, augmentez les fps et ajoutez du ralenti.", "Verbessere die Qualität, erhöhe die FPS und füge Zeitlupe hinzu.", "Melhore a qualidade, aumente os fps e adicione câmera lenta.", "Migliora la qualità, aumenta gli fps e aggiungi slow motion."],
        ["Improve the quality of your photos with AI.", "Améliorez la qualité de vos photos grâce à l’IA.", "Verbessere die Qualität deiner Fotos mit KI.", "Melhore a qualidade das suas fotos com IA.", "Migliora la qualità delle tue foto con l’IA."],
        ["Background removal", "Suppression d’arrière-plan", "Hintergrund entfernen", "Remoção de fundo", "Rimozione dello sfondo"],
        ["Cut out people and objects instantly.", "Détourez personnes et objets instantanément.", "Stelle Personen und Objekte sofort frei.", "Recorte pessoas e objetos na hora.", "Ritaglia persone e oggetti all’istante."],
        ["Color", "Couleur", "Farbe", "Cor", "Colore"],
        ["Adjust light and color in photos and videos.", "Ajustez la lumière et la couleur de vos photos et vidéos.", "Passe Licht und Farbe in Fotos und Videos an.", "Ajuste a luz e a cor em fotos e vídeos.", "Regola luce e colore in foto e video."],
        ["Get started", "Commencer", "Los geht’s", "Começar", "Inizia"],
        ["Next", "Suivant", "Weiter", "Avançar", "Avanti"],
        ["Save current settings", "Enregistrer les réglages actuels", "Aktuelle Einstellungen sichern", "Salvar ajustes atuais", "Salva le impostazioni attuali"],
        ["Preset name", "Nom du préréglage", "Name der Vorgabe", "Nome do preset", "Nome del preset"],
        ["Save", "Enregistrer", "Sichern", "Salvar", "Salva"],
        ["My presets", "Mes préréglages", "Meine Vorgaben", "Meus presets", "I miei preset"],
        ["You have no presets yet.", "Vous n’avez pas encore de préréglage.", "Du hast noch keine Vorgaben.", "Você ainda não tem presets.", "Non hai ancora nessun preset."],
        ["Each preset saves your Video enhance, Image and Color settings. Tap one to apply it; swipe left to delete it.", "Chaque préréglage enregistre vos réglages Amélioration vidéo, Image et Couleur. Touchez-en un pour l’appliquer ; balayez vers la gauche pour le supprimer.", "Jede Vorgabe sichert deine Einstellungen für Video-Verbesserung, Bild und Farbe. Tippe auf eine, um sie anzuwenden; wische nach links, um sie zu löschen.", "Cada preset salva seus ajustes de Melhoria de vídeo, Imagem e Cor. Toque em um para aplicá-lo; deslize para a esquerda para excluí-lo.", "Ogni preset salva le tue impostazioni di Miglioramento video, Immagine e Colore. Toccane uno per applicarlo; scorri verso sinistra per eliminarlo."],
        ["Batch", "Lot", "Stapel", "Lote", "Batch"],
        ["Keep the app open; the screen won't sleep during the batch.", "Gardez l’app ouverte ; l’écran ne se mettra pas en veille pendant le lot.", "Lass die App geöffnet; der Bildschirm schaltet sich während des Stapels nicht aus.", "Mantenha o app aberto; a tela não vai apagar durante o lote.", "Tieni aperta l’app; lo schermo non si spegne durante il batch."],
        ["failed", "échec", "fehlgeschlagen", "falhou", "non riuscito"],
        ["Save them now: they're deleted when you clear the cache.", "Enregistrez-les maintenant : ils sont supprimés quand vous videz le cache.", "Sichere sie jetzt: Sie werden gelöscht, wenn du den Cache leerst.", "Salve-os agora: eles são excluídos quando você limpa o cache.", "Salvali ora: vengono eliminati quando svuoti la cache."],
        ["Summary", "Résumé", "Zusammenfassung", "Resumo", "Riepilogo"],
        ["Astral processes everything on your device. Your videos and photos are not uploaded to any server and the app does not collect personal data.", "Astral traite tout sur votre appareil. Vos vidéos et photos ne sont envoyées à aucun serveur et l’app ne collecte aucune donnée personnelle.", "Astral verarbeitet alles auf deinem Gerät. Deine Videos und Fotos werden an keinen Server hochgeladen, und die App sammelt keine personenbezogenen Daten.", "O Astral processa tudo no seu aparelho. Seus vídeos e fotos não são enviados a nenhum servidor e o app não coleta dados pessoais.", "Astral elabora tutto sul tuo dispositivo. I tuoi video e le tue foto non vengono caricati su nessun server e l’app non raccoglie dati personali."],
        ["What the app uses", "Ce que l’app utilise", "Was die App verwendet", "O que o app usa", "Cosa usa l’app"],
        ["The videos and photos you choose to process, the results it creates and your settings (theme, language and presets). Everything is stored only on your iPhone.", "Les vidéos et photos que vous choisissez de traiter, les résultats qu’elle crée et vos réglages (thème, langue et préréglages). Tout est stocké uniquement sur votre iPhone.", "Die Videos und Fotos, die du zur Verarbeitung auswählst, die von ihr erstellten Ergebnisse und deine Einstellungen (Design, Sprache und Vorgaben). Alles wird nur auf deinem iPhone gespeichert.", "Os vídeos e fotos que você escolhe processar, os resultados que ela cria e seus ajustes (tema, idioma e presets). Tudo é armazenado somente no seu iPhone.", "I video e le foto che scegli di elaborare, i risultati che crea e le tue impostazioni (tema, lingua e preset). Tutto viene memorizzato solo sul tuo iPhone."],
        ["What it doesn't do", "Ce qu’elle ne fait pas", "Was sie nicht tut", "O que ele não faz", "Cosa non fa"],
        ["It doesn't upload your files to the internet, doesn't ask for an account or sign-up, doesn't use analytics or tracking, doesn't show ads and doesn't share information with third parties.", "Elle n’envoie pas vos fichiers sur internet, ne demande ni compte ni inscription, n’utilise ni analyses ni suivi, n’affiche pas de publicités et ne partage aucune information avec des tiers.", "Sie lädt deine Dateien nicht ins Internet hoch, verlangt weder Konto noch Registrierung, verwendet weder Analysen noch Tracking, zeigt keine Werbung und gibt keine Informationen an Dritte weiter.", "Ele não envia seus arquivos para a internet, não pede conta nem cadastro, não usa análises nem rastreamento, não exibe anúncios e não compartilha informações com terceiros.", "Non carica i tuoi file su internet, non richiede account né registrazione, non usa analisi o tracciamento, non mostra pubblicità e non condivide informazioni con terzi."],
        ["Photos permissions", "Autorisations Photos", "Berechtigungen für Fotos", "Permissões de Fotos", "Autorizzazioni per Foto"],
        ["To choose photos and videos, Astral uses the iOS picker, so it only receives what you select. To save a result to Photos, iOS asks for permission to add content only.", "Pour choisir des photos et vidéos, Astral utilise le sélecteur d’iOS : elle ne reçoit donc que ce que vous sélectionnez. Pour enregistrer un résultat dans Photos, iOS demande uniquement l’autorisation d’ajouter du contenu.", "Zum Auswählen von Fotos und Videos nutzt Astral die iOS-Auswahl und erhält daher nur, was du auswählst. Zum Sichern eines Ergebnisses in Fotos fragt iOS nur nach der Erlaubnis, Inhalte hinzuzufügen.", "Para escolher fotos e vídeos, o Astral usa o seletor do iOS e só recebe o que você seleciona. Para salvar um resultado em Fotos, o iOS pede permissão somente para adicionar conteúdo.", "Per scegliere foto e video, Astral usa il selettore di iOS, quindi riceve solo ciò che selezioni. Per salvare un risultato in Foto, iOS chiede solo l’autorizzazione ad aggiungere contenuti."],
        ["Where your files stay", "Où restent vos fichiers", "Wo deine Dateien bleiben", "Onde ficam seus arquivos", "Dove restano i tuoi file"],
        ["Results are stored in the app's folder on your iPhone and you can export them to Photos or Files whenever you want. In Settings you can clear the cache and the saved results. If you uninstall the app, everything it stored is deleted.", "Les résultats sont stockés dans le dossier de l’app sur votre iPhone et vous pouvez les exporter vers Photos ou Fichiers quand vous le souhaitez. Dans Réglages, vous pouvez vider le cache et les résultats enregistrés. Si vous désinstallez l’app, tout ce qu’elle a stocké est supprimé.", "Die Ergebnisse werden im App-Ordner auf deinem iPhone gespeichert, und du kannst sie jederzeit in Fotos oder Dateien exportieren. In den Einstellungen kannst du den Cache und die gesicherten Ergebnisse löschen. Wenn du die App deinstallierst, wird alles gelöscht, was sie gespeichert hat.", "Os resultados ficam na pasta do app no seu iPhone e você pode exportá-los para Fotos ou Arquivos quando quiser. Em Ajustes, você pode limpar o cache e os resultados salvos. Se você desinstalar o app, tudo o que ele armazenou será excluído.", "I risultati vengono memorizzati nella cartella dell’app sul tuo iPhone e puoi esportarli in Foto o File quando vuoi. Nelle Impostazioni puoi svuotare la cache e i risultati salvati. Se disinstalli l’app, tutto ciò che ha memorizzato viene eliminato."],
        ["AI models", "Modèles d’IA", "KI-Modelle", "Modelos de IA", "Modelli di IA"],
        ["The models come included in the app and work offline. Their authors and licenses appear in Settings › Credits & licenses.", "Les modèles sont inclus dans l’app et fonctionnent hors ligne. Leurs auteurs et licences figurent dans Réglages › Crédits et licences.", "Die Modelle sind in der App enthalten und funktionieren offline. Ihre Autoren und Lizenzen findest du unter Einstellungen › Credits und Lizenzen.", "Os modelos já vêm incluídos no app e funcionam offline. Seus autores e licenças aparecem em Ajustes › Créditos e licenças.", "I modelli sono inclusi nell’app e funzionano offline. I loro autori e le licenze sono in Impostazioni › Crediti e licenze."],
        ["Changes", "Modifications", "Änderungen", "Alterações", "Modifiche"],
        ["If this policy changes, it will be updated here inside the app.", "Si cette politique change, elle sera mise à jour ici, dans l’app.", "Wenn sich diese Richtlinie ändert, wird sie hier in der App aktualisiert.", "Se esta política mudar, ela será atualizada aqui, dentro do app.", "Se questa informativa cambia, verrà aggiornata qui, all’interno dell’app."],
        ["PRIVACY POLICY", "POLITIQUE DE CONFIDENTIALITÉ", "DATENSCHUTZERKLÄRUNG", "POLÍTICA DE PRIVACIDADE", "INFORMATIVA SULLA PRIVACY"],
        ["Contact", "Contact", "Kontakt", "Contato", "Contatti"],
        ["Freed", "Libéré", "Freigegeben", "Liberado", "Liberato"],
        ["Credits & licenses", "Crédits et licences", "Credits und Lizenzen", "Créditos e licenças", "Crediti e licenze"],
        ["Privacy policy", "Politique de confidentialité", "Datenschutzerklärung", "Política de privacidade", "Informativa sulla privacy"],
        ["Show the welcome again", "Revoir la bienvenue", "Willkommen erneut anzeigen", "Ver as boas-vindas novamente", "Rivedi il benvenuto"],
        ["THEME", "THÈME", "DESIGN", "TEMA", "TEMA"],
        ["Save to Photos when done", "Enregistrer dans Photos à la fin", "Am Ende in Fotos sichern", "Salvar em Fotos ao terminar", "Salva in Foto al termine"],
        ["Email copied to the clipboard", "E-mail copié dans le presse-papiers", "E-Mail-Adresse in die Zwischenablage kopiert", "E-mail copiado para a área de transferência", "E-mail copiata negli appunti"],
        ["Support", "Assistance", "Support", "Suporte", "Assistenza"],
        ["TRIM", "RECADRAGE", "KÜRZEN", "CORTE", "TAGLIO"],
        ["Duration", "Durée", "Dauer", "Duração", "Durata"],
        ["About", "À propos", "Über", "Sobre", "Informazioni"],
        ["Presets", "Préréglages", "Vorgaben", "Presets", "Preset"],
    ]
}
