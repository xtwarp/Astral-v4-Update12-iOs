import Foundation
import SwiftUI
import PhotosUI
import CoreImage
import CoreVideo
import AVFoundation
import UIKit

@MainActor
final class InterpolationViewModel: ObservableObject {
    @Published var inputURL: URL?
    @Published var outputURL: URL?
    @Published var progress: Double = 0
    @Published var status = tr("Selecciona un video", "Select a video")
    @Published var isProcessing = false
    @Published var liveFrame: CGImage?
    @Published var liveFrameNumber = 0

    @Published var factor = 2
    @Published var precision: RIFEInterpolator.Precision = .fp16
    @Published var alsoUpscale = false
    @Published var exportQuality: ExportQuality = .original
    @Published var slowMotion = false
    @Published var resultTrimStart: Double = 0
    /// Factor de cámara lenta del resultado actual (1 = sin cámara lenta). Lo usa el comparador antes/después.
    @Published var resultSlowFactor: Int = 1
    @Published var selectedUpscaleModel: RealESRGAN.Model = .animevideo

    @Published var videoDuration: Double = 0
    @Published var trimStart: Double = 0
    @Published var trimEnd: Double = 0

    /// nil = vídeo completo.
    var trimRange: CMTimeRange? {
        guard videoDuration > 0, trimEnd > trimStart,
              trimStart > 0.05 || trimEnd < videoDuration - 0.05 else { return nil }
        return CMTimeRange(
            start: CMTime(seconds: trimStart, preferredTimescale: 600),
            duration: CMTime(seconds: trimEnd - trimStart, preferredTimescale: 600)
        )
    }

    private func loadDuration(of url: URL) async {
        let seconds = (try? await AVURLAsset(url: url).load(.duration)).map { CMTimeGetSeconds($0) } ?? 0
        videoDuration = seconds.isFinite ? max(seconds, 0) : 0
        trimStart = 0
        trimEnd = videoDuration
    }

    private var processor: InterpolationProcessor?
    private var pipeline: CombinedPipeline?
    private var securityScopedInput = false
    private let previewContext = CIContext(options: [.cacheIntermediates: false])

    @Published var batchTotal = 0
    @Published var batchIndex = 0
    @Published var batchResults: [URL] = []
    @Published var batchFailures = 0
    @Published var isBatchRunning = false
    private var batchCancelled = false

    /// Procesa varios vídeos uno tras otro con los ajustes actuales.
    func startBatch(_ items: [PhotosPickerItem]) {
        guard !items.isEmpty, !isProcessing, !isBatchRunning else { return }
        isBatchRunning = true
        batchCancelled = false
        batchTotal = items.count
        batchIndex = 0
        batchResults = []
        batchFailures = 0
        UIApplication.shared.isIdleTimerDisabled = true
        Task {
            for (offset, item) in items.enumerated() {
                if batchCancelled { break }
                batchIndex = offset + 1
                let previous = inputURL
                await importVideo(from: item)
                if batchCancelled { break }
                guard let current = inputURL, current != previous else { batchFailures += 1; continue }
                start()
                while isProcessing { try? await Task.sleep(nanoseconds: 300_000_000) }
                if let output = outputURL {
                    batchResults.append(output)
                } else if !batchCancelled {
                    batchFailures += 1
                }
            }
            isBatchRunning = false
            UIApplication.shared.isIdleTimerDisabled = false
        }
    }

    func importVideo(from item: PhotosPickerItem) async {
        guard !isProcessing else { return }
        status = tr("Cargando video…", "Loading video…")
        do {
            let imported = try await item.loadTransferable(type: ImportedMovie.self)
            guard let imported else { status = tr("No se pudo cargar el video", "Could not load the video"); return }
            if securityScopedInput, let oldURL = inputURL { oldURL.stopAccessingSecurityScopedResource() }
            securityScopedInput = false
            let previousInput = inputURL
            inputURL = imported.url
            if previousInput != imported.url { CacheManager.removeIfTemporary(previousInput) }
            outputURL = nil
            liveFrame = nil
            liveFrameNumber = 0
            progress = 0
            await loadDuration(of: imported.url)
            status = tr("Video seleccionado", "Video selected")
        } catch {
            status = tr("No se pudo cargar el video: \(error.localizedDescription)", "Could not load the video: \(error.localizedDescription)")
        }
    }

    func start() {
        guard let sourceURL = inputURL, !isProcessing else { return }
        resultTrimStart = trimRange.map { CMTimeGetSeconds($0.start) } ?? 0
        resultSlowFactor = slowMotion ? factor : 1
        isProcessing = true
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        progress = 0
        let chosenFactor = factor
        let chosenPrecision = precision

        let progressHandler: (Double, String) -> Void = { [weak self] value, text in
            DispatchQueue.main.async { self?.progress = value; self?.status = text }
        }
        let completionHandler: (Result<URL, Error>) -> Void = { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                self.isProcessing = false
                self.processor = nil
                self.pipeline = nil
                switch result {
                case .success(let url):
                    self.outputURL = url
                    self.status = tr("Listo — usa Guardar en Archivos para exportar", "Done — use Save to Files to export")
                case .failure(let error):
                    self.status = error.localizedDescription
                }
            }
        }
        let previewHandler: (CVPixelBuffer, Int) -> Void = { [weak self] pixelBuffer, frameNumber in
            guard let self else { return }
            autoreleasepool {
                let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
                let maxDimension: CGFloat = 900
                let longest = max(ciImage.extent.width, ciImage.extent.height)
                let scale = min(1, maxDimension / max(longest, 1))
                let previewImage = scale < 1 ? ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale)) : ciImage
                if let cg = self.previewContext.createCGImage(previewImage, from: previewImage.extent) {
                    DispatchQueue.main.async {
                        self.liveFrame = cg
                        self.liveFrameNumber = frameNumber
                    }
                }
            }
        }

        if alsoUpscale {
            let model = selectedUpscaleModel
            status = tr("Paso 1/2 · Cargando \(model.displayName)…", "Step 1/2 · Loading \(model.displayName)…")
            let pipeline = CombinedPipeline()
            self.pipeline = pipeline
            pipeline.run(
                inputURL: sourceURL,
                timeRange: trimRange,
                model: model,
                factor: chosenFactor,
                precision: chosenPrecision,
                exportShortSide: exportQuality.shortSide,
                slowMotion: slowMotion,
                progress: progressHandler,
                framePreview: previewHandler,
                completion: completionHandler
            )
            return
        }

        status = tr("Cargando interpolación \(factor)×…", "Loading \(factor)× interpolation…")
        let processor = InterpolationProcessor()
        self.processor = processor
        processor.process(
            inputURL: sourceURL,
            timeRange: trimRange,
            factor: chosenFactor,
            precision: chosenPrecision,
            upscaleModel: nil,
            exportShortSide: exportQuality.shortSide,
            slowMotion: slowMotion,
            progress: progressHandler,
            framePreview: previewHandler,
            completion: completionHandler
        )
    }

    func cancel() {
        if isBatchRunning { batchCancelled = true }
        processor?.cancel()
        pipeline?.cancel()
        status = tr("Cancelando…", "Cancelling…")
    }

    func relocalizeIdleStatus() {
        guard !isProcessing else { return }
        if status == "Selecciona un video" || status == "Select a video" { status = tr("Selecciona un video", "Select a video") }
        if status == "Video seleccionado" || status == "Video selected" { status = tr("Video seleccionado", "Video selected") }
    }

    func makePreset(name: String) -> Preset {
        Preset(name: name, kind: .interpolate, modelRaw: selectedUpscaleModel.rawValue, includesSecondStep: alsoUpscale,
               factor: factor, precisionRaw: precision.rawValue, slowMotion: slowMotion)
    }

    func apply(_ preset: Preset) {
        guard !isProcessing else { return }
        if let model = RealESRGAN.Model(rawValue: preset.modelRaw), RealESRGAN.Model.videoModels.contains(model) { selectedUpscaleModel = model }
        alsoUpscale = preset.includesSecondStep
        slowMotion = preset.slowMotion ?? false
        factor = preset.factor
        precision = RIFEInterpolator.Precision(rawValue: preset.precisionRaw) ?? .fp16
    }

    func discardOutputIfMissing() {
        guard let url = outputURL, !FileManager.default.fileExists(atPath: url.path) else { return }
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        progress = 0
        status = tr("Selecciona un video", "Select a video")
    }
}
