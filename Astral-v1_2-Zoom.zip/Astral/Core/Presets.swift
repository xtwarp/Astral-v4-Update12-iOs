import Foundation

/// Configuración guardada con nombre (modelo, interpolación y precisión).
struct Preset: Codable, Identifiable, Equatable {
    enum Kind: String, Codable, Identifiable {
        case video, interpolate, image
        var id: String { rawValue }
    }

    var id = UUID()
    var name: String
    var kind: Kind
    var modelRaw: String
    /// Pestaña Video: "interpolar también". Pestaña Interpolar: "escalar también".
    var includesSecondStep: Bool
    var factor: Int
    var precisionRaw: String
    /// Solo pestaña Interpolar (opcional para no romper presets ya guardados).
    var slowMotion: Bool? = nil

    var summary: String {
        let model = RealESRGAN.Model(rawValue: modelRaw)?.summaryName ?? modelRaw
        let precision = RIFEInterpolator.Precision(rawValue: precisionRaw)?.displayName ?? precisionRaw
        switch kind {
        case .image:
            return model
        case .video:
            return includesSecondStep ? "\(model) + \(factor)× · \(precision)" : model
        case .interpolate:
            let base = includesSecondStep ? "\(factor)× · \(precision) + \(model)" : "\(factor)× · \(precision)"
            return slowMotion == true ? base + " · " + tr("cámara lenta", "slow motion") : base
        }
    }
}

@MainActor
final class PresetStore: ObservableObject {
    static let shared = PresetStore()
    private let key = "astral.presets"

    @Published private(set) var presets: [Preset] = []

    private init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode([Preset].self, from: data) {
            presets = saved
        }
    }

    func presets(for kind: Preset.Kind) -> [Preset] {
        presets.filter { $0.kind == kind }
    }

    /// Si ya existe uno con el mismo nombre en la misma pestaña, lo reemplaza.
    func save(_ preset: Preset) {
        presets.removeAll { $0.kind == preset.kind && $0.name.caseInsensitiveCompare(preset.name) == .orderedSame }
        presets.append(preset)
        persist()
    }

    func delete(_ id: UUID) {
        presets.removeAll { $0.id == id }
        persist()
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(presets) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
