import SwiftUI

struct SettingsView: View {
    let keepURLs: [URL]
    let isBusy: Bool

    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var languageStore = AppLanguageStore.shared
    @State private var cacheBytes: Int64 = 0
    @State private var message = ""
    @State private var showCredits = false

    var body: some View {
        ZStack {
            NeonBackground().ignoresSafeArea()
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text(L.settingsTitle.text)
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(.white.opacity(0.6))
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white.opacity(0.7))
                            .frame(width: 34, height: 34)
                            .background(Color.white.opacity(0.055), in: Circle())
                    }
                }

                languageCard

                storageCard(
                    title: L.cacheTitle.text,
                    detail: formatBytes(cacheBytes),
                    buttonTitle: L.cacheButton.text,
                    icon: "trash",
                    enabled: !isBusy && cacheBytes > 0
                ) {
                    let freed = CacheManager.remove(CacheManager.temporaryFiles(), keeping: keepURLs)
                    message = tr("Liberado", "Freed") + ": \(formatBytes(freed))"
                    refresh()
                }

                if !message.isEmpty {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(LocalStyle.mint)
                }

                Text(L.cacheFootnote.text)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.45))

                Button { showCredits = true } label: {
                    HStack {
                        Image(systemName: "doc.text")
                        Text(tr("Créditos y licencias", "Credits & licenses")).font(.subheadline.weight(.semibold))
                        Spacer()
                        Image(systemName: "chevron.right").font(.caption.weight(.bold)).opacity(0.4)
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 14)
                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
                    .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 14))
                }

                Spacer(minLength: 0)
            }
            .padding(16)
        }
        .preferredColorScheme(.dark)
        .presentationDetents([.medium, .large])
        .sheet(isPresented: $showCredits) { CreditsView() }
        .onAppear(perform: refresh)
    }

    private func formatBytes(_ bytes: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        formatter.allowsNonnumericFormatting = false   // "0 KB" en lugar de "Zero KB"
        return formatter.string(fromByteCount: bytes)
    }

    private var languageCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(L.settingsLanguage.text)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(.white.opacity(0.45))
            Picker("", selection: $languageStore.language) {
                ForEach(AppLanguage.allCases) { lang in
                    Text(lang.displayName).tag(lang)
                }
            }
            .pickerStyle(.segmented)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 14))
    }

    private func refresh() {
        cacheBytes = CacheManager.size(of: CacheManager.temporaryFiles().filter { url in
            !keepURLs.contains { $0.resolvingSymlinksInPath().path == url.resolvingSymlinksInPath().path }
        })
    }

    private func storageCard(title: String, detail: String, buttonTitle: String, icon: String, enabled: Bool, destructive: Bool = false, action: @escaping () -> Void) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(.white.opacity(0.45))
            Text(detail)
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Button(action: action) {
                HStack(spacing: 8) {
                    Image(systemName: icon)
                    Text(buttonTitle).font(.subheadline.weight(.semibold))
                }
                .foregroundStyle(destructive ? Color.white : Color.black)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(destructive ? AnyShapeStyle(Color.red.opacity(0.75)) : AnyShapeStyle(LocalStyle.gradient), in: RoundedRectangle(cornerRadius: 13))
            }
            .disabled(!enabled)
            .opacity(enabled ? 1 : 0.4)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 14))
    }
}
