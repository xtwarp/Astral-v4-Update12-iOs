# Licencias

- La implementación Core ML usada como referencia: MIT — hanxiao/real-esrgan-coreml.
- Pesos/modelos Real-ESRGAN (AnimeVideo v3, General x4v3, x4plus, x4plus anime 6B): BSD-3-Clause — xinntao/Real-ESRGAN.

Esta aplicación no incluye contenido audiovisual de terceros. Los vídeos de prueba deben ser aportados por el usuario y tener los derechos correspondientes.

Antes de publicar comercialmente, conservar los textos de licencia y revisar los términos vigentes de los repositorios/modelos.
