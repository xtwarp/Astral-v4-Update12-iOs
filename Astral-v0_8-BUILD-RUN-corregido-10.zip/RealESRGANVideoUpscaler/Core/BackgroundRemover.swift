import Foundation
import CoreML
import CoreImage
import CoreGraphics
import ImageIO
import Vision
import UniformTypeIdentifiers

/// Quita el fondo con RMBG-1.4 (BRIA AI) convertido a Core ML.
/// Licencia del modelo: solo uso no comercial (bria-rmbg-1.4).
final class BackgroundRemover {
    enum Style: String, CaseIterable, Identifiable {
        case transparent, white, black
        var id: String { rawValue }
        var displayName: String {
            switch self {
            case .transparent: return tr("Transparente", "Transparent")
            case .white: return tr("Blanco", "White")
            case .black: return tr("Negro", "Black")
            }
        }
    }

    static let resourceName = "RMBG_1_4"
    private static let side = 1024
    /// Lado máximo de la imagen de entrada (limita la memoria).
    static let maxInputSide = 4096

    private let model: MLModel
    private let inputName: String
    private let outputName: String
    private let imageConstraint: MLImageConstraint
    private let ciContext = CIContext(options: [.cacheIntermediates: false])

    init() throws {
        guard let url = Bundle.main.url(forResource: Self.resourceName, withExtension: "mlmodelc") else {
            throw UpscaleError.modelMissing("RMBG-1.4")
        }
        let configuration = MLModelConfiguration()
        configuration.computeUnits = .cpuOnly   // configuración con la que se verificó la conversión
        do {
            model = try MLModel(contentsOf: url, configuration: configuration)
        } catch {
            throw UpscaleError.coreML(tr("No se pudo cargar RMBG-1.4: \(error.localizedDescription)", "Could not load RMBG-1.4: \(error.localizedDescription)"))
        }
        let description = model.modelDescription
        guard let input = description.inputDescriptionsByName.first(where: { $0.value.type == .image }),
              let constraint = input.value.imageConstraint,
              let output = description.outputDescriptionsByName.keys.first else {
            throw UpscaleError.coreML(tr("El modelo RMBG-1.4 tiene un formato inesperado.", "The RMBG-1.4 model has an unexpected format."))
        }
        inputName = input.key
        imageConstraint = constraint
        outputName = description.outputDescriptionsByName["alpha_mask"] != nil ? "alpha_mask" : output
    }

    /// Carga una imagen aplicando la orientación EXIF y limitando su tamaño.
    static func loadImage(from data: Data) -> CGImage? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil) else { return nil }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxInputSide
        ]
        return CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary)
    }

    func cutout(_ image: CGImage, style: Style, isCancelled: () -> Bool = { false }) throws -> CGImage {
        try autoreleasepool {
            if isCancelled() { throw UpscaleError.cancelled }
            let feature = try MLFeatureValue(
                cgImage: image,
                constraint: imageConstraint,
                options: [.cropAndScale: VNImageCropAndScaleOption.scaleFill.rawValue]
            )
            let provider = try MLDictionaryFeatureProvider(dictionary: [inputName: feature])
            let result: MLFeatureProvider
            do { result = try model.prediction(from: provider) }
            catch { throw UpscaleError.coreML(error.localizedDescription) }
            if isCancelled() { throw UpscaleError.cancelled }

            guard let array = result.featureValue(for: outputName)?.multiArrayValue else {
                throw UpscaleError.coreML(tr("RMBG-1.4 no devolvió una máscara.", "RMBG-1.4 returned no mask."))
            }
            let mask = try Self.maskImage(from: array)
            return try compose(image: image, mask: mask, style: style)
        }
    }

    /// Convierte la salida [1,1,H,W] (0…1) en una imagen de grises de 8 bits.
    private static func maskImage(from array: MLMultiArray) throws -> CGImage {
        let rank = array.shape.count
        guard rank >= 2 else { throw UpscaleError.coreML("Máscara con forma inesperada.") }
        let height = array.shape[rank - 2].intValue
        let width = array.shape[rank - 1].intValue
        let rowStride = array.strides[rank - 2].intValue
        let colStride = array.strides[rank - 1].intValue
        var pixels = [UInt8](repeating: 0, count: width * height)

        func fill<T: BinaryFloatingPoint>(_ buffer: UnsafeBufferPointer<T>) {
            for y in 0..<height {
                for x in 0..<width {
                    let value = Float(buffer[y * rowStride + x * colStride])
                    pixels[y * width + x] = UInt8(max(0, min(255, (value * 255).rounded())))
                }
            }
        }
        switch array.dataType {
        case .float16:
            array.withUnsafeBufferPointer(ofType: Float16.self) { fill($0) }
        case .float32:
            array.withUnsafeBufferPointer(ofType: Float.self) { fill($0) }
        case .double:
            array.withUnsafeBufferPointer(ofType: Double.self) { fill($0) }
        default:
            throw UpscaleError.coreML("Tipo de máscara no compatible.")
        }

        guard let provider = CGDataProvider(data: Data(pixels) as CFData),
              let mask = CGImage(
                width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 8, bytesPerRow: width,
                space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.none.rawValue),
                provider: provider, decode: nil, shouldInterpolate: true, intent: .defaultIntent
              ) else {
            throw UpscaleError.coreML("No se pudo crear la máscara.")
        }
        return mask
    }

    private func compose(image: CGImage, mask: CGImage, style: Style) throws -> CGImage {
        let extent = CGRect(x: 0, y: 0, width: image.width, height: image.height)
        let source = CIImage(cgImage: image)
        let scaledMask = CIImage(cgImage: mask)
            .transformed(by: CGAffineTransform(scaleX: extent.width / CGFloat(mask.width), y: extent.height / CGFloat(mask.height)))
            .cropped(to: extent)

        let background: CIImage
        switch style {
        case .transparent: background = CIImage(color: .clear).cropped(to: extent)
        case .white: background = CIImage(color: .white).cropped(to: extent)
        case .black: background = CIImage(color: .black).cropped(to: extent)
        }

        guard let filter = CIFilter(name: "CIBlendWithMask") else { throw UpscaleError.exportFailed }
        filter.setValue(source, forKey: kCIInputImageKey)
        filter.setValue(background, forKey: kCIInputBackgroundImageKey)
        filter.setValue(scaledMask, forKey: kCIInputMaskImageKey)
        guard let output = filter.outputImage,
              let cgImage = ciContext.createCGImage(output, from: extent, format: .RGBA8, colorSpace: CGColorSpace(name: CGColorSpace.sRGB)) else {
            throw UpscaleError.exportFailed
        }
        return cgImage
    }
}
