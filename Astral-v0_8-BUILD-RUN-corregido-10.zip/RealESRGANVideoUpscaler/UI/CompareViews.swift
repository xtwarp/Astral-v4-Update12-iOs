import SwiftUI
import AVFoundation

// MARK: - Divisor compartido (línea + asa) que se arrastra en ambos sentidos

struct CompareDivider: View {
    @Binding var position: CGFloat
    let size: CGSize

    var body: some View {
        ZStack {
            Rectangle().fill(LocalStyle.gradient).frame(width: 2.5, height: size.height)
                .shadow(color: LocalStyle.mint.opacity(0.6), radius: 5)
            Circle().fill(LocalStyle.gradient).frame(width: 34, height: 34)
                .shadow(color: LocalStyle.mint.opacity(0.5), radius: 8)
                .overlay(
                    Image(systemName: "chevron.left.chevron.right")
                        .font(.system(size: 11, weight: .bold)).foregroundStyle(.black)
                )
        }
        .frame(width: 52, height: size.height)
        .contentShape(Rectangle())
        .position(x: size.width * position, y: size.height / 2)
        // El gesto usa el espacio de coordenadas del contenedor: así la posición es absoluta
        // y el divisor responde en los dos sentidos.
        .highPriorityGesture(
            DragGesture(minimumDistance: 0, coordinateSpace: .named("compare"))
                .onChanged { value in
                    position = min(max(value.location.x / max(size.width, 1), 0.02), 0.98)
                }
        )
    }
}

private struct CompareLabel: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(0.8)
            .foregroundStyle(.white)
            .padding(.horizontal, 9).padding(.vertical, 5)
            .background(.black.opacity(0.55), in: Capsule())
    }
}

// MARK: - Reproductores

struct PlayerLayerView: UIViewRepresentable {
    let player: AVPlayer
    func makeUIView(context: Context) -> PlayerContainer {
        let view = PlayerContainer()
        view.playerLayer.player = player
        view.playerLayer.videoGravity = .resizeAspect
        return view
    }
    func updateUIView(_ uiView: PlayerContainer, context: Context) { uiView.playerLayer.player = player }
}

final class PlayerContainer: UIView {
    override static var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}

/// Controla dos reproductores sincronizados: resultado (maestro) y original (sigue al maestro).
final class VideoCompareController: ObservableObject {
    let before: AVPlayer
    let after: AVPlayer
    private let beforeOffset: CMTime
    @Published var isPlaying = false
    @Published var progress: Double = 0
    var scrubbing = false
    private var duration: Double = 0
    private var timeObserver: Any?
    private var endObserver: NSObjectProtocol?

    init(beforeURL: URL, afterURL: URL, beforeStart: Double) {
        before = AVPlayer(url: beforeURL)
        after = AVPlayer(url: afterURL)
        beforeOffset = CMTime(seconds: beforeStart, preferredTimescale: 600)
        before.isMuted = true
        before.seek(to: beforeOffset, toleranceBefore: .zero, toleranceAfter: .zero)

        timeObserver = after.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 0.05, preferredTimescale: 600), queue: .main
        ) { [weak self] time in
            guard let self else { return }
            let total = CMTimeGetSeconds(self.after.currentItem?.duration ?? .zero)
            if total.isFinite, total > 0 {
                self.duration = total
                if !self.scrubbing { self.progress = min(max(CMTimeGetSeconds(time) / total, 0), 1) }
            }
            if self.isPlaying {
                let target = CMTimeAdd(self.beforeOffset, time)
                let drift = CMTimeGetSeconds(CMTimeSubtract(self.before.currentTime(), target))
                if abs(drift) > 0.12 {
                    self.before.seek(to: target, toleranceBefore: .zero, toleranceAfter: .zero)
                }
            }
        }
        endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime, object: after.currentItem, queue: .main
        ) { [weak self] _ in
            self?.pauseBoth()
            self?.progress = 1
        }
    }

    deinit {
        if let timeObserver { after.removeTimeObserver(timeObserver) }
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        before.pause(); after.pause()
    }

    func pauseBoth() {
        before.pause(); after.pause()
        isPlaying = false
    }

    func toggle() {
        if isPlaying { pauseBoth(); return }
        if progress >= 0.99 { seek(to: 0, precise: true) }
        let time = after.currentTime()
        before.seek(to: CMTimeAdd(beforeOffset, time), toleranceBefore: .zero, toleranceAfter: .zero)
        before.play(); after.play()
        isPlaying = true
    }

    func restart() {
        pauseBoth()
        seek(to: 0, precise: true)
    }

    func seek(to fraction: Double, precise: Bool = false) {
        guard duration > 0 || fraction == 0 else { return }
        let time = CMTime(seconds: fraction * duration, preferredTimescale: 600)
        let tolerance = precise ? CMTime.zero : CMTime(seconds: 0.1, preferredTimescale: 600)
        after.seek(to: time, toleranceBefore: tolerance, toleranceAfter: tolerance)
        before.seek(to: CMTimeAdd(beforeOffset, time), toleranceBefore: tolerance, toleranceAfter: tolerance)
        progress = fraction
    }
}

/// Comparación antes/después con vídeo: dentro de la misma vista previa principal.
struct VideoCompareView: View {
    @StateObject private var controller: VideoCompareController
    @State private var position: CGFloat = 0.5

    init(beforeURL: URL, afterURL: URL, beforeStart: Double) {
        _controller = StateObject(wrappedValue: VideoCompareController(beforeURL: beforeURL, afterURL: afterURL, beforeStart: beforeStart))
    }

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black
                PlayerLayerView(player: controller.after).allowsHitTesting(false)
                PlayerLayerView(player: controller.before).allowsHitTesting(false)
                    .mask(alignment: .leading) { Rectangle().frame(width: proxy.size.width * position) }

                CompareDivider(position: $position, size: proxy.size)

                VStack {
                    HStack {
                        CompareLabel(text: L.beforeLabel.text)
                        Spacer()
                        CompareLabel(text: L.afterLabel.text)
                    }
                    .padding(10)
                    .allowsHitTesting(false)
                    Spacer()
                    controls
                }
            }
            .coordinateSpace(name: "compare")
        }
        .onDisappear { controller.pauseBoth() }
    }

    private var controls: some View {
        HStack(spacing: 14) {
            Button { controller.restart() } label: { Image(systemName: "backward.end.fill") }
            Button { controller.toggle() } label: { Image(systemName: controller.isPlaying ? "pause.fill" : "play.fill") }
            Slider(
                value: Binding(get: { controller.progress }, set: { controller.seek(to: $0) }),
                in: 0...1,
                onEditingChanged: { editing in
                    controller.scrubbing = editing
                }
            )
            .tint(LocalStyle.mint)
        }
        .font(.system(size: 16, weight: .bold))
        .foregroundStyle(.white)
        .padding(.horizontal, 16).padding(.vertical, 8)
        .background(.black.opacity(0.6), in: Capsule())
        .padding(.horizontal, 10).padding(.bottom, 10)
    }
}

// MARK: - Comparación de imágenes

struct ImageComparisonView: View {
    let before: CGImage
    let after: CGImage
    @State private var position: CGFloat = 0.5
    @State private var zoom: CGFloat = 1
    @State private var lastZoom: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black
                Image(decorative: after, scale: 1, orientation: .up)
                    .resizable().scaledToFit().scaleEffect(zoom).offset(offset)
                Image(decorative: before, scale: 1, orientation: .up)
                    .resizable().scaledToFit().scaleEffect(zoom).offset(offset)
                    .mask(alignment: .leading) { Rectangle().frame(width: proxy.size.width * position) }

                CompareDivider(position: $position, size: proxy.size)

                VStack {
                    HStack {
                        CompareLabel(text: L.beforeLabel.text)
                        Spacer()
                        CompareLabel(text: L.afterLabel.text)
                    }
                    .padding(10)
                    Spacer()
                }
                .allowsHitTesting(false)
            }
            .coordinateSpace(name: "compare")
            .simultaneousGesture(
                MagnificationGesture()
                    .onChanged { value in zoom = min(max(lastZoom * value, 1), 4) }
                    .onEnded { _ in
                        lastZoom = zoom
                        if zoom <= 1 { offset = .zero; lastOffset = .zero }
                    }
            )
        }
    }
}
