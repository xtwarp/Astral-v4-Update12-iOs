import SwiftUI

struct PresetsSheet: View {
    let kind: Preset.Kind
    let current: (String) -> Preset
    let apply: (Preset) -> Void

    @ObservedObject private var store = PresetStore.shared
    @ObservedObject private var language = AppLanguageStore.shared
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""

    private var trimmedName: String { name.trimmingCharacters(in: .whitespacesAndNewlines) }

    var body: some View {
        NavigationStack {
            List {
                Section(tr("Guardar configuración actual", "Save current settings")) {
                    TextField(tr("Nombre del preset", "Preset name"), text: $name)
                    Button(tr("Guardar", "Save")) {
                        store.save(current(trimmedName))
                        name = ""
                    }
                    .disabled(trimmedName.isEmpty)
                }

                Section(tr("Mis presets", "My presets")) {
                    let items = store.presets(for: kind)
                    if items.isEmpty {
                        Text(tr("Aún no tienes presets en esta pestaña.", "You have no presets in this tab yet."))
                            .foregroundStyle(.secondary)
                    }
                    ForEach(items) { preset in
                        Button {
                            apply(preset)
                            dismiss()
                        } label: {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(preset.name).font(.headline)
                                Text(preset.summary).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    .onDelete { offsets in
                        let items = store.presets(for: kind)
                        for index in offsets { store.delete(items[index].id) }
                    }
                }

                if !store.presets(for: kind).isEmpty {
                    Section {
                        Text(tr("Toca un preset para aplicarlo. Desliza a la izquierda para borrarlo.",
                                "Tap a preset to apply it. Swipe left to delete it."))
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Presets")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button(tr("Cerrar", "Close")) { dismiss() } }
            }
        }
        .presentationDetents([.medium, .large])
        .preferredColorScheme(.dark)
    }
}

/// Resumen del lote: progreso mientras corre y, al terminar, botón para guardar/compartir todo.
struct BatchSummary: View {
    let isRunning: Bool
    let index: Int
    let total: Int
    let failures: Int
    let results: [URL]

    var body: some View {
        if total > 0 {
            VStack(alignment: .leading, spacing: 8) {
                if isRunning {
                    Text(tr("Lote", "Batch") + " \(index)/\(total)")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(LocalStyle.mint)
                    Text(tr("Mantén la app abierta; la pantalla no se apagará durante el lote.",
                            "Keep the app open; the screen won't sleep during the batch."))
                        .font(.caption).foregroundStyle(.white.opacity(0.5))
                } else {
                    Text(tr("Lote terminado", "Batch finished") + ": \(results.count)/\(total)"
                         + (failures > 0 ? " · \(failures) " + tr("con error", "failed") : ""))
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(LocalStyle.mint)
                    if !results.isEmpty {
                        ShareLink(items: results) {
                            HStack(spacing: 8) {
                                Image(systemName: "square.and.arrow.up")
                                Text(tr("Guardar / compartir todos", "Save / share all"))
                            }
                            .font(.system(size: 14, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, minHeight: 44)
                            .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                        }
                        Text(tr("Guárdalos ahora: se borran al limpiar la caché.",
                                "Save them now: they're deleted when you clear the cache."))
                            .font(.caption).foregroundStyle(.white.opacity(0.5))
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12)
            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
        }
    }
}
