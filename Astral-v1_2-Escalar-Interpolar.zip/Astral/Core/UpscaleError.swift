import Foundation

enum UpscaleError: LocalizedError {
    case invalidVideo
    case modelMissing(String)
    case unsupportedPixelFormat
    case cancelled
    case readerFailed
    case writerFailed
    case coreML(String)
    case exportFailed
    case frameTooLarge(width: Int, height: Int)
    case interpolationUnsupportedSize(width: Int, height: Int)
    case writerStalled
    case combinedTooLarge(width: Int, height: Int)

    var errorDescription: String? {
        switch self {
        case .invalidVideo: return tr("No se pudo abrir el vídeo.", "Could not open the video.")
        case .modelMissing(let name): return tr("Falta \(name) en esta compilación. Vuelve a correr el build para incluirlo.", "\(name) is missing from this build. Run the build again to include it.")
        case .unsupportedPixelFormat: return tr("El vídeo usa un formato de píxel no compatible.", "The video uses an unsupported pixel format.")
        case .cancelled: return tr("Procesamiento cancelado.", "Processing cancelled.")
        case .readerFailed: return tr("No se pudo leer el vídeo.", "Could not read the video.")
        case .writerFailed: return tr("No se pudo escribir el vídeo.", "Could not write the video.")
        case .coreML(let message): return "Core ML: \(message)"
        case .exportFailed: return tr("No se pudo finalizar el archivo de vídeo.", "Could not finalize the video file.")
        case .frameTooLarge(let width, let height):
            return tr("El frame \(width)×\(height) es demasiado grande para procesarlo a 4× con seguridad en este iPhone.", "The \(width)×\(height) frame is too large to safely process at 4× on this iPhone.")
        case .interpolationUnsupportedSize(let width, let height):
            return tr("El vídeo \(width)×\(height) supera el tamaño máximo para interpolar (\(RIFEInterpolator.maxSizeDescription)).", "The \(width)×\(height) video exceeds the maximum size for interpolation (\(RIFEInterpolator.maxSizeDescription)).")
        case .combinedTooLarge(let width, let height):
            return tr("Al escalar primero, el video quedaría en \(width)×\(height) y supera el máximo para interpolar (\(RIFEInterpolator.maxSizeDescription)). Usa un video más pequeño, un modelo 2× o interpola sin escalar.", "Upscaling first would make the video \(width)×\(height), above the interpolation maximum (\(RIFEInterpolator.maxSizeDescription)). Use a smaller video, a 2× model, or interpolate without upscaling.")
        case .writerStalled:
            return tr("El proceso se detuvo sin avanzar (probable límite de memoria o calor del iPhone). Prueba con un vídeo más corto o ciérralo y vuelve a intentarlo.", "Processing stalled (likely the iPhone's memory limit or heat). Try a shorter video, or close it and try again.")
        }
    }
}
