# RealESRGAN Video Upscaler — desarrollo v0.2

App iOS nativa para probar Real-ESRGAN AnimeVideo-v3 sobre vídeo local.

## Flujo actual

1. Seleccionar vídeo.
2. Cargar Real-ESRGAN AnimeVideo-v3.
3. Decodificar frames como BGRA.
4. Convertir a RGB float.
5. Dividir cada frame en tiles de 512×512 con 32 px de overlap.
6. Aplicar pre-pad/square-pad de acuerdo con el pipeline CoreML upstream (entrada 522×522).
7. Inferencia Core ML en CPU+GPU.
8. Quitar padding, mezclar tiles y reconstruir el frame 4×.
9. Codificar HEVC.
10. Mantener timestamps/orientación y copiar el audio comprimido cuando AVAssetWriter lo admita.
11. Exportar/guardar en Fotos.

## Importante

Esta versión está pensada para desarrollo y pruebas. Todavía no debe considerarse una versión comercial: hay que probarla en un iPhone físico y medir memoria, temperatura, rendimiento, vídeos largos, distintos contenedores y sincronización de audio.

## Build en la nube

El repositorio incluye un workflow de GitHub Actions que instala XcodeGen, descarga el modelo Core ML y genera/compila el proyecto para el simulador. Esa compilación no firma una app para instalar en un iPhone físico.

## Modelo

El upstream documenta cinco variantes y describe AnimeVideo como una variante 4× para vídeo anime. Su pipeline usa tiles de 512 px, overlap de 32 px y una entrada 522×522 con pre-pad de 10 px. La implementación Swift de este proyecto sigue esa preparación en lugar de inventar otro padding.
