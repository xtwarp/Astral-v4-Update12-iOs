COPIA DEL BUILD

Este directorio contiene una copia del build.yml que se usa para generar la IPA.
El workflow principal sigue estando en .github/workflows/build.yml.
