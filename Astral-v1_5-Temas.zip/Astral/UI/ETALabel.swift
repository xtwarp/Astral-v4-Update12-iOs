import SwiftUI

/// Porcentaje + tiempo restante estimado ("42% · ≈ 2 min 10 s"). Se reinicia solo cuando el progreso vuelve a empezar
/// (otro video del lote o un nuevo proceso). La estimación se suaviza para que no salte de un valor a otro.
struct ETALabel: View {
    let progress: Double

    @State private var startDate = Date()
    @State private var lastProgress = 0.0
    @State private var smoothedRemaining: Double?

    var body: some View {
        Text(text)
            .monospacedDigit()
            .onChange(of: progress) { _, value in update(value) }
    }

    private var text: String {
        let percent = "\(Int(progress * 100))%"
        guard let remaining = smoothedRemaining else {
            return percent + " · " + tr("calculando…", "estimating…")
        }
        return percent + " · ≈ " + Self.format(remaining)
    }

    private func update(_ value: Double) {
        if value < lastProgress - 0.01 {
            startDate = Date()
            smoothedRemaining = nil
        }
        lastProgress = value
        let elapsed = Date().timeIntervalSince(startDate)
        guard value >= 0.02, value < 1, elapsed >= 4 else { return }
        let raw = elapsed * (1 - value) / value
        smoothedRemaining = smoothedRemaining.map { $0 * 0.8 + raw * 0.2 } ?? raw
    }

    static func format(_ seconds: Double) -> String {
        let total = max(Int(seconds.rounded()), 1)
        if total < 60 { return "\(total) s" }
        let minutes = total / 60
        let secs = total % 60
        if minutes < 60 { return secs == 0 ? "\(minutes) min" : "\(minutes) min \(secs) s" }
        let hours = minutes / 60
        return "\(hours) h \(minutes % 60) min"
    }
}
