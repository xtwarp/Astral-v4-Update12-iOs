import Foundation
import AVFoundation

/// Hace que la vista previa del vídeo respete el recorte, como el editor de Fotos del iPhone:
/// al mover una manija se muestra el frame de ese punto, y al reproducir solo se ve (y se oye)
/// la parte seleccionada: empieza en el inicio del recorte y se detiene en el final.
final class TrimPlaybackSync: ObservableObject {
    private var player: AVPlayer?
    private var timeObserver: Any?
    private var start: Double = 0
    private var end: Double = 0
    private var duration: Double = 0
    private var seekInFlight = false
    private var pendingSeek: CMTime?

    private var isTrimmed: Bool { duration > 0 && (start > 0.05 || end < duration - 0.05) }

    /// Llamar cada vez que se crea un reproductor nuevo (al elegir otro vídeo).
    func attach(_ newPlayer: AVPlayer?) {
        if let player, let timeObserver { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        player = newPlayer
        start = 0
        end = 0
        duration = 0
        seekInFlight = false
        pendingSeek = nil
        guard let newPlayer else { return }
        timeObserver = newPlayer.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 0.05, preferredTimescale: 600), queue: .main
        ) { [weak self] time in
            self?.tick(time)
        }
    }

    /// Llamar cuando cambia el inicio o el final del recorte.
    func update(start newStart: Double, end newEnd: Double, duration newDuration: Double) {
        guard let player else { return }
        let startMoved = abs(newStart - start) > 0.001
        let endMoved = abs(newEnd - end) > 0.001
        start = newStart
        end = newEnd
        duration = newDuration

        player.currentItem?.forwardPlaybackEndTime = (isTrimmed && end < duration - 0.05)
            ? CMTime(seconds: end, preferredTimescale: 600)
            : .invalid
        player.pause()

        // Si solo se movió el final se enseña el último frame del recorte; en cualquier otro caso, el primero.
        let showEnd = endMoved && !startMoved && end < duration - 0.05
        seek(to: showEnd ? max(end - 0.05, start) : start)
    }

    private func tick(_ time: CMTime) {
        guard let player, isTrimmed, player.timeControlStatus != .paused else { return }
        let seconds = CMTimeGetSeconds(time)
        if seconds < start - 0.08 {
            // Empezó fuera del recorte (por ejemplo, al repetir desde el principio del archivo).
            seek(to: start)
        } else if seconds >= end - 0.01 {
            player.pause()
        }
    }

    private func seek(to seconds: Double) {
        let time = CMTime(seconds: max(seconds, 0), preferredTimescale: 600)
        if seekInFlight { pendingSeek = time; return }
        seekInFlight = true
        player?.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] _ in
            DispatchQueue.main.async {
                guard let self else { return }
                self.seekInFlight = false
                if let next = self.pendingSeek {
                    self.pendingSeek = nil
                    self.seek(to: CMTimeGetSeconds(next))
                }
            }
        }
    }
}
