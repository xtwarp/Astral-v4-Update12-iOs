import SwiftUI

struct SettingsView: View {
    let keepURLs: [URL]
    let isBusy: Bool

    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var languageStore = AppLanguageStore.shared
    @ObservedObject private var themeStore = ThemeStore.shared
    @State private var cacheBytes: Int64 = 0
    @State private var message = ""
    @State private var showCredits = false

    var body: some View {
        ZStack {
            NeonBackground().ignoresSafeArea()
            ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text(L.settingsTitle.text)
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(Theme.ink(0.6))
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(Theme.ink(0.7))
                            .frame(width: 34, height: 34)
                            .background(Theme.fill(0.055), in: Circle())
                    }
                }

                themeCard

                languageCard

                storageCard(
                    title: L.cacheTitle.text,
                    detail: formatBytes(cacheBytes),
                    buttonTitle: L.cacheButton.text,
                    icon: "trash",
                    enabled: !isBusy && cacheBytes > 0
                ) {
                    let freed = CacheManager.remove(CacheManager.temporaryFiles(), keeping: keepURLs)
                    message = tr("Liberado", "Freed") + ": \(formatBytes(freed))"
                    refresh()
                }

                if !message.isEmpty {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(LocalStyle.mint)
                }

                Text(L.cacheFootnote.text)
                    .font(.caption)
                    .foregroundStyle(Theme.ink(0.45))

                Button { showCredits = true } label: {
                    HStack {
                        Image(systemName: "doc.text")
                        Text(tr("Créditos y licencias", "Credits & licenses")).font(.subheadline.weight(.semibold))
                        Spacer()
                        Image(systemName: "chevron.right").font(.caption.weight(.bold)).opacity(0.4)
                    }
                    .foregroundStyle(Theme.ink())
                    .padding(.horizontal, 14)
                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
                    .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
                }

                Spacer(minLength: 0)
            }
            .padding(16)
            }
        }
        .preferredColorScheme(themeStore.theme.palette.scheme)
        .presentationDetents([.medium, .large])
        .sheet(isPresented: $showCredits) { CreditsView() }
        .onAppear(perform: refresh)
    }

    private func formatBytes(_ bytes: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        formatter.allowsNonnumericFormatting = false   // "0 KB" en lugar de "Zero KB"
        return formatter.string(fromByteCount: bytes)
    }

    private var themeCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(tr("TEMA", "THEME"))
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(Theme.ink(0.45))
            HStack(spacing: 8) {
                ForEach(AppTheme.allCases) { option in
                    themeOption(option)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
    }

    /// Mini muestra del tema (su fondo y su acento) con el nombre debajo.
    private func themeOption(_ option: AppTheme) -> some View {
        let palette = option.palette
        let selected = themeStore.theme == option
        return Button {
            withAnimation(.easeInOut(duration: 0.2)) { themeStore.theme = option }
        } label: {
            VStack(spacing: 7) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10).fill(palette.base)
                    if palette.blobOpacity > 0 {
                        Circle().fill(Color(red: 0.0, green: 0.85, blue: 1.0)).frame(width: 26, height: 26)
                            .blur(radius: 9).opacity(palette.blobOpacity * 1.6).offset(x: 14, y: -6)
                        Circle().fill(Color(red: 0.75, green: 0.2, blue: 1.0)).frame(width: 26, height: 26)
                            .blur(radius: 9).opacity(palette.blobOpacity * 1.6).offset(x: -14, y: 8)
                    }
                    Capsule()
                        .fill(LinearGradient(colors: [palette.mint, palette.cyan], startPoint: .leading, endPoint: .trailing))
                        .frame(width: 34, height: 9)
                }
                .frame(height: 50)
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Theme.ink(0.15), lineWidth: 1))

                VStack(spacing: 1) {
                    Text(option.displayName)
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                    Text(option.detail)
                        .font(.system(size: 9, weight: .medium, design: .rounded))
                        .lineLimit(1).minimumScaleFactor(0.8)
                        .opacity(0.6)
                }
                .foregroundStyle(Theme.ink())
            }
            .padding(6)
            .frame(maxWidth: .infinity)
            .background(selected ? Theme.fill(0.07) : Color.clear, in: RoundedRectangle(cornerRadius: 13))
            .overlay(
                RoundedRectangle(cornerRadius: 13)
                    .stroke(selected ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.clear), lineWidth: 2)
            )
        }
    }

    private var languageCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(L.settingsLanguage.text)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(Theme.ink(0.45))
            Picker("", selection: $languageStore.language) {
                ForEach(AppLanguage.allCases) { lang in
                    Text(lang.displayName).tag(lang)
                }
            }
            .pickerStyle(.segmented)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
    }

    private func refresh() {
        cacheBytes = CacheManager.size(of: CacheManager.temporaryFiles().filter { url in
            !keepURLs.contains { $0.resolvingSymlinksInPath().path == url.resolvingSymlinksInPath().path }
        })
    }

    private func storageCard(title: String, detail: String, buttonTitle: String, icon: String, enabled: Bool, destructive: Bool = false, action: @escaping () -> Void) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(Theme.ink(0.45))
            Text(detail)
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .foregroundStyle(Theme.ink())
            Button(action: action) {
                HStack(spacing: 8) {
                    Image(systemName: icon)
                    Text(buttonTitle).font(.subheadline.weight(.semibold))
                }
                .foregroundStyle(destructive ? Color.white : Theme.onAccent)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(destructive ? AnyShapeStyle(Color.red.opacity(0.75)) : AnyShapeStyle(LocalStyle.gradient), in: RoundedRectangle(cornerRadius: 13))
            }
            .disabled(!enabled)
            .opacity(enabled ? 1 : 0.4)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
    }
}
