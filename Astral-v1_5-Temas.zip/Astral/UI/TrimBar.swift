import SwiftUI
import AVFoundation

/// Barra de recorte tipo editor de iPhone: tira de miniaturas con dos manijas.
struct TrimBar: View {
    let url: URL
    let duration: Double
    @Binding var start: Double
    @Binding var end: Double
    var disabled: Bool = false

    @State private var thumbs: [CGImage] = []
    @State private var dragOrigin: Double?

    private let handleWidth: CGFloat = 14
    private let barHeight: CGFloat = 50
    private let minGap: Double = 0.5

    private var isTrimmed: Bool { start > 0.05 || end < duration - 0.05 }

    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Text(tr("RECORTAR", "TRIM"))
                    .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1)
                    .foregroundStyle(Theme.ink(0.45))
                Spacer()
                if isTrimmed {
                    Button(tr("Restablecer", "Reset")) { start = 0; end = duration }
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(LocalStyle.mint)
                }
            }

            GeometryReader { geo in
                let width = geo.size.width
                let span = max(width - handleWidth, 1)
                let leftX = CGFloat(start / duration) * span
                let rightX = CGFloat(end / duration) * span

                ZStack(alignment: .leading) {
                    HStack(spacing: 0) {
                        ForEach(Array(thumbs.enumerated()), id: \.offset) { _, image in
                            Image(decorative: image, scale: 1)
                                .resizable().scaledToFill()
                                .frame(width: width / CGFloat(max(thumbs.count, 1)), height: barHeight)
                                .clipped()
                        }
                    }
                    .frame(width: width, height: barHeight, alignment: .leading)
                    .background(Theme.fill(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 8))

                    // Zonas descartadas
                    Rectangle().fill(Color.black.opacity(0.62))
                        .frame(width: leftX + handleWidth / 2, height: barHeight)
                    Rectangle().fill(Color.black.opacity(0.62))
                        .frame(width: max(width - rightX - handleWidth / 2, 0), height: barHeight)
                        .offset(x: rightX + handleWidth / 2)

                    // Marco seleccionado
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(LocalStyle.gradient, lineWidth: 2.5)
                        .shadow(color: LocalStyle.mint.opacity(0.45), radius: 6)
                        .frame(width: max(rightX - leftX + handleWidth, handleWidth * 2), height: barHeight)
                        .offset(x: leftX)

                    handle.offset(x: leftX)
                        .gesture(DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                if dragOrigin == nil { dragOrigin = start }
                                let proposed = (dragOrigin ?? start) + Double(value.translation.width / span) * duration
                                start = min(max(proposed, 0), end - minGap)
                            }
                            .onEnded { _ in dragOrigin = nil })

                    handle.offset(x: rightX)
                        .gesture(DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                if dragOrigin == nil { dragOrigin = end }
                                let proposed = (dragOrigin ?? end) + Double(value.translation.width / span) * duration
                                end = min(max(proposed, start + minGap), duration)
                            }
                            .onEnded { _ in dragOrigin = nil })
                }
            }
            .frame(height: barHeight)

            HStack {
                Text(format(start)).monospacedDigit()
                Spacer()
                Text(tr("Duración", "Duration") + " " + format(end - start)).monospacedDigit()
                Spacer()
                Text(format(end)).monospacedDigit()
            }
            .font(.caption)
            .foregroundStyle(Theme.ink(0.6))
        }
        .padding(12)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 13))
        .overlay(RoundedRectangle(cornerRadius: 13).stroke(LocalStyle.mint.opacity(0.18), lineWidth: 1))
        .opacity(disabled ? 0.5 : 1)
        .allowsHitTesting(!disabled)
        .task(id: url) { thumbs = await Self.makeThumbnails(url: url, count: 10) }
    }

    private var handle: some View {
        RoundedRectangle(cornerRadius: 4)
            .fill(LocalStyle.gradient)
            .frame(width: handleWidth, height: barHeight)
            .overlay(Capsule().fill(Theme.onAccent.opacity(0.55)).frame(width: 2, height: 18))
            .contentShape(Rectangle().inset(by: -10))
    }

    private func format(_ seconds: Double) -> String {
        let total = max(seconds, 0)
        let minutes = Int(total) / 60
        let rest = total - Double(minutes * 60)
        return String(format: "%d:%04.1f", minutes, rest)
    }

    private static func makeThumbnails(url: URL, count: Int) async -> [CGImage] {
        let asset = AVURLAsset(url: url)
        guard let time = try? await asset.load(.duration) else { return [] }
        let total = CMTimeGetSeconds(time)
        guard total.isFinite, total > 0 else { return [] }
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 200, height: 200)
        generator.requestedTimeToleranceBefore = CMTime(seconds: 0.5, preferredTimescale: 600)
        generator.requestedTimeToleranceAfter = CMTime(seconds: 0.5, preferredTimescale: 600)
        var images: [CGImage] = []
        for index in 0..<count {
            let at = CMTime(seconds: total * (Double(index) + 0.5) / Double(count), preferredTimescale: 600)
            if let result = try? await generator.image(at: at) { images.append(result.image) }
        }
        return images
    }
}
