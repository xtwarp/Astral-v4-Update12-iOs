import SwiftUI

/// Temas de color de la app. Se elige en Ajustes y se recuerda entre sesiones.
enum AppTheme: String, CaseIterable, Identifiable {
    case neon, black, light

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .neon: return tr("Neón", "Neon")
        case .black: return tr("Negro", "Black")
        case .light: return tr("Claro", "Light")
        }
    }

    var detail: String {
        switch self {
        case .neon: return tr("El de siempre", "The classic")
        case .black: return tr("Negro puro", "Pure black")
        case .light: return tr("Fondo claro", "Light background")
        }
    }

    var palette: Palette {
        switch self {
        case .neon:
            return Palette(
                scheme: .dark,
                base: Color(red: 0.02, green: 0.03, blue: 0.04),
                ink: .white,
                fillBoost: 1,
                onAccent: .black,
                mint: Color(red: 0.35, green: 0.95, blue: 0.68),
                cyan: Color(red: 0.20, green: 0.85, blue: 1.0),
                blobOpacity: 0.38,
                veil: Color.black.opacity(0.35)
            )
        case .black:
            // Negro puro, sin manchas de color: ahorra batería en pantallas OLED y se ve más sobrio.
            return Palette(
                scheme: .dark,
                base: .black,
                ink: .white,
                fillBoost: 1.25,
                onAccent: .black,
                mint: Color(red: 0.35, green: 0.95, blue: 0.68),
                cyan: Color(red: 0.20, green: 0.85, blue: 1.0),
                blobOpacity: 0,
                veil: .clear
            )
        case .light:
            // Acentos más oscuros para que el texto de color se lea sobre fondo claro;
            // el texto sobre los botones activos pasa a ser blanco.
            return Palette(
                scheme: .light,
                base: Color(red: 0.95, green: 0.96, blue: 0.98),
                ink: Color(red: 0.07, green: 0.08, blue: 0.11),
                fillBoost: 1.7,
                onAccent: .white,
                mint: Color(red: 0.0, green: 0.55, blue: 0.42),
                cyan: Color(red: 0.04, green: 0.46, blue: 0.80),
                blobOpacity: 0.30,
                veil: Color.white.opacity(0.28)
            )
        }
    }
}

struct Palette {
    let scheme: ColorScheme
    /// Fondo base.
    let base: Color
    /// Color del texto y de las superficies translúcidas (blanco en temas oscuros, casi negro en el claro).
    let ink: Color
    /// Las superficies translúcidas se refuerzan en el tema claro para que se noten igual.
    let fillBoost: Double
    /// Color del texto sobre los botones con degradado.
    let onAccent: Color
    let mint: Color
    let cyan: Color
    /// 0 = sin manchas de color de fondo.
    let blobOpacity: Double
    let veil: Color
}

/// Guarda el tema elegido. La vista principal se reconstruye al cambiarlo.
final class ThemeStore: ObservableObject {
    static let shared = ThemeStore()
    private let key = "astral.theme"

    @Published var theme: AppTheme {
        didSet { UserDefaults.standard.set(theme.rawValue, forKey: key) }
    }

    private init() {
        if let raw = UserDefaults.standard.string(forKey: key), let saved = AppTheme(rawValue: raw) {
            theme = saved
        } else {
            theme = .neon
        }
    }
}

/// Colores que dependen del tema activo.
enum Theme {
    static var palette: Palette { ThemeStore.shared.theme.palette }

    /// Texto (y trazos) con la opacidad dada.
    static func ink(_ opacity: Double = 1) -> Color { palette.ink.opacity(opacity) }

    /// Superficies translúcidas (tarjetas, botones apagados).
    static func fill(_ opacity: Double) -> Color {
        palette.ink.opacity(min(opacity * palette.fillBoost, 1))
    }

    /// Texto sobre un botón con degradado.
    static var onAccent: Color { palette.onAccent }
}

enum LocalStyle {
    static var mint: Color { Theme.palette.mint }
    static var cyan: Color { Theme.palette.cyan }
    static var gradient: LinearGradient {
        LinearGradient(colors: [mint, cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

struct NeonBackground: View {
    @ObservedObject private var themeStore = ThemeStore.shared
    @State private var animate = false

    var body: some View {
        let palette = themeStore.theme.palette
        ZStack {
            palette.base
            if palette.blobOpacity > 0 {
                GeometryReader { proxy in
                    let w = proxy.size.width
                    let h = proxy.size.height
                    ZStack {
                        Circle().fill(Color(red: 0.35, green: 1.0, blue: 0.25))
                            .frame(width: w * 0.9, height: w * 0.9)
                            .offset(x: animate ? -w * 0.30 : -w * 0.05, y: animate ? -h * 0.30 : -h * 0.18)
                        Circle().fill(Color(red: 0.0, green: 0.85, blue: 1.0))
                            .frame(width: w * 0.8, height: w * 0.8)
                            .offset(x: animate ? w * 0.35 : w * 0.15, y: animate ? h * 0.05 : h * 0.20)
                        Circle().fill(Color(red: 0.75, green: 0.2, blue: 1.0))
                            .frame(width: w * 0.85, height: w * 0.85)
                            .offset(x: animate ? -w * 0.10 : -w * 0.30, y: animate ? h * 0.38 : h * 0.28)
                    }
                    .frame(width: w, height: h)
                    .blur(radius: 90)
                    .opacity(palette.blobOpacity)
                }
            }
            palette.veil
        }
        .allowsHitTesting(false)
        .onAppear {
            withAnimation(.easeInOut(duration: 9).repeatForever(autoreverses: true)) { animate = true }
        }
    }
}
