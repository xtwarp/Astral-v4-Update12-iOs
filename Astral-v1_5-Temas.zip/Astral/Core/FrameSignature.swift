import Foundation
import CoreVideo

/// Huella barata de un frame BGRA: luminancia en una cuadrícula de 64×36 muestras.
/// Sirve para detectar frames repetidos (animación "a doses/treses") y cortes de escena
/// sin leer el frame completo.
struct FrameSignature {
    static let columns = 64
    static let rows = 36

    let luma: [UInt8]

    init?(pixelBuffer: CVPixelBuffer) {
        guard CVPixelBufferGetPixelFormatType(pixelBuffer) == kCVPixelFormatType_32BGRA else { return nil }
        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(pixelBuffer) else { return nil }

        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        guard width > 0, height > 0 else { return nil }
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)
        let ptr = base.assumingMemoryBound(to: UInt8.self)

        var samples = [UInt8](repeating: 0, count: Self.columns * Self.rows)
        for row in 0..<Self.rows {
            let y = min(height - 1, (2 * row + 1) * height / (2 * Self.rows))
            let line = ptr.advanced(by: y * bytesPerRow)
            for column in 0..<Self.columns {
                let x = min(width - 1, (2 * column + 1) * width / (2 * Self.columns))
                let pixel = line.advanced(by: x * 4)
                let value = (Int(pixel[2]) * 77 + Int(pixel[1]) * 150 + Int(pixel[0]) * 29) >> 8
                samples[row * Self.columns + column] = UInt8(value)
            }
        }
        luma = samples
    }

    /// Diferencia media absoluta (0...255) entre dos huellas.
    func meanAbsoluteDifference(to other: FrameSignature) -> Double {
        var total = 0
        for index in 0..<luma.count {
            total += abs(Int(luma[index]) - Int(other.luma[index]))
        }
        return Double(total) / Double(luma.count)
    }

    /// Si falta alguna huella devuelve un valor intermedio: ni "repetido" ni "corte de escena".
    static func difference(_ a: FrameSignature?, _ b: FrameSignature?) -> Double {
        guard let a, let b else { return 10 }
        return a.meanAbsoluteDifference(to: b)
    }
}
