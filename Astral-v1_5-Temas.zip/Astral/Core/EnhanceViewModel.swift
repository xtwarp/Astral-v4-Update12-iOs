import Foundation
import SwiftUI
import PhotosUI
import CoreImage
import CoreVideo
import AVFoundation
import UIKit

/// Qué hace la pestaña "Mejora de video". Se elige en el menú desplegable.
enum EnhanceMode: String, CaseIterable, Identifiable {
    case quality, fps, both
    var id: String { rawValue }

    var title: String {
        switch self {
        case .quality: return tr("Mejorar calidad", "Improve quality")
        case .fps: return tr("Aumentar fps", "Raise fps")
        case .both: return tr("Mejorar calidad y Aumentar fps", "Improve quality and Raise fps")
        }
    }

    var icon: String {
        switch self {
        case .quality: return "sparkles"
        case .fps: return "film.stack"
        case .both: return "sparkles.rectangle.stack"
        }
    }
}

/// Pestaña "Mejora de video": junta el escalado (Real-ESRGAN) y la interpolación (RIFE) en un solo flujo.
/// - Solo "Mejorar calidad"  → VideoProcessor
/// - Solo "Aumentar fps"     → InterpolationProcessor
/// - Ambas                   → CombinedPipeline (primero escala todo el video y luego interpola ese resultado)
@MainActor
final class EnhanceViewModel: ObservableObject {
    @Published var inputURL: URL?
    @Published var outputURL: URL?
    @Published var progress: Double = 0
    @Published var status = tr("Selecciona un video", "Select a video")
    @Published var isProcessing = false
    @Published var liveFrame: CGImage?
    @Published var liveFrameNumber = 0

    // Qué se hace. nil = todavía no eligió: no se muestran opciones ni se puede comenzar.
    @Published var mode: EnhanceMode?
    var doUpscale: Bool { mode == .quality || mode == .both }
    var doInterpolate: Bool { mode == .fps || mode == .both }

    // Opciones de "Mejorar calidad"
    @Published var selectedModel: RealESRGAN.Model = .animevideo

    // Opciones de "Aumentar fps"
    @Published var factor = 2
    @Published var precision: RIFEInterpolator.Precision = .fp16
    @Published var slowMotion = false

    // Común
    @Published var exportQuality: ExportQuality = .automatic

    @Published var resultTrimStart: Double = 0
    /// Factor de cámara lenta del resultado actual (1 = sin cámara lenta). Lo usa el comparador antes/después.
    @Published var resultSlowFactor: Int = 1

    // Datos del video elegido (para la línea "Resultado")
    @Published var sourceWidth = 0
    @Published var sourceHeight = 0
    @Published var sourceFps: Double = 0

    @Published var videoDuration: Double = 0
    @Published var trimStart: Double = 0
    @Published var trimEnd: Double = 0

    /// nil = vídeo completo.
    var trimRange: CMTimeRange? {
        guard videoDuration > 0, trimEnd > trimStart,
              trimStart > 0.05 || trimEnd < videoDuration - 0.05 else { return nil }
        return CMTimeRange(
            start: CMTime(seconds: trimStart, preferredTimescale: 600),
            duration: CMTime(seconds: trimEnd - trimStart, preferredTimescale: 600)
        )
    }

    // MARK: - Resultado esperado

    /// Cámara lenta solo existe junto con "Aumentar fps".
    private var effectiveSlowMotion: Bool { doInterpolate && slowMotion }

    /// El modelo elegido no puede con un video tan grande (se calcula antes de empezar).
    var isTooLarge: Bool {
        doUpscale && sourceWidth > 0
            && RealESRGAN.exceedsSafeLimit(width: sourceWidth, height: sourceHeight, scale: selectedModel.scale)
    }

    /// Tamaño final del archivo exportado, o nil si aún no se conoce el video.
    var resultSize: (width: Int, height: Int)? {
        guard mode != nil, sourceWidth > 0, sourceHeight > 0 else { return nil }
        var width = sourceWidth
        var height = sourceHeight
        if doUpscale {
            width *= selectedModel.scale
            height *= selectedModel.scale
        }
        let shortSide = exportQuality.shortSide(sourceShortSide: min(sourceWidth, sourceHeight))
        return ExportQuality.fittedSize(width: width, height: height, shortSide: shortSide)
    }

    /// fps del archivo exportado. En cámara lenta los fps se mantienen y es la duración la que crece.
    var resultFps: Double {
        guard sourceFps > 0 else { return 0 }
        if doInterpolate && !slowMotion { return sourceFps * Double(factor) }
        return sourceFps
    }

    private static func fpsText(_ value: Double) -> String {
        if abs(value - value.rounded()) < 0.05 { return "\(Int(value.rounded())) fps" }
        return String(format: "%.2f fps", value)
    }

    /// Ejemplo: "Resultado: 2560×1440 · 60 fps". nil si todavía no hay video.
    var resultSummary: String? {
        guard mode != nil else { return nil }
        if isTooLarge { return tr("Demasiado grande para este modelo", "Too large for this model") }
        guard let size = resultSize, sourceFps > 0 else { return nil }
        var text = tr("Resultado", "Result") + ": \(size.width)×\(size.height) · " + Self.fpsText(resultFps)
        if effectiveSlowMotion { text += " · " + tr("dura ×\(factor)", "lasts ×\(factor)") }
        return text
    }

    // MARK: - Carga del video

    private func loadMetadata(of url: URL) async {
        let asset = AVURLAsset(url: url)
        let seconds = (try? await asset.load(.duration)).map { CMTimeGetSeconds($0) } ?? 0
        videoDuration = seconds.isFinite ? max(seconds, 0) : 0
        trimStart = 0
        trimEnd = videoDuration

        sourceWidth = 0
        sourceHeight = 0
        sourceFps = 0
        let tracks = (try? await asset.loadTracks(withMediaType: .video)) ?? []
        guard let track = tracks.first else { return }
        let size = (try? await track.load(.naturalSize)) ?? .zero
        let transform = (try? await track.load(.preferredTransform)) ?? .identity
        let nominal = (try? await track.load(.nominalFrameRate)) ?? 0
        // Con la rotación aplicada: así coincide con lo que se ve en Fotos.
        let rotated = size.applying(transform)
        sourceWidth = Int(abs(rotated.width).rounded())
        sourceHeight = Int(abs(rotated.height).rounded())
        sourceFps = nominal > 0 ? Double(nominal) : 24
    }

    private var processor: VideoProcessor?
    private var interpolator: InterpolationProcessor?
    private var pipeline: CombinedPipeline?
    private let previewContext = CIContext(options: [.cacheIntermediates: false])

    @Published var batchTotal = 0
    @Published var batchIndex = 0
    @Published var batchResults: [URL] = []
    @Published var batchFailures = 0
    @Published var isBatchRunning = false
    private var batchCancelled = false

    /// Procesa varios vídeos uno tras otro con los ajustes actuales.
    func startBatch(_ items: [PhotosPickerItem]) {
        guard !items.isEmpty, !isProcessing, !isBatchRunning else { return }
        isBatchRunning = true
        batchCancelled = false
        batchTotal = items.count
        batchIndex = 0
        batchResults = []
        batchFailures = 0
        UIApplication.shared.isIdleTimerDisabled = true
        Task {
            for (offset, item) in items.enumerated() {
                if batchCancelled { break }
                batchIndex = offset + 1
                let previous = inputURL
                await importVideo(from: item)
                if batchCancelled { break }
                guard let current = inputURL, current != previous else { batchFailures += 1; continue }
                start()
                while isProcessing { try? await Task.sleep(nanoseconds: 300_000_000) }
                if let output = outputURL {
                    batchResults.append(output)
                } else if !batchCancelled {
                    batchFailures += 1
                }
            }
            isBatchRunning = false
            UIApplication.shared.isIdleTimerDisabled = false
        }
    }

    func importVideo(from item: PhotosPickerItem) async {
        guard !isProcessing else { return }
        status = tr("Cargando video…", "Loading video…")
        do {
            let imported = try await item.loadTransferable(type: ImportedMovie.self)
            guard let imported else { status = tr("No se pudo cargar el video", "Could not load the video"); return }
            let previousInput = inputURL
            inputURL = imported.url
            if previousInput != imported.url { CacheManager.removeIfTemporary(previousInput) }
            outputURL = nil
            liveFrame = nil
            liveFrameNumber = 0
            progress = 0
            await loadMetadata(of: imported.url)
            status = tr("Video seleccionado", "Video selected")
        } catch {
            status = tr("No se pudo cargar el video: \(error.localizedDescription)", "Could not load the video: \(error.localizedDescription)")
        }
    }

    // MARK: - Procesamiento

    func start() {
        guard let sourceURL = inputURL, !isProcessing, mode != nil else { return }
        guard !isTooLarge else { status = resultSummary ?? ""; return }

        let upscale = doUpscale
        let interpolate = doInterpolate
        let slow = effectiveSlowMotion
        let model = selectedModel
        let chosenFactor = factor
        let chosenPrecision = precision
        let shortSide = exportQuality.shortSide(sourceShortSide: min(sourceWidth, sourceHeight))

        resultTrimStart = trimRange.map { CMTimeGetSeconds($0.start) } ?? 0
        resultSlowFactor = slow ? chosenFactor : 1
        isProcessing = true
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        progress = 0

        let progressHandler: (Double, String) -> Void = { [weak self] value, text in
            DispatchQueue.main.async { self?.progress = value; self?.status = text }
        }
        let completionHandler: (Result<URL, Error>) -> Void = { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                self.isProcessing = false
                self.processor = nil
                self.interpolator = nil
                self.pipeline = nil
                switch result {
                case .success(let url):
                    self.outputURL = url
                    self.status = tr("Listo — usa Guardar en Archivos para exportar", "Done — use Save to Files to export")
                case .failure(let error):
                    self.status = error.localizedDescription
                }
            }
        }
        let previewHandler: (CVPixelBuffer, Int) -> Void = { [weak self] pixelBuffer, frameNumber in
            guard let self else { return }
            autoreleasepool {
                let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
                let maxDimension: CGFloat = 900
                let longest = max(ciImage.extent.width, ciImage.extent.height)
                let scale = min(1, maxDimension / max(longest, 1))
                let previewImage = scale < 1 ? ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale)) : ciImage
                if let cg = self.previewContext.createCGImage(previewImage, from: previewImage.extent) {
                    DispatchQueue.main.async {
                        self.liveFrame = cg
                        self.liveFrameNumber = frameNumber
                    }
                }
            }
        }

        if upscale && interpolate {
            status = tr("Paso 1/2 · Cargando \(model.displayName)…", "Step 1/2 · Loading \(model.displayName)…")
            let pipeline = CombinedPipeline()
            self.pipeline = pipeline
            pipeline.run(
                inputURL: sourceURL,
                timeRange: trimRange,
                model: model,
                factor: chosenFactor,
                precision: chosenPrecision,
                exportShortSide: shortSide,
                slowMotion: slow,
                progress: progressHandler,
                framePreview: previewHandler,
                completion: completionHandler
            )
        } else if upscale {
            status = tr("Cargando \(model.displayName)…", "Loading \(model.displayName)…")
            let processor = VideoProcessor()
            self.processor = processor
            processor.process(
                inputURL: sourceURL,
                timeRange: trimRange,
                model: model,
                exportShortSide: shortSide,
                progress: progressHandler,
                framePreview: previewHandler,
                completion: completionHandler
            )
        } else {
            status = tr("Cargando interpolación \(chosenFactor)×…", "Loading \(chosenFactor)× interpolation…")
            let interpolator = InterpolationProcessor()
            self.interpolator = interpolator
            interpolator.process(
                inputURL: sourceURL,
                timeRange: trimRange,
                factor: chosenFactor,
                precision: chosenPrecision,
                upscaleModel: nil,
                exportShortSide: shortSide,
                slowMotion: slow,
                progress: progressHandler,
                framePreview: previewHandler,
                completion: completionHandler
            )
        }
    }

    func cancel() {
        if isBatchRunning { batchCancelled = true }
        processor?.cancel()
        interpolator?.cancel()
        pipeline?.cancel()
        status = tr("Cancelando…", "Cancelling…")
    }

    func relocalizeIdleStatus() {
        guard !isProcessing else { return }
        if status == "Selecciona un video" || status == "Select a video" { status = tr("Selecciona un video", "Select a video") }
        if status == "Video seleccionado" || status == "Video selected" { status = tr("Video seleccionado", "Video selected") }
    }

    // MARK: - Presets

    func makeSection() -> EnhanceSection {
        EnhanceSection(doUpscale: doUpscale, doInterpolate: doInterpolate, modelRaw: selectedModel.rawValue,
                       factor: factor, precisionRaw: precision.rawValue, slowMotion: slowMotion,
                       exportQualityRaw: exportQuality.rawValue)
    }

    func apply(_ section: EnhanceSection) {
        guard !isProcessing, !isBatchRunning else { return }
        if let model = RealESRGAN.Model(rawValue: section.modelRaw), RealESRGAN.Model.videoModels.contains(model) { selectedModel = model }
        switch (section.doUpscale, section.doInterpolate) {
        case (true, true): mode = .both
        case (true, false): mode = .quality
        case (false, true): mode = .fps
        default: mode = nil
        }
        factor = [2, 4].contains(section.factor) ? section.factor : 2
        precision = RIFEInterpolator.Precision(rawValue: section.precisionRaw) ?? .fp16
        slowMotion = section.slowMotion
        exportQuality = ExportQuality(rawValue: section.exportQualityRaw) ?? .automatic
    }
}
