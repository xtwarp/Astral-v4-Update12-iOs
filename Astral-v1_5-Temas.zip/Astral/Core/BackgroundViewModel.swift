import Foundation
import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import ImageIO
import UIKit

@MainActor
final class BackgroundViewModel: ObservableObject {
    @Published var inputImage: CGImage?
    @Published var outputImage: CGImage?
    @Published var isProcessing = false
    @Published var status = tr("Selecciona una imagen", "Select an image")

    @Published var batchTotal = 0
    @Published var batchIndex = 0
    @Published var batchResults: [URL] = []
    @Published var batchFailures = 0
    @Published var isBatchRunning = false
    private let cancelFlag = CancelFlag()

    private let remover = BackgroundRemover()

    var isBusy: Bool { isProcessing || isBatchRunning }

    func relocalizeIdleStatus() {
        guard !isBusy else { return }
        if status == "Selecciona una imagen" || status == "Select an image" { status = tr("Selecciona una imagen", "Select an image") }
        if status == "Imagen seleccionada" || status == "Image selected" { status = tr("Imagen seleccionada", "Image selected") }
    }

    func importImage(from item: PhotosPickerItem) async {
        guard !isBusy else { return }
        status = tr("Cargando imagen…", "Loading image…")
        do {
            guard let data = try await item.loadTransferable(type: Data.self),
                  let image = BackgroundRemover.loadImage(from: data) else {
                status = tr("No se pudo cargar la imagen", "Could not load the image")
                return
            }
            inputImage = image
            outputImage = nil
            status = tr("Imagen seleccionada", "Image selected")
        } catch {
            status = tr("No se pudo cargar la imagen: \(error.localizedDescription)", "Could not load the image: \(error.localizedDescription)")
        }
    }

    func start() {
        guard let source = inputImage, !isBusy else { return }
        isProcessing = true
        outputImage = nil
        status = tr("Quitando el fondo…", "Removing the background…")
        let engine = remover
        Task {
            do {
                let result = try await Task.detached(priority: .userInitiated) {
                    try engine.cutout(source)
                }.value
                outputImage = result
                status = tr("Listo — guarda el resultado en Archivos", "Done — save the result to Files")
            } catch {
                status = error.localizedDescription
            }
            isProcessing = false
        }
    }

    // MARK: - Lote

    func startBatch(_ items: [PhotosPickerItem]) {
        guard !items.isEmpty, !isBusy else { return }
        isBatchRunning = true
        cancelFlag.value = false
        batchTotal = items.count
        batchIndex = 0
        batchResults = []
        batchFailures = 0
        UIApplication.shared.isIdleTimerDisabled = true
        let flag = cancelFlag
        let engine = remover
        Task {
            for (offset, item) in items.enumerated() {
                if flag.value { break }
                batchIndex = offset + 1
                status = tr("Procesando imagen \(offset + 1)/\(items.count)…", "Processing image \(offset + 1)/\(items.count)…")
                do {
                    guard let data = try await item.loadTransferable(type: Data.self) else { batchFailures += 1; continue }
                    let url = try await Task.detached(priority: .userInitiated) {
                        try BackgroundViewModel.cutoutToTemporaryPNG(data: data, engine: engine, flag: flag)
                    }.value
                    batchResults.append(url)
                } catch {
                    if !flag.value { batchFailures += 1 }
                }
            }
            isBatchRunning = false
            UIApplication.shared.isIdleTimerDisabled = false
            status = flag.value ? tr("Lote cancelado", "Batch cancelled") : tr("Lote terminado", "Batch finished")
        }
    }

    func cancelBatch() {
        cancelFlag.value = true
        status = tr("Cancelando…", "Cancelling…")
    }

    nonisolated private static func cutoutToTemporaryPNG(data: Data, engine: BackgroundRemover, flag: CancelFlag) throws -> URL {
        guard let image = BackgroundRemover.loadImage(from: data) else { throw UpscaleError.exportFailed }
        let result = try engine.cutout(image) { flag.value }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Result_\(UUID().uuidString).png")
        guard let destination = CGImageDestinationCreateWithURL(url as CFURL, UTType.png.identifier as CFString, 1, nil) else {
            throw UpscaleError.exportFailed
        }
        CGImageDestinationAddImage(destination, result, nil)
        guard CGImageDestinationFinalize(destination) else { throw UpscaleError.exportFailed }
        return url
    }
}
