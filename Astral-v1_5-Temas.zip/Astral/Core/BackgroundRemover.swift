import Foundation
import CoreImage
import CoreGraphics
import ImageIO
import Vision

/// Quita el fondo con el modelo de segmentación de sujetos que trae iOS (Vision, iOS 17+).
/// Es el mismo sistema de «Levantar sujeto» de Fotos: no necesita descargar ningún modelo
/// y funciona sin conexión. El resultado siempre tiene fondo transparente.
final class BackgroundRemover {
    /// Lado máximo de la imagen de entrada (limita la memoria).
    static let maxInputSide = 4096

    private let ciContext = CIContext(options: [.cacheIntermediates: false])

    /// Carga una imagen aplicando la orientación EXIF y limitando su tamaño.
    static func loadImage(from data: Data) -> CGImage? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil) else { return nil }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxInputSide
        ]
        return CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary)
    }

    func cutout(_ image: CGImage, isCancelled: () -> Bool = { false }) throws -> CGImage {
        try autoreleasepool {
            if isCancelled() { throw UpscaleError.cancelled }

            let request = VNGenerateForegroundInstanceMaskRequest()
            let handler = VNImageRequestHandler(cgImage: image, options: [:])
            do {
                try handler.perform([request])
            } catch {
                throw UpscaleError.coreML(tr(
                    "No se pudo analizar la imagen: \(error.localizedDescription)",
                    "Could not analyze the image: \(error.localizedDescription)"
                ))
            }
            if isCancelled() { throw UpscaleError.cancelled }

            guard let observation = request.results?.first, !observation.allInstances.isEmpty else {
                throw UpscaleError.coreML(tr(
                    "No se detectó ningún sujeto claro en la imagen.",
                    "No clear subject was detected in the image."
                ))
            }

            let masked: CVPixelBuffer
            do {
                masked = try observation.generateMaskedImage(
                    ofInstances: observation.allInstances,
                    from: handler,
                    croppedToInstancesExtent: false
                )
            } catch {
                throw UpscaleError.coreML(tr(
                    "No se pudo separar el sujeto: \(error.localizedDescription)",
                    "Could not separate the subject: \(error.localizedDescription)"
                ))
            }

            let output = CIImage(cvPixelBuffer: masked)
            guard let result = ciContext.createCGImage(
                output,
                from: output.extent,
                format: .RGBA8,
                colorSpace: CGColorSpace(name: CGColorSpace.sRGB)
            ) else {
                throw UpscaleError.exportFailed
            }
            return result
        }
    }
}
