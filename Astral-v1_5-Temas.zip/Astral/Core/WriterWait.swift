import Foundation
import AVFoundation

/// Espera a que un AVAssetWriterInput esté listo para recibir más datos.
///
/// El bug que causaba los congelamientos: el código anterior solo comprobaba
/// `isCancelled()` dentro del bucle de espera, nunca `writer.status`. Si el
/// escritor fallaba internamente a mitad de proceso (por ejemplo, la sesión
/// de codificación HEVC se invalida por presión de memoria o por calor
/// sostenido), `isReadyForMoreMediaData` se quedaba en `false` para siempre
/// y el bucle giraba en un `Thread.sleep` infinito sin avisar a nadie: la
/// app parecía congelada en ese frame, sin error, sin progreso.
/// Ahora se revisa `writer.status` en cada vuelta y, si falló, se lanza el
/// error real. También hay un límite de tiempo por si el escritor se queda
/// sencillamente estancado sin marcarse como fallido.
enum WriterWait {
    static func until(
        _ input: AVAssetWriterInput,
        writer: AVAssetWriter,
        reader: AVAssetReader,
        timeout: TimeInterval = 20,
        pump: () -> Void = {},
        isCancelled: () -> Bool
    ) throws {
        let start = Date()
        while !input.isReadyForMoreMediaData {
            pump()
            if input.isReadyForMoreMediaData { break }
            if isCancelled() {
                reader.cancelReading(); writer.cancelWriting()
                throw UpscaleError.cancelled
            }
            if writer.status == .failed {
                reader.cancelReading()
                throw writer.error ?? UpscaleError.writerFailed
            }
            if writer.status == .cancelled {
                reader.cancelReading()
                throw UpscaleError.cancelled
            }
            if Date().timeIntervalSince(start) > timeout {
                reader.cancelReading(); writer.cancelWriting()
                throw UpscaleError.writerStalled
            }
            Thread.sleep(forTimeInterval: 0.002)
        }
    }
}
