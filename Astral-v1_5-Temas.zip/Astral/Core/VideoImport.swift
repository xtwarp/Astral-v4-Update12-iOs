import Foundation
import SwiftUI
import UniformTypeIdentifiers

struct ImportedMovie: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { movie in SentTransferredFile(movie.url) } importing: { received in
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Input_\(UUID().uuidString).mp4")
            try FileManager.default.copyItem(at: received.file, to: destination)
            return ImportedMovie(url: destination)
        }
    }
}

struct VideoDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.movie] }
    static var writableContentTypes: [UTType] { [.movie] }
    let url: URL
    init(url: URL) { self.url = url }
    init(configuration: ReadConfiguration) throws {
        let temp = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Imported_\(UUID().uuidString).mp4")
        guard let data = configuration.file.regularFileContents else { throw CocoaError(.fileReadCorruptFile) }
        try data.write(to: temp)
        self.url = temp
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { try FileWrapper(url: url, options: .immediate) }
}
