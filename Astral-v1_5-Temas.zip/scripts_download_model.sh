#!/bin/bash
set -euo pipefail
BASE="https://github.com/hanxiao/real-esrgan-coreml/releases/download/v1.0.0"
OUT="Astral/Resources"
mkdir -p "$OUT"

for MODEL in animevideo general anime_6B x4plus; do
  ZIP="$OUT/RealESRGAN_${MODEL}_522_fp16.zip"
  PKG="$OUT/RealESRGAN_${MODEL}_522_fp16.mlpackage"
  if [ -d "$PKG" ]; then
    echo "Modelo ya presente: $MODEL"
    continue
  fi
  echo "Descargando Real-ESRGAN $MODEL..."
  curl -L --fail --retry 3 "$BASE/RealESRGAN_${MODEL}_522_fp16.zip" -o "$ZIP"
  unzip -o "$ZIP" -d "$OUT"
  rm -f "$ZIP"
  if [ ! -d "$PKG" ]; then
    echo "ERROR: no se encontró $PKG después de extraer el release."
    find "$OUT" -maxdepth 2 -print
    exit 1
  fi
done
