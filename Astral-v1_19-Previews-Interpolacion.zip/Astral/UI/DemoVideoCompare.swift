import SwiftUI
import UIKit
import AVFoundation

/// Videos de ejemplo de la pantalla de bienvenida (carpeta Resources/Demo).
/// Si no están en la app, esa pestaña simplemente no aparece.
enum DemoVideos {
    struct Clip: Identifiable {
        let id: String
        let title: String
        let before: URL
        let after: URL
        /// Textos de las etiquetas de cada lado (por ejemplo, los fps).
        let beforeText: String
        let afterText: String
        /// Ancho / alto de los videos.
        let aspect: CGFloat
    }

    /// Interpolación de frames: 30 fps (antes) frente a 60 fps (después). Los dos videos miden 1280×960.
    static var interpolation: Clip? {
        guard let before = url("interpolacion-antes"), let after = url("interpolacion-despues") else { return nil }
        return Clip(id: "interpolation", title: tr("Interpolación", "Interpolation"),
                    before: before, after: after, beforeText: "30 FPS", afterText: "60 FPS", aspect: 4.0 / 3.0)
    }

    private static func url(_ name: String) -> URL? {
        Bundle.main.url(forResource: name, withExtension: "mp4")
            ?? Bundle.main.url(forResource: name, withExtension: "mp4", subdirectory: "Demo")
    }
}

/// Reproduce los dos videos de ejemplo en bucle y en sincronía: los dos arrancan en el mismo instante y,
/// cada vez que el más corto termina, vuelven a empezar juntos (así no se desfasan con las repeticiones).
final class DemoLoopController: ObservableObject {
    let before: AVPlayer
    let after: AVPlayer
    private var active = false
    private var started = false
    private var endObserver: NSObjectProtocol?
    private var foregroundObserver: NSObjectProtocol?
    private var statusObservers: [NSKeyValueObservation] = []

    init(beforeURL: URL, afterURL: URL) {
        before = AVPlayer(url: beforeURL)
        after = AVPlayer(url: afterURL)
        for player in [before, after] {
            player.isMuted = true
            player.actionAtItemEnd = .pause
            // Necesario para arrancar los dos en un instante exacto con setRate(_:time:atHostTime:).
            player.automaticallyWaitsToMinimizeStalling = false
        }
        endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime, object: after.currentItem, queue: .main
        ) { [weak self] _ in self?.restart() }
        // Al volver a la app desde segundo plano los videos quedan en pausa: se reanudan.
        foregroundObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.willEnterForegroundNotification, object: nil, queue: .main
        ) { [weak self] _ in self?.restart() }
        for player in [before, after] {
            guard let item = player.currentItem else { continue }
            statusObservers.append(item.observe(\.status, options: [.new]) { [weak self] _, _ in
                DispatchQueue.main.async { self?.startWhenReady() }
            })
        }
    }

    deinit {
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        if let foregroundObserver { NotificationCenter.default.removeObserver(foregroundObserver) }
        before.pause(); after.pause()
    }

    private var bothReady: Bool {
        before.currentItem?.status == .readyToPlay && after.currentItem?.status == .readyToPlay
    }

    func start() {
        active = true
        startWhenReady()
    }

    func stop() {
        active = false
        started = false
        before.pause(); after.pause()
    }

    private func startWhenReady() {
        guard active, !started, bothReady else { return }
        started = true
        restart()
    }

    private func restart() {
        guard active, bothReady else { return }
        before.pause(); after.pause()
        let group = DispatchGroup()
        for player in [before, after] {
            group.enter()
            player.seek(to: .zero, toleranceBefore: .zero, toleranceAfter: .zero) { _ in group.leave() }
        }
        group.notify(queue: .main) { [weak self] in
            guard let self, self.active else { return }
            let now = CMClockGetTime(CMClockGetHostTimeClock())
            let host = CMTimeAdd(now, CMTime(seconds: 0.1, preferredTimescale: 1000))
            self.before.setRate(1, time: .zero, atHostTime: host)
            self.after.setRate(1, time: .zero, atHostTime: host)
        }
    }
}

/// Comparativa antes/después con video, igual que la de imágenes de la bienvenida: línea que se arrastra,
/// zoom con pellizco y doble toque para restablecer. Los dos videos se repiten en bucle, sin sonido.
struct DemoVideoCompare: View {
    let clip: DemoVideos.Clip
    /// Avisa cuando el zoom se activa o se restablece.
    var onZoomChange: ((Bool) -> Void)? = nil

    @StateObject private var controller: DemoLoopController
    @State private var position: CGFloat = 0.5
    @State private var zoomState = ZoomState()

    init(clip: DemoVideos.Clip, onZoomChange: ((Bool) -> Void)? = nil) {
        self.clip = clip
        self.onZoomChange = onZoomChange
        _controller = StateObject(wrappedValue: DemoLoopController(beforeURL: clip.before, afterURL: clip.after))
    }

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black
                PlayerLayerView(player: controller.after).allowsHitTesting(false)
                    .scaleEffect(zoomState.zoom).offset(zoomState.offset)
                PlayerLayerView(player: controller.before).allowsHitTesting(false)
                    .scaleEffect(zoomState.zoom).offset(zoomState.offset)
                    .mask(alignment: .leading) { Rectangle().frame(width: proxy.size.width * position, height: proxy.size.height) }

                ZoomGestureSurface(state: $zoomState, size: proxy.size, prioritizeDrag: true)

                CompareDivider(position: $position, size: proxy.size)

                VStack {
                    HStack {
                        tag(clip.beforeText)
                        Spacer()
                        tag(clip.afterText)
                    }
                    .padding(10)
                    .allowsHitTesting(false)
                    ZoomBadge(state: $zoomState)
                    Spacer()
                }
            }
            .coordinateSpace(name: "compare")
            .clipped()
        }
        .aspectRatio(clip.aspect, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Theme.ink(0.12), lineWidth: 1))
        .onChange(of: zoomState.isZoomed) { _, zoomed in onZoomChange?(zoomed) }
        .onAppear { controller.start() }
        .onDisappear {
            controller.stop()
            onZoomChange?(false)
        }
    }

    private func tag(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 10, weight: .heavy, design: .rounded))
            .tracking(0.8)
            .foregroundStyle(.white)
            .padding(.horizontal, 9).padding(.vertical, 5)
            .background(.black.opacity(0.5), in: Capsule())
    }
}
