import Foundation
import Photos
import SwiftUI
import CoreTransferable
import UniformTypeIdentifiers
import ImageIO
import UIKit

enum PhotoSaveError: LocalizedError {
    case denied, encodingFailed
    /// Fotos rechaza el video (PHPhotosErrorInvalidResource, código 3302): suele pasar con muchos fotogramas por segundo
    /// para su resolución. El resultado está bien: se puede guardar en Archivos o compartir.
    case unsupportedVideo

    var errorDescription: String? {
        switch self {
        case .denied:
            return tr("Astral no tiene permiso para guardar en Fotos. Usa Compartir › Guardar, o actívalo en Ajustes.", "Astral doesn't have permission to save to Photos. Use Share › Save, or enable it in Settings.")
        case .encodingFailed:
            return tr("No se pudo preparar la imagen para guardarla.", "Could not prepare the image for saving.")
        case .unsupportedVideo:
            return tr("Fotos no admite este video: tiene demasiados fotogramas por segundo para su tamaño. El resultado está bien; guárdalo en Archivos o compártelo.",
                      "Photos can't store this video: it has too many frames per second for its size. The result is fine; save it to Files or share it.")
        }
    }
}

/// Ajuste "Guardar en Fotos al terminar" (Ajustes). Apagado por defecto.
enum AutoSave {
    static let key = "astral.autoSavePhotos"
    static var isOn: Bool { UserDefaults.standard.bool(forKey: key) }
}

/// Guarda resultados directamente en la fototeca (solo permiso de añadir).
enum PhotoSaver {
    private static func authorize() async throws {
        var status = PHPhotoLibrary.authorizationStatus(for: .addOnly)
        if status == .notDetermined {
            status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        }
        guard status == .authorized || status == .limited else { throw PhotoSaveError.denied }
    }

    /// Cambia el error genérico de Fotos por uno que se entiende (el texto del sistema sale en inglés y no explica nada).
    private static func friendly(_ error: Error) -> Error {
        let nsError = error as NSError
        if nsError.domain == PHPhotosErrorDomain, nsError.code == 3302 { return PhotoSaveError.unsupportedVideo }
        return error
    }

    static func saveVideo(at url: URL) async throws {
        try await authorize()
        do {
            try await PHPhotoLibrary.shared().performChanges {
                let options = PHAssetResourceCreationOptions()
                options.shouldMoveFile = false
                PHAssetCreationRequest.forAsset().addResource(with: .video, fileURL: url, options: options)
            }
        } catch {
            throw friendly(error)
        }
    }

    /// Se guarda como PNG para conservar la transparencia y la calidad.
    static func saveImage(_ image: CGImage) async throws {
        guard let data = pngData(image) else { throw PhotoSaveError.encodingFailed }
        try await authorize()
        try await PHPhotoLibrary.shared().performChanges {
            PHAssetCreationRequest.forAsset().addResource(with: .photo, data: data, options: nil)
        }
    }

    /// Guarda varios archivos (vídeos o imágenes) en una sola operación, p. ej. el resultado de un lote.
    static func saveFiles(_ urls: [URL]) async throws {
        guard !urls.isEmpty else { return }
        try await authorize()
        let videoExtensions: Set<String> = ["mp4", "mov", "m4v"]
        do {
            try await PHPhotoLibrary.shared().performChanges {
                for url in urls {
                    let options = PHAssetResourceCreationOptions()
                    options.shouldMoveFile = false
                    let type: PHAssetResourceType = videoExtensions.contains(url.pathExtension.lowercased()) ? .video : .photo
                    PHAssetCreationRequest.forAsset().addResource(with: type, fileURL: url, options: options)
                }
            }
        } catch {
            throw friendly(error)
        }
    }

    static func pngData(_ image: CGImage) -> Data? {
        let data = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(destination, image, nil)
        return CGImageDestinationFinalize(destination) ? data as Data : nil
    }
}

/// Imagen compartible como PNG (con transparencia).
struct ShareableImage: Transferable {
    let image: CGImage

    static var transferRepresentation: some TransferRepresentation {
        DataRepresentation(exportedContentType: .png) { item in
            guard let data = PhotoSaver.pngData(item.image) else { throw PhotoSaveError.encodingFailed }
            return data
        }
    }
}

// MARK: - Barra de resultado: Guardar en Fotos | Compartir

struct ShareBarLabel: View {
    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "square.and.arrow.up")
            Text(tr("Compartir", "Share")).lineLimit(1)
        }
        .font(.system(size: 14, weight: .semibold, design: .rounded))
        .foregroundStyle(Theme.ink())
        .frame(width: 124, height: 50)
        .background(Theme.fill(0.14))
    }
}

/// Guarda copias de los archivos donde el usuario elija en Archivos (iCloud Drive, En mi iPhone…).
struct FilesExportPicker: UIViewControllerRepresentable {
    let urls: [URL]

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        UIDocumentPickerViewController(forExporting: urls, asCopy: true)
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
}

struct ResultActionBar<Share: View>: View {
    let save: () async throws -> Void
    let share: Share
    /// Archivos del resultado: si Fotos no los admite se ofrece guardarlos en Archivos.
    var exportURLs: [URL] = []

    @State private var message: String?
    @State private var isSaving = false
    @State private var permissionDenied = false
    @State private var offerFiles = false
    @State private var showFilesExport = false

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 2) {
                Button {
                    guard !isSaving else { return }
                    isSaving = true
                    message = nil
                    permissionDenied = false
                    offerFiles = false
                    Task {
                        do {
                            try await save()
                            message = tr("Guardado en Fotos", "Saved to Photos")
                        } catch {
                            message = error.localizedDescription
                            if case PhotoSaveError.denied = error { permissionDenied = true }
                            if case PhotoSaveError.unsupportedVideo = error { offerFiles = !exportURLs.isEmpty }
                        }
                        isSaving = false
                    }
                } label: {
                    HStack(spacing: 8) {
                        if isSaving {
                            ProgressView().tint(Theme.onAccent)
                        } else {
                            Image(systemName: "square.and.arrow.down")
                        }
                        Text(tr("Guardar en Fotos", "Save to Photos")).lineLimit(1).minimumScaleFactor(0.8)
                    }
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(Theme.onAccent)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(LocalStyle.gradient)
                }
                share
            }
            .clipShape(RoundedRectangle(cornerRadius: 13))
            .shadow(color: LocalStyle.mint.opacity(0.25), radius: 8)

            if let message {
                Text(message).font(.caption).foregroundStyle(Theme.ink(0.6))
            }
            if permissionDenied {
                Button { NotificationManager.openSystemSettings() } label: {
                    Text(tr("Abrir Ajustes", "Open Settings"))
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(LocalStyle.mint)
                }
            }
            if offerFiles {
                Button { showFilesExport = true } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "folder")
                        Text(L.saveToFiles.text)
                    }
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(Theme.ink())
                    .frame(maxWidth: .infinity)
                    .frame(height: 44)
                    .background(Theme.fill(0.14), in: RoundedRectangle(cornerRadius: 13))
                }
            }
        }
        .sheet(isPresented: $showFilesExport) {
            FilesExportPicker(urls: exportURLs).ignoresSafeArea()
        }
    }
}
