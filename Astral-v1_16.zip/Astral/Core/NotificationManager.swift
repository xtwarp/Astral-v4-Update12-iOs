import Foundation
import UserNotifications
import UIKit

/// Ajuste "Notificar al terminar" (Ajustes). Apagado por defecto.
enum NotifyOnFinish {
    static let key = "astral.notifyOnFinish"
    static var isOn: Bool { UserDefaults.standard.bool(forKey: key) }
}

/// Avisos locales (sin servidor): nada sale del iPhone.
enum NotificationManager {
    private static let finishedID = "astral.finished"
    private static let pausedID = "astral.paused"

    /// Pide permiso (solo la primera vez muestra el diálogo del sistema). Devuelve si quedó permitido.
    static func requestPermission() async -> Bool {
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        switch settings.authorizationStatus {
        case .authorized, .provisional, .ephemeral:
            return true
        case .denied:
            return false
        default:
            return (try? await center.requestAuthorization(options: [.alert, .sound])) ?? false
        }
    }

    static func notifyFinished(success: Bool) {
        guard NotifyOnFinish.isOn else { return }
        let body = success
            ? tr("Terminó el procesamiento. Tu resultado está listo.", "Processing finished. Your result is ready.")
            : tr("El procesamiento se detuvo. Ábrela para ver qué pasó.", "Processing stopped. Open the app to see what happened.")
        post(id: finishedID, body: body, delay: 1)
    }

    /// Al salir de la app mientras procesa: el trabajo queda en pausa y se retoma al volver.
    static func notifyPaused() {
        guard NotifyOnFinish.isOn else { return }
        post(id: pausedID, body: tr("Astral está en pausa. Ábrela para continuar.", "Astral is paused. Open it to continue."), delay: 2)
    }

    /// Al volver a la app se quitan los avisos pendientes o ya mostrados.
    static func clearAll() {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [finishedID, pausedID])
        center.removeDeliveredNotifications(withIdentifiers: [finishedID, pausedID])
    }

    private static func post(id: String, body: String, delay: TimeInterval) {
        let content = UNMutableNotificationContent()
        content.title = "Astral"
        content.body = body
        content.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: delay, repeats: false)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
    }

    static func openSystemSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(url)
    }
}
