import Foundation
import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import ImageIO
import UIKit

@MainActor
final class ImageViewModel: ObservableObject {
    @Published var inputImage: CGImage?
    @Published var outputImage: CGImage?
    @Published var isProcessing = false
    @Published var status = tr("Selecciona una imagen", "Select an image")
    @Published var selectedModel: RealESRGAN.Model = .general
    @Published var needsLargeConfirmation = false

    @Published var batchTotal = 0
    @Published var batchIndex = 0
    @Published var batchResults: [URL] = []
    @Published var batchFailures = 0
    @Published var isBatchRunning = false
    private let cancelFlag = CancelFlag()

    var isBusy: Bool { isProcessing || isBatchRunning }

    /// Procesa varias imágenes seguidas con el modelo actual. Cada resultado se escribe como PNG
    /// temporal para no acumular imágenes enormes en memoria.
    func startBatch(_ items: [PhotosPickerItem]) {
        guard !items.isEmpty, !isBusy else { return }
        isBatchRunning = true
        cancelFlag.value = false
        batchTotal = items.count
        batchIndex = 0
        batchResults = []
        batchFailures = 0
        needsLargeConfirmation = false
        UIApplication.shared.isIdleTimerDisabled = true
        let model = selectedModel
        let flag = cancelFlag
        status = tr("Cargando \(model.displayName)…", "Loading \(model.displayName)…")
        Task {
            do {
                let engine = try await Task.detached(priority: .userInitiated) { try RealESRGAN(model: model) }.value
                for (offset, item) in items.enumerated() {
                    if flag.value { break }
                    batchIndex = offset + 1
                    status = tr("Procesando imagen \(offset + 1)/\(items.count)…", "Processing image \(offset + 1)/\(items.count)…")
                    do {
                        guard let data = try await item.loadTransferable(type: Data.self) else { batchFailures += 1; continue }
                        let url = try await Task.detached(priority: .userInitiated) {
                            try ImageViewModel.upscaleToTemporaryPNG(data: data, engine: engine, model: model, flag: flag)
                        }.value
                        batchResults.append(url)
                        if AutoSave.isOn { try? await PhotoSaver.saveFiles([url]) }
                    } catch {
                        if !flag.value { batchFailures += 1 }
                    }
                }
            } catch {
                status = error.localizedDescription
            }
            isBatchRunning = false
            UIApplication.shared.isIdleTimerDisabled = false
            if flag.value { status = tr("Lote cancelado", "Batch cancelled") }
            else { status = tr("Lote terminado", "Batch finished") }
        }
    }

    private func autoSave(_ image: CGImage) {
        Task {
            do {
                try await PhotoSaver.saveImage(image)
                status = tr("Listo — guardado en Fotos", "Done — saved to Photos")
            } catch {
                status = error.localizedDescription
            }
        }
    }

    func cancelBatch() {
        cancelFlag.value = true
        status = tr("Cancelando…", "Cancelling…")
    }

    nonisolated private static func upscaleToTemporaryPNG(data: Data, engine: RealESRGAN, model: RealESRGAN.Model, flag: CancelFlag) throws -> URL {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
            throw UpscaleError.invalidVideo
        }
        if RealESRGAN.exceedsSafeLimit(width: image.width, height: image.height, scale: model.scale) {
            throw UpscaleError.frameTooLarge(width: image.width, height: image.height)
        }
        let result = try engine.upscale(cgImage: image, allowLarge: false) { flag.value }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Result_\(UUID().uuidString).png")
        guard let destination = CGImageDestinationCreateWithURL(url as CFURL, UTType.png.identifier as CFString, 1, nil) else {
            throw UpscaleError.exportFailed
        }
        CGImageDestinationAddImage(destination, result, nil)
        guard CGImageDestinationFinalize(destination) else { throw UpscaleError.exportFailed }
        return url
    }

    func relocalizeIdleStatus() {
        guard !isProcessing else { return }
        if isTr(status, "Selecciona una imagen", "Select an image") { status = tr("Selecciona una imagen", "Select an image") }
        if isTr(status, "Imagen seleccionada", "Image selected") { status = tr("Imagen seleccionada", "Image selected") }
    }

    func importImage(from item: PhotosPickerItem) async {
        guard !isBusy else { return }
        status = tr("Cargando imagen…", "Loading image…")
        do {
            guard let data = try await item.loadTransferable(type: Data.self),
                  let source = CGImageSourceCreateWithData(data as CFData, nil),
                  let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
                status = tr("No se pudo cargar la imagen", "Could not load the image")
                return
            }
            inputImage = image
            outputImage = nil
            needsLargeConfirmation = false
            status = tr("Imagen seleccionada", "Image selected")
        } catch {
            status = tr("No se pudo cargar la imagen: \(error.localizedDescription)", "Could not load the image: \(error.localizedDescription)")
        }
    }

    func start(force: Bool = false) {
        guard let source = inputImage, !isBusy else { return }
        let model = selectedModel
        if !force, RealESRGAN.exceedsSafeLimit(width: source.width, height: source.height, scale: model.scale) {
            needsLargeConfirmation = true
            status = tr("La imagen \(source.width)×\(source.height) es muy grande para procesarla a \(model.scale)× con seguridad en este iPhone. Si lo intentas, la app puede cerrarse por falta de memoria.", "The \(source.width)×\(source.height) image is too large to safely process at \(model.scale)× on this iPhone. If you try anyway, the app may close due to lack of memory.")
            return
        }
        needsLargeConfirmation = false
        isProcessing = true
        outputImage = nil
        status = tr("Procesando con \(model.displayName)…", "Processing with \(model.displayName)…")

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                let engine = try RealESRGAN(model: model)
                let result = try engine.upscale(cgImage: source, allowLarge: force) { false }
                DispatchQueue.main.async {
                    self?.outputImage = result
                    self?.isProcessing = false
                    self?.status = tr("Listo — guarda el resultado en Archivos", "Done — save the result to Files")
                    if AutoSave.isOn { self?.autoSave(result) }
                }
            } catch {
                DispatchQueue.main.async {
                    self?.isProcessing = false
                    self?.status = error.localizedDescription
                }
            }
        }
    }
}

struct ImageDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.png, .jpeg] }
    static var writableContentTypes: [UTType] { [.png] }

    let image: CGImage

    init(image: CGImage) { self.image = image }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents,
              let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
            throw CocoaError(.fileReadCorruptFile)
        }
        self.image = image
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        let data = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil) else {
            throw CocoaError(.fileWriteUnknown)
        }
        CGImageDestinationAddImage(destination, image, nil)
        guard CGImageDestinationFinalize(destination) else {
            throw CocoaError(.fileWriteUnknown)
        }
        return FileWrapper(regularFileWithContents: data as Data)
    }
}

/// Bandera de cancelación segura entre hilos.
final class CancelFlag: @unchecked Sendable {
    private let lock = NSLock()
    private var flag = false
    var value: Bool {
        get { lock.lock(); defer { lock.unlock() }; return flag }
        set { lock.lock(); flag = newValue; lock.unlock() }
    }
}
