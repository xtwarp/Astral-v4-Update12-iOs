import Foundation
import CoreVideo
import Accelerate

struct RGBFrame {
    let values: [Float]
    let width: Int
    let height: Int
}

enum PixelBufferTools {
    static func rgbFloatArray(from buffer: CVPixelBuffer) throws -> RGBFrame {
        guard CVPixelBufferGetPixelFormatType(buffer) == kCVPixelFormatType_32BGRA else {
            throw UpscaleError.unsupportedPixelFormat
        }

        CVPixelBufferLockBaseAddress(buffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }

        guard let base = CVPixelBufferGetBaseAddress(buffer) else {
            throw UpscaleError.unsupportedPixelFormat
        }

        let width = CVPixelBufferGetWidth(buffer)
        let height = CVPixelBufferGetHeight(buffer)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(buffer)
        let ptr = base.assumingMemoryBound(to: UInt8.self)
        var rgb = [Float](repeating: 0, count: width * height * 3)

        for y in 0..<height {
            let row = ptr.advanced(by: y * bytesPerRow)
            for x in 0..<width {
                let i = x * 4
                let d = (y * width + x) * 3
                rgb[d] = Float(row[i + 2]) / 255.0
                rgb[d + 1] = Float(row[i + 1]) / 255.0
                rgb[d + 2] = Float(row[i]) / 255.0
            }
        }
        return RGBFrame(values: rgb, width: width, height: height)
    }

    /// Reescala un frame BGRA a otro tamaño (vImage, alta calidad).
    static func resized(_ source: CVPixelBuffer, width: Int, height: Int) throws -> CVPixelBuffer {
        guard CVPixelBufferGetPixelFormatType(source) == kCVPixelFormatType_32BGRA else {
            throw UpscaleError.unsupportedPixelFormat
        }
        var out: CVPixelBuffer?
        let attrs: [CFString: Any] = [kCVPixelBufferIOSurfacePropertiesKey: [:]]
        guard CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA, attrs as CFDictionary, &out) == kCVReturnSuccess,
              let dest = out else {
            throw UpscaleError.writerFailed
        }
        CVPixelBufferLockBaseAddress(source, .readOnly)
        CVPixelBufferLockBaseAddress(dest, [])
        defer {
            CVPixelBufferUnlockBaseAddress(dest, [])
            CVPixelBufferUnlockBaseAddress(source, .readOnly)
        }
        guard let sBase = CVPixelBufferGetBaseAddress(source), let dBase = CVPixelBufferGetBaseAddress(dest) else {
            throw UpscaleError.unsupportedPixelFormat
        }
        var src = vImage_Buffer(
            data: sBase,
            height: vImagePixelCount(CVPixelBufferGetHeight(source)),
            width: vImagePixelCount(CVPixelBufferGetWidth(source)),
            rowBytes: CVPixelBufferGetBytesPerRow(source)
        )
        var dst = vImage_Buffer(
            data: dBase,
            height: vImagePixelCount(height),
            width: vImagePixelCount(width),
            rowBytes: CVPixelBufferGetBytesPerRow(dest)
        )
        let error = vImageScale_ARGB8888(&src, &dst, nil, vImage_Flags(kvImageHighQualityResampling))
        guard error == kvImageNoError else {
            throw UpscaleError.coreML(tr("No se pudo reescalar el frame para interpolar.", "Could not resize the frame for interpolation."))
        }
        return dest
    }

    static func makeBGRA(values: [Float], width: Int, height: Int) throws -> CVPixelBuffer {
        var pb: CVPixelBuffer?
        let attrs: [CFString: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey: true,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ]
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            width,
            height,
            kCVPixelFormatType_32BGRA,
            attrs as CFDictionary,
            &pb
        )
        guard status == kCVReturnSuccess, let buffer = pb else {
            throw UpscaleError.writerFailed
        }

        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        guard let base = CVPixelBufferGetBaseAddress(buffer) else {
            throw UpscaleError.writerFailed
        }

        let ptr = base.assumingMemoryBound(to: UInt8.self)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(buffer)

        for y in 0..<height {
            let row = ptr.advanced(by: y * bytesPerRow)
            for x in 0..<width {
                let s = (y * width + x) * 3
                let d = x * 4
                row[d] = toByte(values[s + 2])
                row[d + 1] = toByte(values[s + 1])
                row[d + 2] = toByte(values[s])
                row[d + 3] = 255
            }
        }
        return buffer
    }

    private static func toByte(_ value: Float) -> UInt8 {
        let clamped = min(max(value, 0.0), 1.0)
        return UInt8((clamped * 255.0).rounded())
    }
}
