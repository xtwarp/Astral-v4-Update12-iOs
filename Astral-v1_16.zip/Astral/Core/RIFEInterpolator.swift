import Foundation
import CoreML
import CoreVideo

/// Interpolación de frames con RIFE 4.25 (MIT, hzwer/Practical-RIFE), convertido a Core ML.
/// Los modelos tienen tamaño de entrada fijo: 1920x1152 en horizontal, 1152x1920 en vertical.
/// Un frame más pequeño se rellena repitiendo su borde y el resultado se recorta de vuelta a su tamaño real.
final class RIFEInterpolator {
    enum Precision: String, CaseIterable, Identifiable {
        case fp16, fp32
        var id: String { rawValue }
        var displayName: String { self == .fp16 ? tr("Rápido", "Fast") : tr("Alta precisión", "High precision") }
        var caption: String { self == .fp16 ? "" : tr("más lento", "slower") }
    }

    private enum Orientation: String {
        case landscape = "Landscape"
        case portrait = "Portrait"
        var maxWidth: Int { self == .landscape ? 1920 : 1152 }
        var maxHeight: Int { self == .landscape ? 1152 : 1920 }
    }

    static var maxSizeDescription: String { tr("1920×1152 en horizontal o 1152×1920 en vertical", "1920×1152 landscape or 1152×1920 portrait") }

    static func exceedsSupportedSize(width: Int, height: Int) -> Bool {
        let orientation: Orientation = width >= height ? .landscape : .portrait
        return width > orientation.maxWidth || height > orientation.maxHeight
    }

    private let precision: Precision
    private var model: MLModel?
    private var loadedOrientation: Orientation?

    private let inputNameA = "img0"
    private let inputNameB = "img1"
    private let inputNameT = "t"
    private let outputName = "mid"

    init(precision: Precision) {
        self.precision = precision
    }

    private func ensureLoaded(width: Int, height: Int) throws {
        let needed: Orientation = width >= height ? .landscape : .portrait
        guard width <= needed.maxWidth, height <= needed.maxHeight else {
            throw UpscaleError.interpolationUnsupportedSize(width: width, height: height)
        }
        if model != nil, loadedOrientation == needed { return }

        let resourceName = "RIFE_\(precision.rawValue)_\(needed.rawValue)"
        guard let url = Bundle.main.url(forResource: resourceName, withExtension: "mlmodelc") else {
            throw UpscaleError.modelMissing(tr("el modelo de interpolación RIFE (\(precision.displayName))", "the RIFE interpolation model (\(precision.displayName))"))
        }
        let configuration = MLModelConfiguration()
        configuration.computeUnits = .cpuAndGPU
        do {
            model = try MLModel(contentsOf: url, configuration: configuration)
        } catch {
            throw UpscaleError.coreML(tr("No se pudo cargar el modelo de interpolación: \(error.localizedDescription)", "Could not load the interpolation model: \(error.localizedDescription)"))
        }
        loadedOrientation = needed
    }

    /// Genera el frame intermedio entre `a` y `b` en el instante `t` (0 a 1). Deben tener el mismo tamaño.
    /// Si el frame es mayor que el tamaño del modelo (p. ej. 4K), se reduce para calcular el frame
    /// intermedio y el resultado se reescala al tamaño original del vídeo.
    func interpolate(a: CVPixelBuffer, b: CVPixelBuffer, t: Float) throws -> CVPixelBuffer {
        let fullW = CVPixelBufferGetWidth(a)
        let fullH = CVPixelBufferGetHeight(a)
        guard Self.exceedsSupportedSize(width: fullW, height: fullH) else {
            return try interpolateFitted(a: a, b: b, t: t)
        }
        let orientation: Orientation = fullW >= fullH ? .landscape : .portrait
        let ratio = min(Double(orientation.maxWidth) / Double(fullW), Double(orientation.maxHeight) / Double(fullH))
        let lowW = max(2, Int((Double(fullW) * ratio).rounded(.down)) & ~1)
        let lowH = max(2, Int((Double(fullH) * ratio).rounded(.down)) & ~1)
        let lowA = try PixelBufferTools.resized(a, width: lowW, height: lowH)
        let lowB = try PixelBufferTools.resized(b, width: lowW, height: lowH)
        let lowMid = try interpolateFitted(a: lowA, b: lowB, t: t)
        return try PixelBufferTools.resized(lowMid, width: fullW, height: fullH)
    }

    private func interpolateFitted(a: CVPixelBuffer, b: CVPixelBuffer, t: Float) throws -> CVPixelBuffer {
        let frameA = try PixelBufferTools.rgbFloatArray(from: a)
        let frameB = try PixelBufferTools.rgbFloatArray(from: b)
        guard frameA.width == frameB.width, frameA.height == frameB.height else {
            throw UpscaleError.coreML(tr("Los dos frames a interpolar tienen tamaños distintos.", "The two frames to interpolate have different sizes."))
        }

        try ensureLoaded(width: frameA.width, height: frameA.height)
        guard let model, let orientation = loadedOrientation else { throw UpscaleError.modelMissing(tr("el modelo de interpolación RIFE", "the RIFE interpolation model")) }

        let targetW = orientation.maxWidth
        let targetH = orientation.maxHeight
        let inputA = try Self.paddedInput(values: frameA.values, width: frameA.width, height: frameA.height, targetW: targetW, targetH: targetH)
        let inputB = try Self.paddedInput(values: frameB.values, width: frameB.width, height: frameB.height, targetW: targetW, targetH: targetH)
        let inputT = try MLMultiArray(shape: [1, 1, 1, 1], dataType: .float32)
        inputT[0] = NSNumber(value: t)

        let output: MLMultiArray
        do {
            let provider = try MLDictionaryFeatureProvider(dictionary: [
                inputNameA: MLFeatureValue(multiArray: inputA),
                inputNameB: MLFeatureValue(multiArray: inputB),
                inputNameT: MLFeatureValue(multiArray: inputT)
            ])
            let result = try model.prediction(from: provider)
            guard let value = result.featureValue(for: outputName)?.multiArrayValue else {
                throw UpscaleError.coreML(tr("El modelo de interpolación no devolvió un resultado.", "The interpolation model returned no result."))
            }
            output = value
        } catch let error as UpscaleError {
            throw error
        } catch {
            throw UpscaleError.coreML(error.localizedDescription)
        }

        let cropped = try Self.croppedOutput(output, width: frameA.width, height: frameA.height)
        return try PixelBufferTools.makeBGRA(values: cropped, width: frameA.width, height: frameA.height)
    }

    private static func paddedInput(values: [Float], width: Int, height: Int, targetW: Int, targetH: Int) throws -> MLMultiArray {
        let array = try MLMultiArray(shape: [1, 3, NSNumber(value: targetH), NSNumber(value: targetW)], dataType: .float32)
        let ptr = array.dataPointer.bindMemory(to: Float32.self, capacity: 3 * targetW * targetH)
        let plane = targetW * targetH
        for y in 0..<targetH {
            let sy = min(y, height - 1)
            for x in 0..<targetW {
                let sx = min(x, width - 1)
                let src = (sy * width + sx) * 3
                let dst = y * targetW + x
                ptr[dst] = values[src]
                ptr[plane + dst] = values[src + 1]
                ptr[2 * plane + dst] = values[src + 2]
            }
        }
        return array
    }

    private static func croppedOutput(_ output: MLMultiArray, width: Int, height: Int) throws -> [Float] {
        let shape = output.shape.map(\NSNumber.intValue)
        guard shape.count == 4, shape[0] == 1, shape[1] == 3 else {
            throw UpscaleError.coreML(tr("Forma de salida inesperada: \(output.shape)", "Unexpected output shape: \(output.shape)"))
        }
        let fullHeight = shape[2]
        let fullWidth = shape[3]
        guard width <= fullWidth, height <= fullHeight else {
            throw UpscaleError.coreML(tr("El modelo de interpolación devolvió un tamaño inesperado.", "The interpolation model returned an unexpected size."))
        }
        let strides = output.strides.map(\NSNumber.intValue)
        guard strides.count == 4 else { throw UpscaleError.coreML(tr("Salida del modelo inválida.", "Invalid model output.")) }

        var result = [Float](repeating: 0, count: width * height * 3)
        func offset(channel: Int, y: Int, x: Int) -> Int { channel * strides[1] + y * strides[2] + x * strides[3] }

        switch output.dataType {
        case .float32:
            let ptr = output.dataPointer.bindMemory(to: Float32.self, capacity: output.count)
            for y in 0..<height { for x in 0..<width {
                let dst = (y * width + x) * 3
                result[dst] = ptr[offset(channel: 0, y: y, x: x)]
                result[dst + 1] = ptr[offset(channel: 1, y: y, x: x)]
                result[dst + 2] = ptr[offset(channel: 2, y: y, x: x)]
            }}
        case .float16:
            let ptr = output.dataPointer.bindMemory(to: UInt16.self, capacity: output.count)
            for y in 0..<height { for x in 0..<width {
                let dst = (y * width + x) * 3
                result[dst] = Float(Float16(bitPattern: ptr[offset(channel: 0, y: y, x: x)]))
                result[dst + 1] = Float(Float16(bitPattern: ptr[offset(channel: 1, y: y, x: x)]))
                result[dst + 2] = Float(Float16(bitPattern: ptr[offset(channel: 2, y: y, x: x)]))
            }}
        default:
            throw UpscaleError.coreML(tr("Tipo de salida no compatible: \(output.dataType)", "Unsupported output type: \(output.dataType)"))
        }
        return result
    }

    static func modelsAvailable(precision: Precision) -> Bool {
        Bundle.main.url(forResource: "RIFE_\(precision.rawValue)_Landscape", withExtension: "mlmodelc") != nil ||
        Bundle.main.url(forResource: "RIFE_\(precision.rawValue)_Portrait", withExtension: "mlmodelc") != nil
    }
}
