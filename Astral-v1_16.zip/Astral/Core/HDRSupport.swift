import Foundation
import AVFoundation
import CoreMedia
import CoreVideo
import VideoToolbox

/// Datos de color de un video HDR (HLG o PQ en BT.2020).
struct HDRInfo {
    let transferFunction: String   // AVVideoTransferFunction_…

    var isPQ: Bool { transferFunction == AVVideoTransferFunction_SMPTE_ST_2084_PQ }

    /// Valor equivalente para las etiquetas de los búferes de píxeles (CoreVideo).
    var bufferTransferFunction: CFString {
        isPQ ? kCVImageBufferTransferFunction_SMPTE_ST_2084_PQ : kCVImageBufferTransferFunction_ITU_R_2100_HLG
    }
}

enum HDRSupport {
    /// nil si el video no es HDR.
    static func info(for track: AVAssetTrack) -> HDRInfo? {
        guard let description = (track.formatDescriptions.first).map({ $0 as! CMFormatDescription }) else { return nil }
        guard let transfer = CMFormatDescriptionGetExtension(
            description, extensionKey: kCMFormatDescriptionExtension_TransferFunction
        ) as? String else { return nil }
        if transfer == (kCMFormatDescriptionTransferFunction_ITU_R_2100_HLG as String) {
            return HDRInfo(transferFunction: AVVideoTransferFunction_ITU_R_2100_HLG)
        }
        if transfer == (kCMFormatDescriptionTransferFunction_SMPTE_ST_2084_PQ as String) {
            return HDRInfo(transferFunction: AVVideoTransferFunction_SMPTE_ST_2084_PQ)
        }
        return nil
    }

    static func isHDR(url: URL) -> Bool {
        guard let track = AVAsset(url: url).tracks(withMediaType: .video).first else { return false }
        return info(for: track) != nil
    }

    /// Ajustes del escritor para exportar en HEVC de 10 bits con las etiquetas de color HDR.
    static func writerSettings(_ base: [String: Any], hdr: HDRInfo) -> [String: Any] {
        var settings = base
        settings[AVVideoColorPropertiesKey] = [
            AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_2020,
            AVVideoTransferFunctionKey: hdr.transferFunction,
            AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_2020
        ]
        var compression = (settings[AVVideoCompressionPropertiesKey] as? [String: Any]) ?? [:]
        compression[AVVideoProfileLevelKey] = kVTProfileLevel_HEVC_Main10_AutoLevel as String
        settings[AVVideoCompressionPropertiesKey] = compression
        return settings
    }

    /// Etiqueta un frame como HDR para que el escritor lo convierta con el espacio de color correcto.
    static func tag(_ buffer: CVPixelBuffer, hdr: HDRInfo) {
        CVBufferSetAttachment(buffer, kCVImageBufferColorPrimariesKey, kCVImageBufferColorPrimaries_ITU_R_2020, .shouldPropagate)
        CVBufferSetAttachment(buffer, kCVImageBufferTransferFunctionKey, hdr.bufferTransferFunction, .shouldPropagate)
        CVBufferSetAttachment(buffer, kCVImageBufferYCbCrMatrixKey, kCVImageBufferYCbCrMatrix_ITU_R_2020, .shouldPropagate)
    }
}
