import Foundation

/// Resolución final del vídeo exportado. Solo reduce; nunca agranda.
/// Se aplica igual a "Mejorar calidad", "Aumentar fps" y a la combinación de ambos.
enum ExportQuality: Int, CaseIterable, Identifiable {
    /// Tal como sale del proceso (si escalas ×4 un 1080p, sale 8K).
    case automatic = 0
    /// Misma resolución que el vídeo que elegiste (útil para limpiar/suavizar sin cambiar el tamaño).
    case sameAsSource = 1
    case p720 = 720
    case p1080 = 1080
    case p1440 = 1440
    case p2160 = 2160

    var id: Int { rawValue }

    /// Límite del lado corto en píxeles. nil = sin límite.
    func shortSide(sourceShortSide: Int) -> Int? {
        switch self {
        case .automatic: return nil
        case .sameAsSource: return sourceShortSide > 0 ? sourceShortSide : nil
        default: return rawValue
        }
    }

    var label: String {
        switch self {
        case .automatic: return tr("Automática", "Automatic")
        case .sameAsSource: return tr("Original", "Original")
        case .p720: return "720p"
        case .p1080: return "1080p"
        case .p1440: return "1440p (2K)"
        case .p2160: return "2160p (4K)"
        }
    }

    /// Tamaño final (par, como exige HEVC) tras aplicar el límite. Lo usan los procesadores y la línea "Resultado".
    static func fittedSize(width: Int, height: Int, shortSide: Int?) -> (width: Int, height: Int) {
        guard let target = shortSide, min(width, height) > target else { return (width, height) }
        let ratio = Double(target) / Double(min(width, height))
        return (
            max(2, Int((Double(width) * ratio).rounded()) & ~1),
            max(2, Int((Double(height) * ratio).rounded()) & ~1)
        )
    }
}
