import SwiftUI
import AVFoundation
import AVKit
import PhotosUI
import UniformTypeIdentifiers

struct ContentView: View {
    enum Tab: String { case video = "VIDEO", image = "IMAGEN", interpolate = "INTERPOLAR" }

    private func title(for tab: Tab) -> String {
        switch tab {
        case .video: return L.tabVideo.text
        case .image: return L.tabImage.text
        case .interpolate: return L.tabInterpolate.text
        }
    }

    @ObservedObject private var languageStore = AppLanguageStore.shared
    @StateObject private var videoVM = VideoViewModel()
    @StateObject private var imageVM = ImageViewModel()
    @StateObject private var interpVM = InterpolationViewModel()
    @State private var tab: Tab = .video
    @State private var selectedVideo: PhotosPickerItem?
    @State private var selectedImage: PhotosPickerItem?
    @State private var selectedInterpVideo: PhotosPickerItem?
    @State private var inputPlayer: AVPlayer?
    @State private var outputPlayer: AVPlayer?
    @State private var interpInputPlayer: AVPlayer?
    @State private var interpOutputPlayer: AVPlayer?
    @State private var showVideoExporter = false
    @State private var videoDocument: VideoDocument?
    @State private var exportingInterpolation = false
    @State private var showImageExporter = false
    @State private var imageDocument: ImageDocument?
    @State private var showSettings = false
    @State private var batchVideoItems: [PhotosPickerItem] = []
    @State private var batchInterpItems: [PhotosPickerItem] = []
    @State private var batchImageItems: [PhotosPickerItem] = []
    @State private var presetsKind: Preset.Kind?

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                NeonBackground().ignoresSafeArea()

                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 14) {
                        tabs
                        switch tab {
                        case .video: videoView(geometry: geometry)
                        case .image: imageView(geometry: geometry)
                        case .interpolate: interpolateView(geometry: geometry)
                        }
                        Spacer(minLength: 0)
                    }
                    .frame(maxWidth: .infinity, minHeight: geometry.size.height, alignment: .top)
                    .padding(.horizontal, 8)
                    .padding(.top, 8)
                    .padding(.bottom, 28)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .preferredColorScheme(.dark)
        .onChange(of: languageStore.language) { _, _ in
            videoVM.relocalizeIdleStatus(); imageVM.relocalizeIdleStatus(); interpVM.relocalizeIdleStatus()
        }
        .onChange(of: batchVideoItems) { _, items in
            guard !items.isEmpty else { return }
            videoVM.startBatch(items)
            batchVideoItems = []
        }
        .onChange(of: batchImageItems) { _, items in
            guard !items.isEmpty else { return }
            imageVM.startBatch(items)
            batchImageItems = []
        }
        .onChange(of: batchInterpItems) { _, items in
            guard !items.isEmpty else { return }
            interpVM.startBatch(items)
            batchInterpItems = []
        }
        .sheet(item: $presetsKind) { kind in
            switch kind {
            case .video:
                PresetsSheet(kind: kind, current: { videoVM.makePreset(name: $0) }, apply: { videoVM.apply($0) })
            case .interpolate:
                PresetsSheet(kind: kind, current: { interpVM.makePreset(name: $0) }, apply: { interpVM.apply($0) })
            case .image:
                PresetsSheet(kind: kind, current: { imageVM.makePreset(name: $0) }, apply: { imageVM.apply($0) })
            }
        }
        .onChange(of: selectedVideo) { _, item in
            guard let item else { return }
            Task { await videoVM.importVideo(from: item); selectedVideo = nil }
        }
        .onChange(of: selectedImage) { _, item in
            guard let item else { return }
            Task { await imageVM.importImage(from: item); selectedImage = nil }
        }
        .onChange(of: selectedInterpVideo) { _, item in
            guard let item else { return }
            Task { await interpVM.importVideo(from: item); selectedInterpVideo = nil }
        }
        .onChange(of: videoVM.inputURL) { _, url in
            inputPlayer?.pause()
            inputPlayer = url.map(AVPlayer.init)
            inputPlayer?.isMuted = true
        }
        .onChange(of: videoVM.outputURL) { _, url in
            outputPlayer?.pause()
            outputPlayer = url.map(AVPlayer.init)
            outputPlayer?.isMuted = true
        }
        .onChange(of: interpVM.inputURL) { _, url in
            interpInputPlayer?.pause()
            interpInputPlayer = url.map(AVPlayer.init)
            interpInputPlayer?.isMuted = true
        }
        .onChange(of: interpVM.outputURL) { _, url in
            interpOutputPlayer?.pause()
            interpOutputPlayer = url.map(AVPlayer.init)
            interpOutputPlayer?.isMuted = true
        }
        .sheet(isPresented: $showSettings) {
            SettingsView(
                keepURLs: ([videoVM.inputURL, videoVM.outputURL, interpVM.inputURL, interpVM.outputURL].compactMap { $0 })
                    + videoVM.batchResults + interpVM.batchResults + imageVM.batchResults,
                isBusy: videoVM.isProcessing || imageVM.isBusy || interpVM.isProcessing || videoVM.isBatchRunning || interpVM.isBatchRunning
            )
        }
        .fileExporter(isPresented: $showVideoExporter, document: videoDocument, contentType: .movie, defaultFilename: exportingInterpolation ? "Astral_Interpolado.mp4" : "Astral_Upscaled.mp4") { result in
            switch result {
            case .success:
                let message = tr("Video exportado a Archivos", "Video exported to Files")
                if exportingInterpolation { interpVM.status = message } else { videoVM.status = message }
            case .failure(let error):
                let message = tr("No se pudo exportar: \(error.localizedDescription)", "Could not export: \(error.localizedDescription)")
                if exportingInterpolation { interpVM.status = message } else { videoVM.status = message }
            }
        }
        .fileExporter(isPresented: $showImageExporter, document: imageDocument, contentType: .png, defaultFilename: "Astral_Upscaled.png") { result in
            switch result {
            case .success: imageVM.status = tr("Imagen exportada a Archivos", "Image exported to Files")
            case .failure(let error): imageVM.status = tr("No se pudo exportar: \(error.localizedDescription)", "Could not export: \(error.localizedDescription)")
            }
        }
    }

    private var tabs: some View {
        VStack(spacing: 6) {
            HStack(spacing: 6) {
                HStack(spacing: 6) {
                    Circle().fill(Color(red: 0.35, green: 0.95, blue: 0.68)).frame(width: 7, height: 7)
                    Text(L.onDevice.text).font(.system(size: 9, weight: .bold, design: .rounded)).tracking(0.8)
                }
                .foregroundStyle(Color(red: 0.35, green: 0.95, blue: 0.68))
                Spacer()
                Button { showSettings = true } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(LocalStyle.mint)
                        .frame(width: 30, height: 30)
                        .background(Color.white.opacity(0.055), in: Circle())
                        .overlay(Circle().stroke(LocalStyle.mint.opacity(0.35), lineWidth: 1))
                }
            }
            HStack(spacing: 4) {
                tabButton(.video)
                tabButton(.image)
            }
            tabButton(.interpolate)
        }
        .padding(4)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 13))
    }

    private func tabButton(_ value: Tab) -> some View {
        Button { tab = value } label: {
            Text(title(for: value))
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .tracking(0.5)
                .minimumScaleFactor(0.75)
                .lineLimit(1)
                .foregroundStyle(tab == value ? .black : .white.opacity(0.55))
                .frame(height: 38)
                .frame(maxWidth: .infinity)
                .background(tab == value ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.clear), in: RoundedRectangle(cornerRadius: 10))
                .shadow(color: tab == value ? LocalStyle.mint.opacity(0.45) : Color.clear, radius: 10)
        }
    }

    @ViewBuilder
    private func videoView(geometry: GeometryProxy) -> some View {
        videoPreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.52, 320))

        presetsButton(.video, busy: videoVM.isProcessing || videoVM.isBatchRunning)

        modelSelector(models: RealESRGAN.Model.videoModels, selected: videoVM.selectedModel) { videoVM.selectedModel = $0 }

        interpolateAlsoToggle

        PhotosPicker(selection: $selectedVideo, matching: .videos, photoLibrary: .shared()) {
            pickerButton(title: L.selectVideo.text, icon: "video.badge.plus")
        }
        .disabled(videoVM.isProcessing || videoVM.isBatchRunning)

        PhotosPicker(selection: $batchVideoItems, maxSelectionCount: 20, matching: .videos, photoLibrary: .shared()) {
            secondaryButton(tr("Procesar varios videos (lote)", "Process several videos (batch)"), color: Color.white.opacity(0.07), icon: "square.stack.3d.up")
        }
        .disabled(videoVM.isProcessing || videoVM.isBatchRunning)

        BatchSummary(isRunning: videoVM.isBatchRunning, index: videoVM.batchIndex, total: videoVM.batchTotal,
                     failures: videoVM.batchFailures, results: videoVM.batchResults)

        if let url = videoVM.inputURL, videoVM.videoDuration > 0 {
            TrimBar(url: url, duration: videoVM.videoDuration, start: $videoVM.trimStart, end: $videoVM.trimEnd,
                    disabled: videoVM.isProcessing || videoVM.isBatchRunning)
        }

        if videoVM.isProcessing || videoVM.isBatchRunning {
            processingSection
        } else {
            Button { videoVM.start() } label: {
                primaryButton(videoVM.alsoInterpolate ? L.startButtonCombined.text : L.startButton.text)
            }
            .disabled(videoVM.inputURL == nil)
            .opacity(videoVM.inputURL == nil ? 0.45 : 1)
        }

        if videoVM.outputURL != nil { videoResult }
    }

    private func modelSelector(models: [RealESRGAN.Model], selected: RealESRGAN.Model, onSelect: @escaping (RealESRGAN.Model) -> Void) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text(L.modelSectionTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
                Spacer()
                Text("\(selected.scale)×").font(.caption.weight(.bold)).foregroundStyle(.white.opacity(0.6))
            }
            HStack(spacing: 7) {
                ForEach(models) { model in
                    Button { onSelect(model) } label: {
                        VStack(spacing: 3) {
                            Text(model.shortName)
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                            HStack(spacing: 3) {
                                if selected == model { Image(systemName: "iphone").font(.system(size: 8, weight: .bold)) }
                                Text(model.caption)
                                    .font(.system(size: 9, weight: .medium, design: .rounded))
                                    .lineLimit(1)
                            }
                            .opacity(selected == model ? 0.75 : 0.55)
                        }
                        .foregroundStyle(selected == model ? .black : .white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                        .background(selected == model ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.white.opacity(0.055)), in: RoundedRectangle(cornerRadius: 12))
                        .shadow(color: selected == model ? LocalStyle.mint.opacity(0.4) : Color.clear, radius: 9)
                    }
                }
            }
        }
    }

    private var interpolateAlsoToggle: some View {
        VStack(spacing: 10) {
            Toggle(isOn: $videoVM.alsoInterpolate.animation()) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(L.alsoInterpolateTitle.text).font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(.white)
                    Text(L.alsoInterpolateSubtitle.text).font(.caption2).foregroundStyle(.white.opacity(0.45))
                }
            }
            .tint(LocalStyle.mint)
            .disabled(videoVM.isProcessing)

            if videoVM.alsoInterpolate {
                HStack(spacing: 7) {
                    ForEach([2, 4], id: \.self) { value in
                        Button { videoVM.interpolationFactor = value } label: {
                            Text("\(value)×").font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundStyle(videoVM.interpolationFactor == value ? .black : .white)
                                .frame(maxWidth: .infinity).frame(height: 38)
                                .background(videoVM.interpolationFactor == value ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.white.opacity(0.055)), in: RoundedRectangle(cornerRadius: 10))
                        }
                        .disabled(videoVM.isProcessing)
                    }
                    Picker("", selection: $videoVM.interpolationPrecision) {
                        ForEach(RIFEInterpolator.Precision.allCases) { option in
                            Text(option == .fp16 ? L.precisionFast.text : L.precisionHigh.text).tag(option)
                        }
                    }
                    .pickerStyle(.segmented)
                    .disabled(videoVM.isProcessing)
                }
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private var videoPreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let frame = videoVM.liveFrame, videoVM.isProcessing {
                Image(decorative: frame, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
            } else if let player = inputPlayer {
                VideoPlayer(player: player)
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "film").font(.system(size: 30)).foregroundStyle(.white.opacity(0.3))
                    Text(L.selectVideoPlaceholderTitle.text).font(.headline).foregroundStyle(.white.opacity(0.85))
                    Text(L.selectVideoPlaceholderSubtitle.text).font(.caption).foregroundStyle(.white.opacity(0.35))
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.07)))
    }

    private var processingSection: some View {
        VStack(spacing: 9) {
            ProgressView(value: videoVM.progress).tint(Color(red: 0.25, green: 0.58, blue: 1))
            HStack {
                Text(videoVM.status).lineLimit(1)
                Spacer()
                Text("\(Int(videoVM.progress * 100))%")
            }
            .font(.caption.weight(.medium)).foregroundStyle(.white.opacity(0.55))

            Button { videoVM.cancel() } label: { secondaryButton(L.cancelButton.text, color: Color(red: 0.75, green: 0.08, blue: 0.12)) }
        }
    }

    private var videoResult: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(L.beforeAfterTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
            ComparisonView(before: inputPlayer, after: outputPlayer)
            if let output = videoVM.outputURL {
                Button {
                    videoDocument = VideoDocument(url: output)
                    exportingInterpolation = false
                    showVideoExporter = true
                } label: { secondaryButton(L.saveToFiles.text, color: Color.white.opacity(0.12), icon: "folder.badge.plus") }
                ShareLink(item: output) {
                    secondaryButton(L.shareExport.text, color: Color.white.opacity(0.07), icon: "square.and.arrow.up")
                }
            }
        }
    }

    @ViewBuilder
    private func interpolateView(geometry: GeometryProxy) -> some View {
        interpPreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.52, 320))

        presetsButton(.interpolate, busy: interpVM.isProcessing || interpVM.isBatchRunning)

        factorSelector

        precisionSelector

        upscaleAfterToggle

        PhotosPicker(selection: $selectedInterpVideo, matching: .videos, photoLibrary: .shared()) {
            pickerButton(title: L.selectVideo.text, icon: "video.badge.plus")
        }
        .disabled(interpVM.isProcessing || interpVM.isBatchRunning)

        PhotosPicker(selection: $batchInterpItems, maxSelectionCount: 20, matching: .videos, photoLibrary: .shared()) {
            secondaryButton(tr("Procesar varios videos (lote)", "Process several videos (batch)"), color: Color.white.opacity(0.07), icon: "square.stack.3d.up")
        }
        .disabled(interpVM.isProcessing || interpVM.isBatchRunning)

        BatchSummary(isRunning: interpVM.isBatchRunning, index: interpVM.batchIndex, total: interpVM.batchTotal,
                     failures: interpVM.batchFailures, results: interpVM.batchResults)

        if let url = interpVM.inputURL, interpVM.videoDuration > 0 {
            TrimBar(url: url, duration: interpVM.videoDuration, start: $interpVM.trimStart, end: $interpVM.trimEnd,
                    disabled: interpVM.isProcessing || interpVM.isBatchRunning)
        }

        if interpVM.isProcessing || interpVM.isBatchRunning {
            interpProcessingSection
        } else {
            Button { interpVM.start() } label: {
                primaryButton(interpVM.alsoUpscale ? L.interpolateButtonCombined.text : "\(L.interpolateButton.text) \(interpVM.factor)×")
            }
            .disabled(interpVM.inputURL == nil)
            .opacity(interpVM.inputURL == nil ? 0.45 : 1)
        }

        if interpVM.outputURL != nil { interpResult }

        Text(interpVM.status).font(.caption).foregroundStyle(.white.opacity(0.45)).frame(maxWidth: .infinity, alignment: .leading)
    }

    private var factorSelector: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(L.interpolateFactorTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
            HStack(spacing: 7) {
                ForEach([2, 4], id: \.self) { value in
                    Button { interpVM.factor = value } label: {
                        VStack(spacing: 2) {
                            Text("\(value)×").font(.system(size: 15, weight: .bold, design: .rounded))
                            HStack(spacing: 3) {
                                if interpVM.factor == value { Image(systemName: "iphone").font(.system(size: 8, weight: .bold)) }
                                Text(value == 2 ? L.interpolateFactorFast.text : L.interpolateFactorSmooth.text).font(.system(size: 9, weight: .medium, design: .rounded))
                            }
                            .opacity(interpVM.factor == value ? 0.75 : 0.55)
                        }
                        .foregroundStyle(interpVM.factor == value ? .black : .white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                        .background(interpVM.factor == value ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.white.opacity(0.055)), in: RoundedRectangle(cornerRadius: 12))
                        .shadow(color: interpVM.factor == value ? LocalStyle.mint.opacity(0.4) : Color.clear, radius: 9)
                    }
                    .disabled(interpVM.isProcessing)
                }
            }
        }
    }

    private var precisionSelector: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(L.precisionTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
                Text(interpVM.precision.displayName + " · " + interpVM.precision.caption)
                    .font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.8))
            }
            Spacer()
            Picker("", selection: $interpVM.precision) {
                ForEach(RIFEInterpolator.Precision.allCases) { option in
                    Text(option == .fp16 ? L.precisionFast.text : L.precisionHigh.text).tag(option)
                }
            }
            .pickerStyle(.segmented)
            .frame(width: 150)
            .disabled(interpVM.isProcessing)
        }
        .padding(12)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private var upscaleAfterToggle: some View {
        VStack(spacing: 10) {
            Toggle(isOn: $interpVM.alsoUpscale.animation()) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(L.alsoUpscaleTitle.text).font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(.white)
                    Text(L.alsoUpscaleSubtitle.text).font(.caption2).foregroundStyle(.white.opacity(0.45))
                }
            }
            .tint(LocalStyle.mint)
            .disabled(interpVM.isProcessing)

            if interpVM.alsoUpscale {
                modelSelector(models: RealESRGAN.Model.videoModels, selected: interpVM.selectedUpscaleModel) { interpVM.selectedUpscaleModel = $0 }
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private var interpPreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let frame = interpVM.liveFrame, interpVM.isProcessing {
                Image(decorative: frame, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
            } else if let player = interpInputPlayer {
                VideoPlayer(player: player)
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "timelapse").font(.system(size: 30)).foregroundStyle(.white.opacity(0.3))
                    Text(L.interpolatePlaceholderTitle.text).font(.headline).foregroundStyle(.white.opacity(0.85))
                    Text(L.interpolatePlaceholderSubtitle.text).font(.caption).foregroundStyle(.white.opacity(0.35))
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.07)))
    }

    private var interpProcessingSection: some View {
        VStack(spacing: 9) {
            ProgressView(value: interpVM.progress).tint(Color(red: 0.25, green: 0.58, blue: 1))
            HStack {
                Text(interpVM.status).lineLimit(1)
                Spacer()
                Text("\(Int(interpVM.progress * 100))%")
            }
            .font(.caption.weight(.medium)).foregroundStyle(.white.opacity(0.55))

            Button { interpVM.cancel() } label: { secondaryButton(L.cancelButton.text, color: Color(red: 0.75, green: 0.08, blue: 0.12)) }
        }
    }

    private var interpResult: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(L.beforeAfterTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
            ComparisonView(before: interpInputPlayer, after: interpOutputPlayer)
            if let output = interpVM.outputURL {
                Button {
                    videoDocument = VideoDocument(url: output)
                    exportingInterpolation = true
                    showVideoExporter = true
                } label: { secondaryButton(L.saveToFiles.text, color: Color.white.opacity(0.12), icon: "folder.badge.plus") }
                ShareLink(item: output) {
                    secondaryButton(L.shareExport.text, color: Color.white.opacity(0.07), icon: "square.and.arrow.up")
                }
            }
        }
    }

    @ViewBuilder
    private func imageView(geometry: GeometryProxy) -> some View {
        imagePreview
            .frame(maxWidth: .infinity)
            .frame(minHeight: max(geometry.size.height * 0.52, 320))

        presetsButton(.image, busy: imageVM.isBusy)

        modelSelector(models: RealESRGAN.Model.imageModels, selected: imageVM.selectedModel) { imageVM.selectedModel = $0 }

        PhotosPicker(selection: $selectedImage, matching: .images, photoLibrary: .shared()) {
            pickerButton(title: L.selectImage.text, icon: "photo.badge.plus")
        }
        .disabled(imageVM.isBusy)

        PhotosPicker(selection: $batchImageItems, maxSelectionCount: 50, matching: .images, photoLibrary: .shared()) {
            secondaryButton(tr("Procesar varias imágenes (lote)", "Process several images (batch)"), color: Color.white.opacity(0.07), icon: "square.stack.3d.up")
        }
        .disabled(imageVM.isBusy)

        BatchSummary(isRunning: imageVM.isBatchRunning, index: imageVM.batchIndex, total: imageVM.batchTotal,
                     failures: imageVM.batchFailures, results: imageVM.batchResults)

        if imageVM.isBatchRunning {
            Button { imageVM.cancelBatch() } label: {
                secondaryButton(tr("Cancelar lote", "Cancel batch"), color: Color.red.opacity(0.35), icon: "xmark")
            }
        }

        Button { imageVM.start() } label: { primaryButton(tr("Mejorar imagen", "Enhance image")) }
            .disabled(imageVM.inputImage == nil || imageVM.isBusy)
            .opacity(imageVM.inputImage == nil || imageVM.isBusy ? 0.45 : 1)

        if imageVM.needsLargeConfirmation && !imageVM.isProcessing {
            Button { imageVM.start(force: true) } label: {
                secondaryButton(L.tryAnyway.text, color: Color.orange.opacity(0.35), icon: "exclamationmark.triangle")
            }
        }

        if let output = imageVM.outputImage, let before = imageVM.inputImage {
            VStack(alignment: .leading, spacing: 10) {
                Text(L.beforeAfterTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45))
                ImageComparisonView(before: before, after: output)
                Button {
                    imageDocument = ImageDocument(image: output)
                    showImageExporter = true
                } label: { secondaryButton(L.saveToFiles.text, color: Color.white.opacity(0.12), icon: "folder.badge.plus") }
            }
        } else if imageVM.isProcessing {
            ProgressView().tint(.white)
        }

        Text(imageVM.status).font(.caption).foregroundStyle(.white.opacity(0.45)).frame(maxWidth: .infinity, alignment: .leading)
    }

    private var imagePreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let image = imageVM.inputImage {
                Image(decorative: image, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
            } else {
                Image(systemName: "photo").font(.system(size: 34)).foregroundStyle(.white.opacity(0.25))
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.07)))
    }

    private func presetsButton(_ kind: Preset.Kind, busy: Bool) -> some View {
        Button { presetsKind = kind } label: {
            secondaryButton("Presets", color: Color.white.opacity(0.07), icon: "bookmark")
        }
        .disabled(busy)
    }

    private func pickerButton(title: String, icon: String) -> some View {
        HStack {
            Image(systemName: icon)
            Text(title).fontWeight(.semibold)
            Spacer()
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).opacity(0.4)
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity).frame(height: 46).padding(.horizontal, 16)
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private func primaryButton(_ title: String) -> some View {
        Text(title).font(.headline.weight(.bold)).foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 50).background(Color(red: 0.12, green: 0.47, blue: 1), in: RoundedRectangle(cornerRadius: 13))
    }

    private func secondaryButton(_ title: String, color: Color, icon: String? = nil) -> some View {
        HStack(spacing: 8) {
            if let icon { Image(systemName: icon) }
            Text(title).font(.subheadline.weight(.semibold))
        }
        .foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 48).background(color, in: RoundedRectangle(cornerRadius: 13))
    }
}

private final class PlayerSyncController: ObservableObject {
    let before: AVPlayer?
    let after: AVPlayer?
    @Published var isPlaying = false
    private var observer: Any?

    init(before: AVPlayer?, after: AVPlayer?) {
        self.before = before; self.after = after
        before?.isMuted = true; after?.isMuted = true
        if let before {
            observer = before.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.08, preferredTimescale: 600), queue: .main) { [weak self] time in
                guard let self, self.isPlaying, let after = self.after else { return }
                let drift = CMTimeGetSeconds(CMTimeSubtract(after.currentTime(), time))
                if abs(drift) > 0.10 { after.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero) }
            }
        }
    }
    deinit { if let observer, let before { before.removeTimeObserver(observer) } }
    func toggle() {
        guard let before, let after else { return }
        if isPlaying { before.pause(); after.pause(); isPlaying = false }
        else { let time = before.currentTime(); after.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero); before.play(); after.play(); isPlaying = true }
    }
    func restart() {
        guard let before, let after else { return }
        before.pause(); after.pause(); before.seek(to: .zero); after.seek(to: .zero); isPlaying = false
    }
}

private struct PlayerLayerView: UIViewRepresentable {
    let player: AVPlayer
    func makeUIView(context: Context) -> PlayerContainer { let view = PlayerContainer(); view.playerLayer.player = player; view.playerLayer.videoGravity = .resizeAspect; return view }
    func updateUIView(_ uiView: PlayerContainer, context: Context) { uiView.playerLayer.player = player }
}
private final class PlayerContainer: UIView { override static var layerClass: AnyClass { AVPlayerLayer.self }; var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer } }

private struct ComparisonView: View {
    let before: AVPlayer?
    let after: AVPlayer?
    @StateObject private var sync: PlayerSyncController
    @State private var position: CGFloat = 0.5
    @State private var zoom: CGFloat = 1
    @State private var lastZoom: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    init(before: AVPlayer?, after: AVPlayer?) { self.before = before; self.after = after; _sync = StateObject(wrappedValue: PlayerSyncController(before: before, after: after)) }

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                if let after { PlayerLayerView(player: after).scaleEffect(zoom).offset(offset).allowsHitTesting(false) }
                if let before {
                    PlayerLayerView(player: before).scaleEffect(zoom).offset(offset).allowsHitTesting(false)
                        .mask(alignment: .leading) { Rectangle().frame(width: proxy.size.width * position) }
                }
                divider(proxy: proxy)
                VStack {
                    HStack { Text(L.beforeLabel.text); Spacer(); Text(L.afterLabel.text) }
                        .font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(.white).padding(12)
                    Spacer()
                    HStack(spacing: 18) {
                        Button { sync.restart() } label: { Image(systemName: "backward.end.fill") }
                        Button { sync.toggle() } label: { Image(systemName: sync.isPlaying ? "pause.fill" : "play.fill") }
                    }
                    .font(.system(size: 18, weight: .bold)).foregroundStyle(.white).padding(.horizontal, 18).padding(.vertical, 10).background(.black.opacity(0.55), in: Capsule()).padding(.bottom, 12)
                }
            }
            .background(.black).clipShape(RoundedRectangle(cornerRadius: 16))
            .gesture(SimultaneousGesture(
                MagnificationGesture().onChanged { value in zoom = min(max(lastZoom * value, 1), 4) }.onEnded { _ in lastZoom = zoom },
                DragGesture().onChanged { value in guard zoom > 1 else { return }; offset = CGSize(width: lastOffset.width + value.translation.width, height: lastOffset.height + value.translation.height) }.onEnded { _ in lastOffset = offset }
            ))
        }
        .frame(minHeight: 320)
        .frame(maxWidth: .infinity)
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.08)))
        .onDisappear { sync.restart() }
    }

    private func divider(proxy: GeometryProxy) -> some View {
        Rectangle().fill(.white).frame(width: 2).frame(maxHeight: .infinity).offset(x: proxy.size.width * position - 1)
            .overlay(Circle().fill(.white).frame(width: 32, height: 32).overlay(Image(systemName: "chevron.left.chevron.right").font(.system(size: 10, weight: .bold)).foregroundStyle(.black)))
            .contentShape(Rectangle().inset(by: -22))
            .gesture(DragGesture().onChanged { value in position = min(max(value.location.x / max(proxy.size.width, 1), 0.02), 0.98) })
    }
}

private struct ImageComparisonView: View {
    let before: CGImage
    let after: CGImage
    @State private var position: CGFloat = 0.5
    @State private var zoom: CGFloat = 1
    @State private var lastZoom: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Image(decorative: after, scale: 1, orientation: .up).resizable().scaledToFit().scaleEffect(zoom).offset(offset)
                Image(decorative: before, scale: 1, orientation: .up).resizable().scaledToFit().scaleEffect(zoom).offset(offset).mask(alignment: .leading) { Rectangle().frame(width: proxy.size.width * position) }
                Rectangle().fill(.white).frame(width: 2).frame(maxHeight: .infinity).offset(x: proxy.size.width * position - 1)
                    .overlay(Circle().fill(.white).frame(width: 32, height: 32).overlay(Image(systemName: "chevron.left.chevron.right").font(.system(size: 10, weight: .bold)).foregroundStyle(.black)))
                    .contentShape(Rectangle().inset(by: -22)).gesture(DragGesture().onChanged { value in position = min(max(value.location.x / max(proxy.size.width, 1), 0.02), 0.98) })
                VStack { HStack { Text(L.beforeLabel.text); Spacer(); Text(L.afterLabel.text) }.font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(.white).padding(12); Spacer() }
            }
            .background(.black).clipShape(RoundedRectangle(cornerRadius: 16))
            .gesture(SimultaneousGesture(
                MagnificationGesture().onChanged { value in zoom = min(max(lastZoom * value, 1), 4) }.onEnded { _ in lastZoom = zoom },
                DragGesture().onChanged { value in guard zoom > 1 else { return }; offset = CGSize(width: lastOffset.width + value.translation.width, height: lastOffset.height + value.translation.height) }.onEnded { _ in lastOffset = offset }
            ))
        }
        .frame(minHeight: 320)
        .frame(maxWidth: .infinity)
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.08)))
    }
}

struct NeonBackground: View {
    @State private var animate = false

    var body: some View {
        ZStack {
            Color(red: 0.02, green: 0.03, blue: 0.04)
            GeometryReader { proxy in
                let w = proxy.size.width
                let h = proxy.size.height
                ZStack {
                    Circle().fill(Color(red: 0.35, green: 1.0, blue: 0.25))
                        .frame(width: w * 0.9, height: w * 0.9)
                        .offset(x: animate ? -w * 0.30 : -w * 0.05, y: animate ? -h * 0.30 : -h * 0.18)
                    Circle().fill(Color(red: 0.0, green: 0.85, blue: 1.0))
                        .frame(width: w * 0.8, height: w * 0.8)
                        .offset(x: animate ? w * 0.35 : w * 0.15, y: animate ? h * 0.05 : h * 0.20)
                    Circle().fill(Color(red: 0.75, green: 0.2, blue: 1.0))
                        .frame(width: w * 0.85, height: w * 0.85)
                        .offset(x: animate ? -w * 0.10 : -w * 0.30, y: animate ? h * 0.38 : h * 0.28)
                }
                .frame(width: w, height: h)
                .blur(radius: 90)
                .opacity(0.38)
            }
            Color.black.opacity(0.35)
        }
        .allowsHitTesting(false)
        .onAppear {
            withAnimation(.easeInOut(duration: 9).repeatForever(autoreverses: true)) { animate = true }
        }
    }
}

enum LocalStyle {
    static let mint = Color(red: 0.35, green: 0.95, blue: 0.68)
    static let cyan = Color(red: 0.20, green: 0.85, blue: 1.0)
    static var gradient: LinearGradient {
        LinearGradient(colors: [mint, cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}
