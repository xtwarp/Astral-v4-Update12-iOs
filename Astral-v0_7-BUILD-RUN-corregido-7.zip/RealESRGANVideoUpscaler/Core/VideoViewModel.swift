import Foundation
import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import CoreImage
import CoreVideo
import AVFoundation
import UIKit

@MainActor
final class VideoViewModel: ObservableObject {
    @Published var inputURL: URL?
    @Published var outputURL: URL?
    @Published var progress: Double = 0
    @Published var status = tr("Selecciona un video", "Select a video")
    @Published var isProcessing = false
    @Published var liveFrame: CGImage?
    @Published var liveFrameNumber = 0
    @Published var selectedModel: RealESRGAN.Model = .animevideo
    @Published var alsoInterpolate = false
    @Published var interpolationFactor = 2
    @Published var interpolationPrecision: RIFEInterpolator.Precision = .fp16

    @Published var videoDuration: Double = 0
    @Published var trimStart: Double = 0
    @Published var trimEnd: Double = 0

    /// nil = vídeo completo.
    var trimRange: CMTimeRange? {
        guard videoDuration > 0, trimEnd > trimStart,
              trimStart > 0.05 || trimEnd < videoDuration - 0.05 else { return nil }
        return CMTimeRange(
            start: CMTime(seconds: trimStart, preferredTimescale: 600),
            duration: CMTime(seconds: trimEnd - trimStart, preferredTimescale: 600)
        )
    }

    private func loadDuration(of url: URL) async {
        let seconds = (try? await AVURLAsset(url: url).load(.duration)).map { CMTimeGetSeconds($0) } ?? 0
        videoDuration = seconds.isFinite ? max(seconds, 0) : 0
        trimStart = 0
        trimEnd = videoDuration
    }

    private var processor: VideoProcessor?
    private var interpolationProcessor: InterpolationProcessor?
    private var securityScopedInput = false
    private let previewContext = CIContext(options: [.cacheIntermediates: false])

    @Published var batchTotal = 0
    @Published var batchIndex = 0
    @Published var batchResults: [URL] = []
    @Published var batchFailures = 0
    @Published var isBatchRunning = false
    private var batchCancelled = false

    /// Procesa varios vídeos uno tras otro con los ajustes actuales.
    func startBatch(_ items: [PhotosPickerItem]) {
        guard !items.isEmpty, !isProcessing, !isBatchRunning else { return }
        isBatchRunning = true
        batchCancelled = false
        batchTotal = items.count
        batchIndex = 0
        batchResults = []
        batchFailures = 0
        UIApplication.shared.isIdleTimerDisabled = true
        Task {
            for (offset, item) in items.enumerated() {
                if batchCancelled { break }
                batchIndex = offset + 1
                let previous = inputURL
                await importVideo(from: item)
                if batchCancelled { break }
                guard let current = inputURL, current != previous else { batchFailures += 1; continue }
                start()
                while isProcessing { try? await Task.sleep(nanoseconds: 300_000_000) }
                if let output = outputURL {
                    batchResults.append(output)
                } else if !batchCancelled {
                    batchFailures += 1
                }
            }
            isBatchRunning = false
            UIApplication.shared.isIdleTimerDisabled = false
        }
    }

    func importVideo(from item: PhotosPickerItem) async {
        guard !isProcessing else { return }
        status = tr("Cargando video…", "Loading video…")
        do {
            let imported = try await item.loadTransferable(type: ImportedMovie.self)
            guard let imported else { status = tr("No se pudo cargar el video", "Could not load the video"); return }
            if securityScopedInput, let oldURL = inputURL { oldURL.stopAccessingSecurityScopedResource() }
            securityScopedInput = false
            let previousInput = inputURL
            inputURL = imported.url
            if previousInput != imported.url { CacheManager.removeIfTemporary(previousInput) }
            outputURL = nil
            liveFrame = nil
            liveFrameNumber = 0
            progress = 0
            await loadDuration(of: imported.url)
            status = tr("Video seleccionado", "Video selected")
        } catch {
            status = tr("No se pudo cargar el video: \(error.localizedDescription)", "Could not load the video: \(error.localizedDescription)")
        }
    }

    func start() {
        guard let sourceURL = inputURL, !isProcessing else { return }
        isProcessing = true
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        progress = 0
        let model = selectedModel

        let framePreview: (CVPixelBuffer, Int) -> Void = { [weak self] pixelBuffer, frameNumber in
            guard let self else { return }
            autoreleasepool {
                let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
                let maxDimension: CGFloat = 900
                let longest = max(ciImage.extent.width, ciImage.extent.height)
                let scale = min(1, maxDimension / max(longest, 1))
                let previewImage = scale < 1 ? ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale)) : ciImage
                if let cg = self.previewContext.createCGImage(previewImage, from: previewImage.extent) {
                    DispatchQueue.main.async {
                        self.liveFrame = cg
                        self.liveFrameNumber = frameNumber
                    }
                }
            }
        }
        let completion: (Result<URL, Error>) -> Void = { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                self.isProcessing = false
                self.processor = nil
                self.interpolationProcessor = nil
                switch result {
                case .success(let url):
                    self.outputURL = url
                        self.status = tr("Listo — usa Guardar en Archivos para exportar", "Done — use Save to Files to export")
                case .failure(let error):
                    self.status = error.localizedDescription
                }
            }
        }

        if alsoInterpolate {
            status = tr("Cargando interpolación \(interpolationFactor)× + \(model.displayName)…", "Loading \(interpolationFactor)× interpolation + \(model.displayName)…")
            let processor = InterpolationProcessor()
            self.interpolationProcessor = processor
            processor.process(
                inputURL: sourceURL,
                timeRange: trimRange,
                factor: interpolationFactor,
                precision: interpolationPrecision,
                upscaleModel: model,
                progress: { [weak self] value, text in
                    DispatchQueue.main.async { self?.progress = value; self?.status = text }
                },
                framePreview: framePreview,
                completion: completion
            )
        } else {
            status = tr("Cargando \(model.displayName)…", "Loading \(model.displayName)…")
            let processor = VideoProcessor()
            self.processor = processor
            processor.process(
                inputURL: sourceURL,
                timeRange: trimRange,
                model: model,
                progress: { [weak self] value, text in
                    DispatchQueue.main.async { self?.progress = value; self?.status = text }
                },
                framePreview: framePreview,
                completion: completion
            )
        }
    }

    func cancel() {
        if isBatchRunning { batchCancelled = true }
        processor?.cancel()
        interpolationProcessor?.cancel()
        status = tr("Cancelando…", "Cancelling…")
    }

    func relocalizeIdleStatus() {
        guard !isProcessing else { return }
        if status == "Selecciona un video" || status == "Select a video" { status = tr("Selecciona un video", "Select a video") }
        if status == "Video seleccionado" || status == "Video selected" { status = tr("Video seleccionado", "Video selected") }
    }

    func makePreset(name: String) -> Preset {
        Preset(name: name, kind: .video, modelRaw: selectedModel.rawValue, includesSecondStep: alsoInterpolate,
               factor: interpolationFactor, precisionRaw: interpolationPrecision.rawValue)
    }

    func apply(_ preset: Preset) {
        guard !isProcessing else { return }
        if let model = RealESRGAN.Model(rawValue: preset.modelRaw), RealESRGAN.Model.videoModels.contains(model) { selectedModel = model }
        alsoInterpolate = preset.includesSecondStep
        interpolationFactor = preset.factor
        interpolationPrecision = RIFEInterpolator.Precision(rawValue: preset.precisionRaw) ?? .fp16
    }

    func discardOutputIfMissing() {
        guard let url = outputURL, !FileManager.default.fileExists(atPath: url.path) else { return }
        outputURL = nil
        liveFrame = nil
        liveFrameNumber = 0
        progress = 0
        status = tr("Selecciona un video", "Select a video")
    }
}

struct ImportedMovie: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { movie in SentTransferredFile(movie.url) } importing: { received in
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Input_\(UUID().uuidString).mp4")
            try FileManager.default.copyItem(at: received.file, to: destination)
            return ImportedMovie(url: destination)
        }
    }
}

struct VideoDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.movie] }
    static var writableContentTypes: [UTType] { [.movie] }
    let url: URL
    init(url: URL) { self.url = url }
    init(configuration: ReadConfiguration) throws {
        let temp = FileManager.default.temporaryDirectory.appendingPathComponent("Astral_Imported_\(UUID().uuidString).mp4")
        guard let data = configuration.file.regularFileContents else { throw CocoaError(.fileReadCorruptFile) }
        try data.write(to: temp)
        self.url = temp
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { try FileWrapper(url: url, options: .immediate) }
}
