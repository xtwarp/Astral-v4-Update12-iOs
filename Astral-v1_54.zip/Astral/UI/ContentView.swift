import SwiftUI
import AVFoundation
import AVKit
import PhotosUI
import UniformTypeIdentifiers

struct ContentView: View {
    enum Tab: String { case enhance = "MEJORA", image = "IMAGEN", background = "FONDO", color = "COLOR" }

    private func title(for tab: Tab) -> String {
        switch tab {
        case .enhance: return tr("MEJORAS DE VIDEO", "VIDEO ENHANCEMENTS")
        case .image: return L.tabImage.text
        case .background: return L.tabBackground.text
        case .color: return L.tabColor.text
        }
    }

    @ObservedObject private var languageStore = AppLanguageStore.shared
    @ObservedObject private var themeStore = ThemeStore.shared
    @StateObject private var enhanceVM = EnhanceViewModel()
    @StateObject private var imageVM = ImageViewModel()
    @StateObject private var enhanceTrimSync = TrimPlaybackSync()
    @StateObject private var backgroundVM = BackgroundViewModel()
    @StateObject private var colorVM = ColorViewModel()
    @ObservedObject private var access = ProAccess.shared
    @State private var quotaPrompt: VideoQuotaPrompt?
    @State private var presetNotice: String?
    @Environment(\.scenePhase) private var scenePhase
    @State private var tab: Tab = .enhance
    @State private var showSuccess = false
    @State private var selectedVideo: PhotosPickerItem?
    @State private var selectedImage: PhotosPickerItem?
    @State private var enhancePlayer: AVPlayer?
    @State private var showSettings = false
    @State private var showPresets = false
    @State private var showMoreTools = false
    @State private var showEnhanceAdvanced = false
    @State private var showColorAdvanced = false
    @State private var batchEnhanceItems: [PhotosPickerItem] = []
    @State private var batchImageItems: [PhotosPickerItem] = []
    @State private var selectedBackgroundImage: PhotosPickerItem?
    @State private var selectedColorItem: PhotosPickerItem?
    @State private var batchBackgroundItems: [PhotosPickerItem] = []

    var body: some View {
        withSheets(withTrimHandlers(withCompletionHandlers(withChangeHandlersB(withChangeHandlersA(mainContent.id(themeStore.theme))))))
    }

    private var mainContent: some View {
        GeometryReader { geometry in
            ZStack {
                NeonBackground().ignoresSafeArea()

                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 14) {
                        tabs
                        switch tab {
                        case .enhance: enhanceView(geometry: geometry)
                        case .image: imageView(geometry: geometry)
                        case .background: backgroundView(geometry: geometry)
                        case .color: colorView(geometry: geometry)
                        }
                        Spacer(minLength: 0)
                    }
                    .frame(maxWidth: .infinity, minHeight: geometry.size.height, alignment: .top)
                    .animation(.easeInOut(duration: 0.25), value: anythingBusy)
                    .animation(.easeInOut(duration: 0.22), value: tab)
                    .padding(.horizontal, 8)
                    .padding(.top, 8)
                    .padding(.bottom, 28)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                if showSuccess {
                    SuccessBurst()
                        .transition(.opacity)
                        .allowsHitTesting(false)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .preferredColorScheme(themeStore.theme.palette.scheme)
    }

    private func withChangeHandlersA<V: View>(_ view: V) -> some View {
        view
        .onChange(of: languageStore.language) { _, _ in
            enhanceVM.relocalizeIdleStatus(); imageVM.relocalizeIdleStatus(); backgroundVM.relocalizeIdleStatus(); colorVM.relocalizeIdleStatus()
        }
        .onChange(of: batchEnhanceItems) { _, items in
            guard !items.isEmpty else { return }
            enhanceVM.startBatch(items)
            batchEnhanceItems = []
        }
        .onChange(of: selectedColorItem) { _, item in
            guard let item else { return }
            Task { await colorVM.importItem(item); selectedColorItem = nil }
        }
        .onChange(of: selectedBackgroundImage) { _, item in
            guard let item else { return }
            Task { await backgroundVM.importImage(from: item); selectedBackgroundImage = nil }
        }
        .onChange(of: batchBackgroundItems) { _, items in
            guard !items.isEmpty else { return }
            backgroundVM.startBatch(items)
            batchBackgroundItems = []
        }
        .onChange(of: batchImageItems) { _, items in
            guard !items.isEmpty else { return }
            imageVM.startBatch(items)
            batchImageItems = []
        }
    }

    private func withChangeHandlersB<V: View>(_ view: V) -> some View {
        view
        .onChange(of: selectedVideo) { _, item in
            guard let item else { return }
            Task { await enhanceVM.importVideo(from: item); selectedVideo = nil }
        }
        .onChange(of: selectedImage) { _, item in
            guard let item else { return }
            Task { await imageVM.importImage(from: item); selectedImage = nil }
        }
        .onChange(of: scenePhase) { _, phase in
            switch phase {
            case .background:
                // iOS 26+: el trabajo sigue en segundo plano (sin GPU). Antes o si iOS no lo permite: se pausa y sigue al volver.
                enhanceVM.sceneEnteredBackground()
            case .active:
                NotificationManager.clearAll()
                UsageQuota.shared.touch()
                enhanceVM.sceneBecameActive()
            default:
                break
            }
        }
        .onChange(of: access.isPro) { _, pro in
            if !pro { enforceFreeSelections() }
        }
        .onChange(of: anythingBusy) { wasBusy, isBusy in
            guard wasBusy, !isBusy, scenePhase != .active else { return }
            let hasResult = enhanceVM.outputURL != nil || imageVM.outputImage != nil
                || backgroundVM.outputImage != nil || colorVM.outputURL != nil
            NotificationManager.notifyFinished(success: hasResult)
        }
        .onChange(of: enhanceVM.inputURL) { _, url in
            enhancePlayer?.pause()
            enhancePlayer = url.map(AVPlayer.init)
            enhanceTrimSync.attach(enhancePlayer)
        }
    }

    /// Al terminar un resultado: vibración suave y una palomita breve (solo con la app a la vista).
    private func withCompletionHandlers<V: View>(_ view: V) -> some View {
        view
        .onChange(of: enhanceVM.outputURL) { old, new in
            if old == nil, new != nil { celebrate() }
        }
        .onChange(of: imageVM.outputImage != nil) { _, hasResult in
            if hasResult { celebrate() }
        }
        .onChange(of: backgroundVM.outputImage != nil) { _, hasResult in
            if hasResult { celebrate() }
        }
        .onChange(of: colorVM.outputURL) { old, new in
            if old == nil, new != nil { celebrate() }
        }
    }

    private func celebrate() {
        guard scenePhase == .active else { return }
        Haptics.success()
        withAnimation(.easeOut(duration: 0.2)) { showSuccess = true }
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 1_400_000_000)
            withAnimation(.easeIn(duration: 0.3)) { showSuccess = false }
        }
    }

    /// La vista previa sigue al recorte: al mover una manija se ve ese frame y al reproducir solo se ve lo seleccionado.
    private func withTrimHandlers<V: View>(_ view: V) -> some View {
        view
        .onChange(of: enhanceVM.trimStart) { _, _ in
            enhanceTrimSync.update(start: enhanceVM.trimStart, end: enhanceVM.trimEnd, duration: enhanceVM.videoDuration)
        }
        .onChange(of: enhanceVM.trimEnd) { _, _ in
            enhanceTrimSync.update(start: enhanceVM.trimStart, end: enhanceVM.trimEnd, duration: enhanceVM.videoDuration)
        }
    }

    private func withSheets<V: View>(_ view: V) -> some View {
        view
        .sheet(isPresented: $showPresets) {
            PresetsSheet(current: { makeCurrentPreset(name: $0) }, apply: { applyPreset($0) })
        }
        .sheet(isPresented: $showSettings) {
            SettingsView(keepURLs: urlsToKeep, isBusy: anythingBusy)
        }
        .sheet(isPresented: $showMoreTools) {
            MoreToolsSheet(items: moreToolItems, current: tab) { tab = $0 }
        }
        .sheet(isPresented: $access.showPaywall) { PaywallView() }
        .confirmationDialog(
            tr("Límite diario de video", "Daily video limit"),
            isPresented: Binding(get: { quotaPrompt != nil }, set: { if !$0 { quotaPrompt = nil } }),
            titleVisibility: .visible,
            presenting: quotaPrompt
        ) { prompt in
            Button(tr("Procesar los primeros \(prompt.remaining) s", "Process the first \(prompt.remaining) s")) { enhanceVM.start() }
            Button(tr("Quitar límites con Pro", "Remove limits with Pro")) { access.requestPaywall(reason: nil) }
            Button(tr("Cancelar", "Cancel"), role: .cancel) {}
        } message: { prompt in
            Text(tr("Tu video dura \(prompt.selected) s y hoy te quedan \(prompt.remaining) s.",
                    "Your video is \(prompt.selected) s long and you have \(prompt.remaining) s left today."))
        }
        .alert(
            tr("Preset aplicado", "Preset applied"),
            isPresented: Binding(get: { presetNotice != nil }, set: { if !$0 { presetNotice = nil } })
        ) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(presetNotice ?? "")
        }
    }

    /// Sin Pro, lo que era de pago vuelve a su equivalente gratis (p. ej. al vencer la suscripción).
    private func enforceFreeSelections() {
        if !enhanceVM.isProcessing && !enhanceVM.isBatchRunning { enhanceVM.useFreeOptions() }
        if !imageVM.isBusy && access.isLocked(imageModel: imageVM.selectedModel) { imageVM.selectedModel = .general }
    }

    /// Iniciar el video: sin Pro, si es más largo que los segundos de hoy se ofrece procesar solo el principio.
    private func startEnhance() {
        guard !access.isPro, enhanceVM.mode != nil, enhanceVM.inputURL != nil,
              !enhanceVM.usesProOptions else { enhanceVM.start(); return }
        let remaining = UsageQuota.shared.remainingVideoSeconds
        let selected = enhanceVM.selectedSeconds
        if remaining >= 1, selected > remaining + 0.05 {
            quotaPrompt = VideoQuotaPrompt(selected: Int(selected.rounded(.up)), remaining: Int(remaining.rounded(.down)))
        } else {
            enhanceVM.start()   // si no queda cuota u hay opciones Pro, start() explica el motivo y abre la suscripción
        }
    }

    /// Un preset guarda la configuración de todas las pestañas.
    private func makeCurrentPreset(name: String) -> Preset {
        Preset(name: name,
               enhance: enhanceVM.makeSection(),
               image: ImageSection(modelRaw: imageVM.selectedModel.rawValue, cleanup: imageVM.cleanupStrength),
               color: colorVM.settings)
    }

    private func applyPreset(_ preset: Preset) {
        guard !anythingBusy else { return }
        var replacedProOptions = false
        if let section = preset.enhance {
            enhanceVM.apply(section)
            // Un preset con opciones Pro sin suscripción: se cambian por las gratuitas y no queda ninguna de pago.
            if !access.isPro && enhanceVM.usesProOptions { enhanceVM.useFreeOptions(); replacedProOptions = true }
        }
        if let image = preset.image,
           let model = RealESRGAN.Model(rawValue: image.modelRaw),
           RealESRGAN.Model.imageModels.contains(model) {
            if access.isLocked(imageModel: model) {
                imageVM.selectedModel = .general
                replacedProOptions = true
            } else {
                imageVM.selectedModel = model
            }
            let saved = image.cleanup ?? RealESRGAN.defaultCleanup
            imageVM.cleanupStrength = RealESRGAN.cleanupSteps.contains(saved) ? saved : RealESRGAN.defaultCleanup
        }
        if let color = preset.color { colorVM.settings = color }
        if replacedProOptions {
            presetNotice = tr("Algunas opciones Pro se cambiaron por las gratuitas.", "Some Pro options were replaced with the free ones.")
        }
    }

    private var urlsToKeep: [URL] {
        var urls: [URL] = []
        urls += [enhanceVM.inputURL, enhanceVM.outputURL].compactMap { $0 }
        urls += enhanceVM.batchResults
        urls += imageVM.batchResults
        urls += backgroundVM.batchResults
        if let colorURL = colorVM.outputURL { urls.append(colorURL) }
        return urls
    }

    private var anythingBusy: Bool {
        let enhance: Bool = enhanceVM.isProcessing || enhanceVM.isBatchRunning
        let image: Bool = imageVM.isBusy
        let background: Bool = backgroundVM.isBusy
        let color: Bool = colorVM.isExporting
        return enhance || image || background || color
    }

    private var tabs: some View {
        VStack(spacing: 6) {
            HStack(spacing: 6) {
                presetsButton
                Spacer()
                headerCircleButton(icon: "gearshape.fill", label: tr("Ajustes", "Settings"), disabled: false) { showSettings = true }
            }
            HStack(spacing: 4) {
                tabButton(.enhance, height: 44, icon: "wand.and.stars", fontSize: 13)
                moreToolsButton
            }
        }
        .padding(4)
        .background(Theme.fill(0.045), in: RoundedRectangle(cornerRadius: 13))
    }

    private var moreToolItems: [MoreToolsSheet.Item] {
        let tools: [Tab] = [.image, .background, .color]
        return tools.map { MoreToolsSheet.Item(tab: $0, icon: toolIcon($0), title: toolTitle($0), detail: toolDetail($0)) }
    }

    private func toolIcon(_ tab: Tab) -> String {
        switch tab {
        case .enhance: return "wand.and.stars"
        case .image: return "photo"
        case .background: return "person.crop.rectangle"
        case .color: return "slider.horizontal.below.rectangle"
        }
    }

    private func toolTitle(_ tab: Tab) -> String {
        switch tab {
        case .enhance: return tr("Mejora de video", "Video enhance")
        case .image: return tr("Mejorar imagen", "Enhance image")
        case .background: return tr("Eliminar fondo", "Remove background")
        case .color: return tr("Ajustar color", "Adjust color")
        }
    }

    private func toolDetail(_ tab: Tab) -> String {
        switch tab {
        case .enhance: return tr("Más calidad y más fps en tus videos", "More quality and more fps in your videos")
        case .image: return tr("Mejora la calidad de tus fotos", "Improve the quality of your photos")
        case .background: return tr("Deja solo al sujeto, con fondo transparente", "Keep only the subject, on a transparent background")
        case .color: return tr("Estilos y ajustes para fotos y videos", "Looks and adjustments for photos and videos")
        }
    }

    /// Segundo botón de la barra: abre la lista de herramientas. Si hay una activa, muestra su nombre.
    private var moreToolsButton: some View {
        let active = tab != .enhance
        return Button { Haptics.tap(); showMoreTools = true } label: {
            HStack(spacing: 6) {
                if active { Image(systemName: toolIcon(tab)).font(.system(size: 13, weight: .bold)) }
                Text(active ? toolTitle(tab).uppercased() : tr("MÁS HERRAMIENTAS", "MORE TOOLS"))
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .tracking(0.5)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.7)
                    .lineLimit(2)
                Image(systemName: "chevron.down").font(.system(size: 10, weight: .bold)).opacity(0.7)
            }
            .foregroundStyle(active ? Theme.onAccent : Theme.ink().opacity(0.55))
            .frame(height: 44)
            .frame(maxWidth: .infinity)
            .background(active ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.clear), in: RoundedRectangle(cornerRadius: 10))
            .shadow(color: active ? LocalStyle.mint.opacity(0.45) : Color.clear, radius: 10)
        }
        .buttonStyle(PressableStyle())
    }

    /// Botón de presets con su nombre: cápsula tenue con borde, igual que el estilo de los botones de la cabecera.
    private var presetsButton: some View {
        Button { showPresets = true } label: {
            HStack(spacing: 6) {
                Text(tr("Presets", "Presets"))
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Image(systemName: "slider.horizontal.3").font(.system(size: 12, weight: .semibold))
            }
            .foregroundStyle(LocalStyle.mint)
            .padding(.horizontal, 12)
            .frame(height: 30)
            .background(Theme.fill(0.055), in: Capsule())
            .overlay(Capsule().stroke(LocalStyle.mint.opacity(0.35), lineWidth: 1))
        }
        .disabled(anythingBusy)
        .opacity(anythingBusy ? 0.45 : 1)
    }

    private func headerCircleButton(icon: String, label: String, disabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(LocalStyle.mint)
                .frame(width: 30, height: 30)
                .background(Theme.fill(0.055), in: Circle())
                .overlay(Circle().stroke(LocalStyle.mint.opacity(0.35), lineWidth: 1))
        }
        .accessibilityLabel(label)
        .disabled(disabled)
        .opacity(disabled ? 0.45 : 1)
    }

    private func tabButton(_ value: Tab, height: CGFloat = 38, icon: String? = nil, fontSize: CGFloat = 11) -> some View {
        Button { Haptics.tap(); tab = value } label: {
            HStack(spacing: 6) {
                if let icon { Image(systemName: icon).font(.system(size: fontSize, weight: .bold)) }
                Text(title(for: value))
                    .font(.system(size: fontSize, weight: .bold, design: .rounded))
                    .tracking(0.5)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.7)
                    .lineLimit(2)
            }
            .foregroundStyle(tab == value ? Theme.onAccent : Theme.ink().opacity(0.55))
            .frame(height: height)
            .frame(maxWidth: .infinity)
            .background(tab == value ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.clear), in: RoundedRectangle(cornerRadius: 10))
            .shadow(color: tab == value ? LocalStyle.mint.opacity(0.45) : Color.clear, radius: 10)
        }
        .buttonStyle(PressableStyle())
    }

    private let blockGap: CGFloat = 16   // espacio ENTRE bloques de una pestaña
    private let innerGap: CGFloat = 8    // espacio DENTRO de un bloque

    /// Título pequeño en mayúsculas de una sección (mismo estilo que «MODELO» y «ELEGIR TU PLAN» en la suscripción).
    private func sectionTitle(_ text: String) -> some View {
        Text(text.uppercased())
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .tracking(1)
            .foregroundStyle(Theme.ink(0.45))
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    /// Tarjeta que agrupa opciones relacionadas (fondo tenue, esquinas 14).
    private func optionCard<Content: View>(spacing: CGFloat = 8, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: spacing) { content() }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
    }

    /// Línea de estado bajo el botón principal: tenue, pequeña y alineada a la izquierda en todas las pestañas.
    private func statusLine(_ text: String) -> some View {
        Text(text)
            .font(.caption2)
            .foregroundStyle(Theme.ink(0.4))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 4)
    }

    /// Tarjeta «MODELO» con los botones de modelo, su descripción y, solo para General, la intensidad de limpieza.
    private func modelOptionsCard(models: [RealESRGAN.Model], topRowCount: Int, selected: RealESRGAN.Model, cleanup: Binding<Int>,
                                  busy: Bool, isLocked: @escaping (RealESRGAN.Model) -> Bool,
                                  onSelect: @escaping (RealESRGAN.Model) -> Void) -> some View {
        optionCard(spacing: 12) {
            modelSelector(models: models, topRowCount: topRowCount, selected: selected, isLocked: isLocked, onSelect: onSelect)
            if selected == .general, RealESRGAN.cleanupAvailable {
                Divider().overlay(Theme.ink(0.1))
                cleanupRow(value: cleanup)
            }
        }
        .disabled(busy)
    }

    /// Los modelos se reparten en dos filas: la primera con `topRowCount` botones y el resto debajo.
    /// Todos los botones de una pestaña comparten el mismo ancho (la fila de abajo deja huecos vacíos si hace falta).
    private func modelSelector(models: [RealESRGAN.Model], topRowCount: Int = 2, selected: RealESRGAN.Model,
                               isLocked: @escaping (RealESRGAN.Model) -> Bool, onSelect: @escaping (RealESRGAN.Model) -> Void) -> some View {
        let topRow = Array(models.prefix(topRowCount))
        let bottomRow = Array(models.dropFirst(topRowCount))
        return VStack(alignment: .leading, spacing: innerGap) {
            sectionTitle(L.modelSectionTitle.text)
            VStack(spacing: 7) {
                modelRow(topRow, slots: topRowCount, selected: selected, isLocked: isLocked, onSelect: onSelect)
                if !bottomRow.isEmpty {
                    modelRow(bottomRow, slots: topRowCount, selected: selected, isLocked: isLocked, onSelect: onSelect)
                }
            }
            if models.contains(selected) {
                Text(selected.blurb)
                    .font(.caption2)
                    .foregroundStyle(Theme.ink(0.45))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private func modelRow(_ row: [RealESRGAN.Model], slots: Int, selected: RealESRGAN.Model,
                          isLocked: @escaping (RealESRGAN.Model) -> Bool, onSelect: @escaping (RealESRGAN.Model) -> Void) -> some View {
        HStack(spacing: 7) {
            ForEach(row) { model in
                Button {
                    if isLocked(model) { access.requestPaywall(reason: ProAccess.proOptionReason) } else { Haptics.tap(); onSelect(model) }
                } label: {
                    VStack(spacing: 3) {
                        Text(model.shortName)
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        HStack(spacing: 3) {
                            Image(systemName: "iphone").font(.system(size: 8, weight: .bold))
                            Text(model.caption)
                                .font(.system(size: 9, weight: .medium, design: .rounded))
                                .lineLimit(1)
                        }
                        .opacity(selected == model ? 0.75 : 0.55)
                    }
                    .foregroundStyle(selected == model ? Theme.onAccent : Theme.ink())
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(selected == model ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Theme.fill(0.055)), in: RoundedRectangle(cornerRadius: 12))
                    .shadow(color: selected == model ? LocalStyle.mint.opacity(0.4) : Color.clear, radius: 9)
                    .overlay(alignment: .topTrailing) {
                        if isLocked(model) { ProBadge(compact: true).padding(4) }
                    }
                    .animation(.spring(response: 0.3, dampingFraction: 0.75), value: selected == model)
                }
                .buttonStyle(PressableStyle())
            }
            ForEach(0..<max(slots - row.count, 0), id: \.self) { _ in
                Color.clear.frame(maxWidth: .infinity).frame(height: 52)
            }
        }
    }

    // MARK: - Mejora de video
    @ViewBuilder
    private func enhanceView(geometry: GeometryProxy) -> some View {
        let busy = enhanceVM.isProcessing || enhanceVM.isBatchRunning
        // Resultado listo: solo quedan la preview, Guardar/Compartir y el selector para elegir otro video.
        let showingResult = enhanceVM.outputURL != nil && !busy

        VStack(spacing: blockGap) {
            enhancePreview
                .adaptivePreview(aspect: enhanceAspect, maxHeight: max(geometry.size.height * 0.52, 320))

            // El aviso de límites diarios va justo debajo de la preview, antes de todas las opciones.
            if !access.isPro && !busy && !showingResult { QuotaBanner(kind: .video) }

            if let pending = enhanceVM.pendingJob, !busy, !showingResult {
                pendingJobCard(pending)
            }

            if showingResult {
                enhanceResult
            } else if !busy {
                // Mientras se procesa solo quedan la preview y el bloque de progreso/cancelar.
                if let url = enhanceVM.inputURL, enhanceVM.videoDuration > 0 {
                    TrimBar(url: url, duration: enhanceVM.videoDuration, start: $enhanceVM.trimStart, end: $enhanceVM.trimEnd,
                            disabled: busy)
                }

                enhanceModeMenu(busy: busy)

                // Hasta que no elija qué hacer, no se muestra ninguna opción.
                if enhanceVM.doUpscale {
                    upscaleOptionsCard(busy: busy)
                }
                if enhanceVM.doInterpolate {
                    fpsOptionsCard(busy: busy)
                }
                if enhanceVM.mode != nil {
                    enhanceAdvancedCard(busy: busy)
                }
            }

            // Zona de acción: elegir video (y lote), botón principal y línea de estado.
            VStack(spacing: innerGap) {
                if !busy {
                    HStack(spacing: 8) {
                        PhotosPicker(selection: $selectedVideo, matching: .videos, photoLibrary: .shared()) {
                            pickerButton(title: L.selectVideo.text, icon: "video.badge.plus")
                        }
                        if !showingResult {
                            batchCompactPicker(selection: $batchEnhanceItems, maxCount: 20, matching: .videos, busy: busy)
                        }
                    }
                }

                if !showingResult {
                    if enhanceVM.batchTotal > 0 {
                        BatchSummary(isRunning: enhanceVM.isBatchRunning, index: enhanceVM.batchIndex, total: enhanceVM.batchTotal,
                                     failures: enhanceVM.batchFailures, results: enhanceVM.batchResults)
                    }

                    if busy {
                        enhanceProcessingSection
                    } else {
                        // El botón principal aparece cuando ya hay un video elegido.
                        if enhanceVM.inputURL != nil {
                            Button { startEnhance() } label: {
                                startButtonLabel(title: enhanceStartTitle, subtitle: enhanceVM.resultSummary)
                            }
                            .buttonStyle(PressableStyle())
                            .disabled(!enhanceCanStart)
                            .opacity(enhanceCanStart ? 1 : 0.45)
                            .transition(.scale(scale: 0.94).combined(with: .opacity))
                        }

                        // Sin video elegido no se muestra el aviso «Selecciona un video».
                        if !isTr(enhanceVM.status, "Selecciona un video", "Select a video") {
                            statusLine(enhanceVM.status)
                        }
                    }
                }
            }
            .animation(.spring(response: 0.4, dampingFraction: 0.8), value: enhanceVM.inputURL != nil)
        }
    }

    private var enhanceCanStart: Bool {
        enhanceVM.inputURL != nil && enhanceVM.mode != nil && !enhanceVM.isTooLarge
    }

    private var enhanceStartTitle: String {
        switch enhanceVM.mode {
        case .none: return tr("Elige qué hacer", "Choose what to do")
        case .some(.both): return tr("Mejorar + aumentar fps", "Enhance + raise fps")
        case .some(.quality): return tr("Mejorar calidad", "Improve quality")
        case .some(.fps): return tr("Aumentar fps", "Raise fps") + (enhanceVM.activeFixedFps.map { " · \($0) fps" } ?? " ×\(enhanceVM.factor)")
        }
    }

    /// Botón principal con la línea "Resultado: …" pegada debajo del título: se ve justo donde se decide empezar
    /// y no ocupa una fila extra.
    private func startButtonLabel(title: String, subtitle: String?) -> some View {
        VStack(spacing: 2) {
            Text(title).font(.headline.weight(.bold))
            if let subtitle {
                Text(subtitle)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                    .opacity(0.88)
            }
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity)
        .frame(height: subtitle == nil ? 50 : 58)
        .background(Color(red: 0.12, green: 0.47, blue: 1), in: RoundedRectangle(cornerRadius: 13))
    }

    /// Un solo botón de ancho completo con menú desplegable (flecha a la derecha).
    /// Al entrar no hay nada elegido: primero se escoge qué hacer y solo entonces aparecen las opciones.
    private func enhanceModeMenu(busy: Bool) -> some View {
        let current = enhanceVM.mode
        let isOn = current != nil
        // Mientras no hay nada elegido el botón invita a abrir el menú; con una opción elegida muestra su nombre.
        let icon = current?.icon ?? "hand.tap"
        let label = current?.title ?? tr("Elige qué hacer", "Choose what to do")
        return Menu {
            ForEach(EnhanceMode.allCases) { option in
                Button {
                    withAnimation { enhanceVM.mode = option }
                } label: {
                    Label(option.title, systemImage: current == option ? "checkmark" : option.icon)
                }
            }
        } label: {
            HStack(spacing: 10) {
                Image(systemName: icon).font(.system(size: 16, weight: .bold))
                Text(label)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .lineLimit(1)
                    .minimumScaleFactor(0.65)
                Spacer(minLength: 8)
                Image(systemName: "chevron.down").font(.system(size: 13, weight: .bold))
            }
            .foregroundStyle(isOn ? Theme.onAccent : Theme.ink())
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .background(isOn ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Theme.fill(0.055)), in: RoundedRectangle(cornerRadius: 12))
            .shadow(color: isOn ? LocalStyle.mint.opacity(0.4) : Color.clear, radius: 9)
        }
        .menuOrder(.fixed)
        .disabled(busy)
    }

    /// Opciones de "Mejorar calidad": el modelo.
    private func upscaleOptionsCard(busy: Bool) -> some View {
        modelOptionsCard(models: RealESRGAN.Model.videoModels, topRowCount: 2, selected: enhanceVM.selectedModel,
                         cleanup: $enhanceVM.cleanupStrength, busy: busy,
                         isLocked: { access.isLocked(videoModel: $0) }) { enhanceVM.selectedModel = $0 }
    }

    /// "Intensidad de limpieza": solo para el modelo General. 100 % limpia más el ruido; 0 % conserva más textura.
    private func cleanupRow(value: Binding<Int>) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(tr("Intensidad de limpieza", "Cleanup strength"))
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(Theme.ink())
                Spacer()
                Text("\(value.wrappedValue)%")
                    .font(.system(size: 13, weight: .bold, design: .rounded)).monospacedDigit()
                    .foregroundStyle(LocalStyle.mint)
            }
            Slider(
                value: Binding(
                    get: { Double(value.wrappedValue) },
                    set: { value.wrappedValue = min(max(Int(($0 / 25).rounded()) * 25, 0), 100) }
                ),
                in: 0...100, step: 25
            )
            .tint(LocalStyle.mint)
            .accessibilityLabel(tr("Intensidad de limpieza", "Cleanup strength"))
            .accessibilityValue("\(value.wrappedValue)%")
        }
    }

    /// Selector "Multiplicador | Salida fija" (a la derecha del título del factor).
    private var fpsModePicker: some View {
        HStack(spacing: 2) {
            ForEach([EnhanceViewModel.FpsMode.multiplier, .fixed], id: \.self) { mode in
                let enabled = mode == .multiplier || enhanceVM.fixedAvailable
                let selected = enhanceVM.fpsMode == mode
                let proLocked = mode == .fixed && access.fixedFpsLocked
                Button {
                    if proLocked { access.requestPaywall(reason: ProAccess.proOptionReason) } else { enhanceVM.fpsMode = mode }
                } label: {
                    HStack(spacing: 4) {
                        Text(mode == .multiplier ? L.interpolateModeMultiplier.text : L.interpolateModeFixed.text)
                            .font(.system(size: 11, weight: .semibold, design: .rounded))
                            .lineLimit(1).minimumScaleFactor(0.7)
                            .foregroundStyle(selected ? Theme.onAccent : Theme.ink(enabled ? 0.8 : 0.35))
                        if proLocked { ProBadge(compact: true) }
                    }
                    .padding(.horizontal, 9).padding(.vertical, 5)
                    .background(selected ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.clear), in: Capsule())
                }
                .disabled(!enabled)
            }
        }
        .padding(2)
        .background(Theme.fill(0.055), in: Capsule())
        .fixedSize()
    }

    private func fpsOptionButton(title: String, caption: String, selected: Bool, proLocked: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 2) {
                Text(title).font(.system(size: 15, weight: .bold, design: .rounded))
                HStack(spacing: 3) {
                    Image(systemName: "iphone").font(.system(size: 8, weight: .bold))
                    Text(caption).font(.system(size: 9, weight: .medium, design: .rounded))
                }
                .opacity(selected ? 0.75 : 0.55)
            }
            .foregroundStyle(selected ? Theme.onAccent : Theme.ink())
            .frame(maxWidth: .infinity)
            .frame(height: 52)
            .background(selected ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Theme.fill(0.055)), in: RoundedRectangle(cornerRadius: 12))
            .shadow(color: selected ? LocalStyle.mint.opacity(0.4) : Color.clear, radius: 9)
            .overlay(alignment: .topTrailing) {
                if proLocked { ProBadge(compact: true).padding(4) }
            }
        }
    }

    /// Opciones de "Aumentar fps": factor, precisión y cámara lenta.
    private func fpsOptionsCard(busy: Bool) -> some View {
        VStack(alignment: .leading, spacing: innerGap) {
            VStack(alignment: .leading, spacing: innerGap) {
                HStack(spacing: 8) {
                    Text(L.interpolateFactorTitle.text)
                        .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
                        .lineLimit(1).minimumScaleFactor(0.6)
                    Spacer(minLength: 4)
                    fpsModePicker
                }
                HStack(spacing: 7) {
                    if enhanceVM.fpsMode == .fixed {
                        ForEach(EnhanceViewModel.fixedTargets, id: \.self) { value in
                            let reachable = enhanceVM.canReach(value)
                            fpsOptionButton(title: "\(value) fps",
                                            caption: reachable ? (value == 60 ? L.interpolateFactorFast.text : L.interpolateFactorSmooth.text) : tr("no necesario", "not needed"),
                                            selected: enhanceVM.fixedTarget == value && reachable) {
                                enhanceVM.fixedTarget = value
                            }
                            .disabled(!reachable)
                            .opacity(reachable ? 1 : 0.4)
                        }
                    } else {
                        ForEach([2, 4], id: \.self) { value in
                            fpsOptionButton(title: "×\(value)",
                                            caption: value == 2 ? L.interpolateFactorFast.text : L.interpolateFactorSmooth.text,
                                            selected: enhanceVM.factor == value,
                                            proLocked: access.isLocked(factor: value)) {
                                if access.isLocked(factor: value) {
                                    access.requestPaywall(reason: ProAccess.proOptionReason)
                                } else {
                                    enhanceVM.factor = value
                                }
                            }
                        }
                    }
                }
                if enhanceVM.fpsMode == .fixed {
                    Text(tr("Exporta a \(enhanceVM.fixedTarget) fps sin importar los fps del video original.",
                            "Exports at \(enhanceVM.fixedTarget) fps whatever the original video's fps."))
                        .font(.caption2).foregroundStyle(Theme.ink(0.45))
                }
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
        .disabled(busy)
    }

    /// Ajustes que casi nunca hace falta tocar: precisión, cámara lenta, HDR y resolución final (siempre la última).
    private func enhanceAdvancedCard(busy: Bool) -> some View {
        AdvancedDisclosure(icon: "slider.horizontal.3", isExpanded: $showEnhanceAdvanced, isModified: enhanceAdvancedModified) {
            if enhanceVM.doInterpolate {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(L.precisionTitle.text).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
                    Text(enhanceVM.precision.caption.isEmpty ? enhanceVM.precision.displayName : L.precisionHigh.text + " · " + enhanceVM.precision.caption)
                        .font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(Theme.ink(0.8))
                }
                Spacer()
                Picker("", selection: Binding(
                    get: { enhanceVM.precision },
                    set: { newValue in
                        if access.isLocked(precision: newValue) {
                            access.requestPaywall(reason: ProAccess.proOptionReason)
                        } else {
                            enhanceVM.precision = newValue
                        }
                    }
                )) {
                    ForEach(RIFEInterpolator.Precision.allCases) { option in
                        Text(precisionLabel(option)).tag(option)
                    }
                }
                .pickerStyle(.segmented)
                .frame(width: access.isPro ? 150 : 185)
            }

            if enhanceVM.activeFixedFps == nil && access.slowMotionLocked {
                LockedSettingRow(title: tr("Cámara lenta", "Slow motion"),
                                 detail: tr("Mantiene la duración y sube los fps", "Keeps the duration and raises the fps"),
                                 reason: ProAccess.proOptionReason)
            } else if enhanceVM.activeFixedFps == nil {
            Toggle(isOn: $enhanceVM.slowMotion) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(tr("Cámara lenta", "Slow motion")).font(.system(size: 14, weight: .semibold, design: .rounded))
                    Text(enhanceVM.slowMotion
                         ? tr("El video dura ×\(enhanceVM.factor) más", "The video lasts ×\(enhanceVM.factor) longer")
                         : tr("Mantiene la duración y sube los fps", "Keeps the duration and raises the fps"))
                        .font(.caption2).foregroundStyle(Theme.ink(0.45))
                }
            }
            .tint(LocalStyle.mint)
            }
            }
        if access.hdrLocked {
            LockedSettingRow(title: tr("Conservar HDR", "Keep HDR"),
                             detail: tr("Exporta en HDR si el video original lo es", "Exports in HDR if the original video is"),
                             reason: ProAccess.proOptionReason)
        } else {
            Toggle(isOn: $enhanceVM.keepHDR) {
                Text(tr("Conservar HDR", "Keep HDR")).font(.system(size: 14, weight: .semibold, design: .rounded))
            }
            .tint(LocalStyle.mint)
        }
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(tr("RESOLUCIÓN DE EXPORTACIÓN", "EXPORT RESOLUTION"))
                    .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
            }
            Spacer()
            Picker("", selection: $enhanceVM.exportQuality) {
                ForEach(ExportQuality.allCases) { option in
                    Text(option.label).tag(option)
                }
            }
            .pickerStyle(.menu)
            .tint(LocalStyle.mint)
            .disabled(busy)
        }
        }
        .disabled(busy)
    }

    private func precisionLabel(_ option: RIFEInterpolator.Precision) -> String {
        if option == .fp16 { return L.precisionFast.text }
        return (access.isLocked(precision: option) ? "✦ " : "") + L.precisionHigh.text
    }

    private var enhanceAdvancedModified: Bool {
        (enhanceVM.doInterpolate && (enhanceVM.precision != .fp16 || (enhanceVM.slowMotion && enhanceVM.activeFixedFps == nil))) || enhanceVM.exportQuality != .automatic || enhanceVM.keepHDR
    }

    /// Recuadro vacío de las vistas previas (igual en todas las pestañas).
    private func emptyPlaceholder(icon: String, title: String) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon).font(.system(size: 30)).foregroundStyle(.white.opacity(0.3))
            Text(title).font(.headline).foregroundStyle(.white.opacity(0.85))
            Text(L.deviceOnlyNote.text).font(.caption).foregroundStyle(.white.opacity(0.35))
        }
    }

    /// Forma (ancho / alto) del video elegido, para que la vista previa se ajuste si es más pequeño que ella.
    private var enhanceAspect: CGFloat? {
        enhanceVM.sourceWidth > 0 && enhanceVM.sourceHeight > 0
            ? CGFloat(enhanceVM.sourceWidth) / CGFloat(enhanceVM.sourceHeight) : nil
    }

    private var colorAspect: CGFloat? {
        switch colorVM.media {
        case .image: return colorVM.previewImage?.aspectRatio
        case .video: return colorVM.videoAspect
        case .none: return nil
        }
    }

    private var enhancePreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let frame = enhanceVM.liveFrame, enhanceVM.isProcessing {
                Image(decorative: frame, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
            } else if let input = enhanceVM.inputURL, let output = enhanceVM.outputURL {
                VideoCompareView(beforeURL: input, afterURL: output, beforeStart: enhanceVM.resultTrimStart, slowFactor: enhanceVM.resultSlowFactor).id(output)
            } else if let player = enhancePlayer {
                ZoomableVideoPreview(player: player, trimStart: enhanceVM.trimStart, trimEnd: enhanceVM.trimEnd).id(ObjectIdentifier(player))
            } else {
                emptyPlaceholder(icon: "film", title: L.selectVideoPlaceholderTitle.text)
            }
        }
        .animation(.easeInOut(duration: 0.3), value: enhanceVM.inputURL)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.fill(0.1)))
    }

    private var enhanceProcessingSection: some View {
        VStack(spacing: innerGap) {
            ProgressView(value: enhanceVM.progress).tint(Color(red: 0.25, green: 0.58, blue: 1)).progressShimmer()
            HStack {
                Text(enhanceVM.status).lineLimit(1)
                Spacer()
                ETALabel(progress: enhanceVM.progress)
            }
            .font(.caption.weight(.medium)).foregroundStyle(Theme.ink(0.55))

            Button { enhanceVM.cancel() } label: { secondaryButton(L.cancelButton.text, color: Color(red: 0.75, green: 0.08, blue: 0.12)) }
        }
    }

    /// Aviso de un video que quedó a medias (la app se cerró): se puede continuar o descartar.
    private func pendingJobCard(_ job: ResumeJob) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "arrow.clockwise.circle.fill").foregroundStyle(LocalStyle.mint)
                Text(tr("Tienes un video a medias", "You have an unfinished video"))
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundStyle(Theme.ink())
            }
            Text(tr("\(job.doneSegments)/\(job.segmentCount) partes listas", "\(job.doneSegments)/\(job.segmentCount) parts done"))
                .font(.system(size: 12, weight: .medium, design: .rounded))
                .foregroundStyle(Theme.ink(0.6))
            HStack(spacing: 8) {
                Button { enhanceVM.resumePending() } label: { primaryButton(tr("Reanudar", "Resume")) }
                Button { enhanceVM.discardPending() } label: { secondaryButton(tr("Descartar", "Discard"), color: Theme.ink(0.5)) }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(LocalStyle.mint.opacity(0.35), lineWidth: 1))
    }

    private var enhanceResult: some View {
        Group {
            if let output = enhanceVM.outputURL {
                ResultActionBar(save: { try await PhotoSaver.saveVideo(at: output) },
                                share: ShareLink(item: output) { ShareBarLabel() },
                                exportURLs: [output])
                    .id(output)
            }
        }
    }
    @ViewBuilder
    private func imageView(geometry: GeometryProxy) -> some View {
        // Resultado listo: solo quedan la preview, Guardar/Compartir y el selector para elegir otra imagen.
        let showingResult = imageVM.outputImage != nil && !imageVM.isBusy

        VStack(spacing: blockGap) {
            imagePreview
                .adaptivePreview(aspect: imageVM.inputImage?.aspectRatio, maxHeight: max(geometry.size.height * 0.52, 320))

            if !access.isPro && !imageVM.isBusy && !showingResult { QuotaBanner(kind: .photos) }

            if showingResult, let output = imageVM.outputImage {
                ResultActionBar(
                    save: { try await PhotoSaver.saveImage(output) },
                    share: ShareLink(item: ShareableImage(image: output), preview: SharePreview("Astral", image: Image(decorative: output, scale: 1))) { ShareBarLabel() }
                )
                .id(ObjectIdentifier(output))
            } else if !imageVM.isBusy {
                modelOptionsCard(models: RealESRGAN.Model.imageModels, topRowCount: 3, selected: imageVM.selectedModel,
                                 cleanup: $imageVM.cleanupStrength, busy: imageVM.isBusy,
                                 isLocked: { access.isLocked(imageModel: $0) }) { imageVM.selectedModel = $0 }
            }

            // Zona de acción: elegir imagen (y lote), botón principal y línea de estado.
            VStack(spacing: innerGap) {
                if !imageVM.isBusy {
                    HStack(spacing: 8) {
                        PhotosPicker(selection: $selectedImage, matching: .images, photoLibrary: .shared()) {
                            pickerButton(title: L.selectImage.text, icon: "photo.badge.plus")
                        }
                        if !showingResult {
                            batchCompactPicker(selection: $batchImageItems, maxCount: 50, matching: .images, busy: imageVM.isBusy)
                        }
                    }
                }

                if !showingResult {
                    if imageVM.batchTotal > 0 {
                        BatchSummary(isRunning: imageVM.isBatchRunning, index: imageVM.batchIndex, total: imageVM.batchTotal,
                                     failures: imageVM.batchFailures, results: imageVM.batchResults)
                    }

                    if imageVM.isBatchRunning {
                        Button { imageVM.cancelBatch() } label: {
                            secondaryButton(tr("Cancelar lote", "Cancel batch"), color: Color.red.opacity(0.35), icon: "xmark")
                        }
                    }

                    // El botón principal aparece cuando ya hay una imagen elegida.
                    if !imageVM.isBusy && imageVM.inputImage != nil {
                        Button { imageVM.start() } label: { primaryButton(tr("Mejorar imagen", "Enhance image")) }
                            .buttonStyle(PressableStyle())
                            .transition(.scale(scale: 0.94).combined(with: .opacity))
                    }

                    if imageVM.needsLargeConfirmation && !imageVM.isProcessing {
                        Button { imageVM.start(force: true) } label: {
                            secondaryButton(L.tryAnyway.text, color: Color.orange.opacity(0.35), icon: "exclamationmark.triangle")
                        }
                    }

                    if imageVM.isProcessing {
                        ProgressView().tint(Theme.ink())
                    }

                    if !imageVM.isBusy && !isTr(imageVM.status, "Selecciona una imagen", "Select an image") {
                        statusLine(imageVM.status)
                    }
                }
            }
            .animation(.spring(response: 0.4, dampingFraction: 0.8), value: imageVM.inputImage != nil)
        }
    }

    private var imagePreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let output = imageVM.outputImage, let before = imageVM.inputImage {
                ImageComparisonView(before: before, after: output)
            } else if let image = imageVM.inputImage {
                ZoomablePreview(resetToken: ObjectIdentifier(image).hashValue) {
                    Image(decorative: image, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
                }
            } else {
                emptyPlaceholder(icon: "photo", title: L.selectImagePlaceholderTitle.text)
            }
        }
        .animation(.easeInOut(duration: 0.3), value: imageVM.inputImage.map { ObjectIdentifier($0) })
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.fill(0.1)))
    }

    @ViewBuilder
    private func colorView(geometry: GeometryProxy) -> some View {
        colorPreview
            .adaptivePreview(aspect: colorAspect, maxHeight: max(geometry.size.height * 0.46, 300))

        if !colorVM.isExporting {
            PhotosPicker(selection: $selectedColorItem, matching: .any(of: [.images, .videos]), photoLibrary: .shared()) {
                pickerButton(title: tr("Elegir foto o video", "Choose photo or video"), icon: "photo.on.rectangle")
            }
        }

        // Video exportado: solo quedan Guardar/Compartir (elegir otro archivo vuelve a mostrar los ajustes).
        let colorExportDone = colorVM.media == .video && colorVM.outputURL != nil && !colorVM.isExporting

        if colorVM.hasMedia {
            if !colorExportDone && !colorVM.isExporting {
                colorLooksRow
                colorSlidersCard
            }

            if colorVM.media == .video {
                if colorVM.isExporting {
                    VStack(alignment: .leading, spacing: 8) {
                        ProgressView(value: colorVM.progress).tint(LocalStyle.mint)
                        Text(tr("Exportando…", "Exporting…") + " \(Int(colorVM.progress * 100))%")
                            .font(.caption).foregroundStyle(Theme.ink(0.6))
                    }
                } else if !colorExportDone {
                    Toggle(isOn: $colorVM.keepHDR) {
                        Text(tr("Conservar HDR", "Keep HDR")).font(.system(size: 14, weight: .semibold, design: .rounded))
                    }
                    .tint(LocalStyle.mint)
                    .foregroundStyle(Theme.ink())
                    Button { colorVM.exportVideo() } label: { primaryButton(tr("Exportar video", "Export video")) }
                        .disabled(colorVM.settings.isNeutral)
                        .opacity(colorVM.settings.isNeutral ? 0.45 : 1)
                }
                if let output = colorVM.outputURL, !colorVM.isExporting {
                    ResultActionBar(save: { try await PhotoSaver.saveVideo(at: output) },
                                    share: ShareLink(item: output) { ShareBarLabel() },
                                    exportURLs: [output])
                        .id(output)
                }
            } else if colorVM.media == .image, !colorVM.settings.isNeutral, let source = colorVM.sourceImage {
                ResultActionBar(
                    save: { try await PhotoSaver.saveImage(try await colorVM.renderedImage()) },
                    share: ShareLink(item: ShareableAdjustedImage(source: source, settings: colorVM.settings),
                                     preview: SharePreview("Astral", image: Image(decorative: source, scale: 1))) { ShareBarLabel() }
                )
            }
        }

        if !colorVM.isExporting && !colorExportDone
            && !isTr(colorVM.status, "Elige una foto o un video", "Choose a photo or a video") {
            Text(colorVM.status).font(.caption).foregroundStyle(Theme.ink(0.45)).frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var colorPreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            switch colorVM.media {
            case .image:
                if let image = colorVM.previewImage {
                    ZoomablePreview(resetToken: ObjectIdentifier(image).hashValue) {
                        Image(decorative: image, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
                    }
                }
            case .video:
                if let player = colorVM.player {
                    ZoomablePreview(resetToken: ObjectIdentifier(player).hashValue, onTap: { colorVM.togglePlay() }) {
                        PlayerLayerView(player: player).allowsHitTesting(false)
                    }
                    if !colorVM.isPlaying {
                        Image(systemName: "play.fill")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 58, height: 58)
                            .background(.black.opacity(0.45), in: Circle())
                            .allowsHitTesting(false)
                            .accessibilityHidden(true)
                    }
                }
            case .none:
                emptyPlaceholder(icon: "slider.horizontal.below.rectangle", title: tr("Ajuste de color", "Color adjustment"))
            }

            if colorVM.hasMedia {
                VStack {
                    HStack {
                        Text(tr("Mantén para ver el original", "Hold to see the original"))
                            .font(.system(size: 10, weight: .bold, design: .rounded))
                            .foregroundStyle(colorVM.showOriginal ? Theme.onAccent : .white)
                            .padding(.horizontal, 10).padding(.vertical, 6)
                            .background(colorVM.showOriginal ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Color.black.opacity(0.55)), in: Capsule())
                            .onLongPressGesture(minimumDuration: 0.01, maximumDistance: 60, pressing: { pressing in
                                colorVM.showOriginal = pressing
                            }, perform: {})
                        Spacer()
                        if colorVM.media == .video, colorVM.player != nil {
                            PlaybackSpeedMenu(speed: $colorVM.playbackSpeed)
                        }
                    }
                    .padding(10)
                    Spacer()
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.fill(0.1)))
    }

    private var colorLooksRow: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(tr("ESTILOS", "LOOKS"))
                .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 7) {
                    ForEach(ColorLook.allCases) { look in
                        let selected = colorVM.settings == look.settings
                        Button { colorVM.applyLook(look) } label: {
                            Text(look.title)
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundStyle(selected ? Theme.onAccent : Theme.ink())
                                .padding(.horizontal, 14).frame(height: 38)
                                .background(selected ? AnyShapeStyle(LocalStyle.gradient) : AnyShapeStyle(Theme.fill(0.055)), in: RoundedRectangle(cornerRadius: 11))
                        }
                    }
                }
            }
        }
        .disabled(colorVM.isExporting)
    }

    private var colorSlidersCard: some View {
        VStack(spacing: 12) {
            HStack {
                Text(tr("AJUSTES", "ADJUSTMENTS"))
                    .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(Theme.ink(0.45))
                Spacer()
                Button(tr("Restablecer", "Reset")) { colorVM.reset() }
                    .font(.caption.weight(.semibold)).foregroundStyle(LocalStyle.mint)
                    .disabled(colorVM.settings.isNeutral)
                    .opacity(colorVM.settings.isNeutral ? 0.4 : 1)
            }
            colorSlider(tr("Exposición", "Exposure"), $colorVM.settings.exposure, -2...2, neutral: 0)
            colorSlider(tr("Contraste", "Contrast"), $colorVM.settings.contrast, 0.6...1.6, neutral: 1)
            colorSlider(tr("Saturación", "Saturation"), $colorVM.settings.saturation, 0...2, neutral: 1)
            colorSlider(tr("Temperatura", "Temperature"), $colorVM.settings.temperature, -1...1, neutral: 0)

            AdvancedDisclosure(isExpanded: $showColorAdvanced, isModified: colorAdvancedModified, plain: true) {
                colorSlider(tr("Brillo", "Brightness"), $colorVM.settings.brightness, -0.3...0.3, neutral: 0)
                colorSlider(tr("Intensidad", "Vibrance"), $colorVM.settings.vibrance, -1...1, neutral: 0)
                colorSlider(tr("Matiz", "Tint"), $colorVM.settings.tint, -1...1, neutral: 0)
                colorSlider(tr("Luces altas", "Highlights"), $colorVM.settings.highlights, 0...1, neutral: 0)
                colorSlider(tr("Sombras", "Shadows"), $colorVM.settings.shadows, 0...1, neutral: 0)
                colorSlider(tr("Reducir ruido", "Noise reduction"), $colorVM.settings.denoise, 0...1, neutral: 0)
                colorSlider(tr("Nitidez", "Sharpness"), $colorVM.settings.sharpness, 0...1.5, neutral: 0)
                colorSlider(tr("Viñeta", "Vignette"), $colorVM.settings.vignette, 0...1, neutral: 0)
            }
        }
        .padding(12)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 13))
        .disabled(colorVM.isExporting)
    }

    private var colorAdvancedModified: Bool {
        let c = colorVM.settings
        return c.brightness != 0 || c.vibrance != 0 || c.tint != 0 || c.highlights != 0
            || c.shadows != 0 || c.denoise != 0 || c.sharpness != 0 || c.vignette != 0
    }

    private func colorSlider(_ title: String, _ value: Binding<Double>, _ range: ClosedRange<Double>, neutral: Double) -> some View {
        VStack(spacing: 3) {
            HStack {
                Text(title).font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(Theme.ink(0.85))
                Spacer()
                Text(String(format: "%+.2f", value.wrappedValue - neutral))
                    .font(.system(size: 11, weight: .medium, design: .rounded)).monospacedDigit()
                    .foregroundStyle(value.wrappedValue == neutral ? Theme.ink(0.35) : LocalStyle.mint)
            }
            Slider(value: value, in: range).tint(LocalStyle.mint)
        }
    }

    @ViewBuilder
    private func backgroundView(geometry: GeometryProxy) -> some View {
        // Resultado listo: solo quedan la preview, Guardar/Compartir y el selector para elegir otra imagen.
        let showingResult = backgroundVM.outputImage != nil && !backgroundVM.isBusy

        VStack(spacing: blockGap) {
            backgroundPreview
                .adaptivePreview(aspect: backgroundVM.inputImage?.aspectRatio, maxHeight: max(geometry.size.height * 0.52, 320))

            if !access.isPro && !backgroundVM.isBusy && !showingResult { QuotaBanner(kind: .background) }

            if showingResult, let output = backgroundVM.outputImage {
                ResultActionBar(
                    save: { try await PhotoSaver.saveImage(output) },
                    share: ShareLink(item: ShareableImage(image: output), preview: SharePreview("Astral", image: Image(decorative: output, scale: 1))) { ShareBarLabel() }
                )
                .id(ObjectIdentifier(output))
            }

            // Zona de acción: elegir imagen (y lote), botón principal y línea de estado.
            VStack(spacing: innerGap) {
                if !backgroundVM.isBusy {
                    HStack(spacing: 8) {
                        PhotosPicker(selection: $selectedBackgroundImage, matching: .images, photoLibrary: .shared()) {
                            pickerButton(title: L.selectImage.text, icon: "photo.badge.plus")
                        }
                        if !showingResult {
                            batchCompactPicker(selection: $batchBackgroundItems, maxCount: 50, matching: .images, busy: backgroundVM.isBusy)
                        }
                    }
                }

                if !showingResult {
                    if backgroundVM.batchTotal > 0 {
                        BatchSummary(isRunning: backgroundVM.isBatchRunning, index: backgroundVM.batchIndex, total: backgroundVM.batchTotal,
                                     failures: backgroundVM.batchFailures, results: backgroundVM.batchResults)
                    }

                    if backgroundVM.isBatchRunning {
                        Button { backgroundVM.cancelBatch() } label: {
                            secondaryButton(tr("Cancelar lote", "Cancel batch"), color: Color.red.opacity(0.35), icon: "xmark")
                        }
                    }

                    // El botón principal aparece cuando ya hay una imagen elegida.
                    if !backgroundVM.isBusy && backgroundVM.inputImage != nil {
                        Button { backgroundVM.start() } label: { primaryButton(tr("Quitar fondo", "Remove background")) }
                            .buttonStyle(PressableStyle())
                            .transition(.scale(scale: 0.94).combined(with: .opacity))
                    }

                    if backgroundVM.isProcessing {
                        ProgressView().tint(Theme.ink())
                    }

                    if !backgroundVM.isBusy && !isTr(backgroundVM.status, "Selecciona una imagen", "Select an image") {
                        statusLine(backgroundVM.status)
                    }
                }
            }
            .animation(.spring(response: 0.4, dampingFraction: 0.8), value: backgroundVM.inputImage != nil)
        }
    }

    private var backgroundPreview: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.05)
            if let output = backgroundVM.outputImage, let before = backgroundVM.inputImage {
                ImageComparisonView(before: before, after: output)
            } else if let image = backgroundVM.inputImage {
                ZoomablePreview(resetToken: ObjectIdentifier(image).hashValue) {
                    Image(decorative: image, scale: 1, orientation: .up).resizable().scaledToFit().padding(5)
                }
            } else {
                emptyPlaceholder(icon: "person.crop.rectangle", title: L.selectImagePlaceholderTitle.text)
            }
        }
        .animation(.easeInOut(duration: 0.3), value: backgroundVM.inputImage.map { ObjectIdentifier($0) })
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.fill(0.1)))
    }

    private func batchCompactPicker(selection: Binding<[PhotosPickerItem]>, maxCount: Int, matching: PHPickerFilter, busy: Bool) -> some View {
        PhotosPicker(selection: selection, maxSelectionCount: maxCount, matching: matching, photoLibrary: .shared()) {
            compactAction(tr("Procesar por lotes", "Batch process"), icon: "square.stack.3d.up")
        }
        .disabled(busy)
        .opacity(busy ? 0.45 : 1)
    }

    private func compactAction(_ title: String, icon: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 14, weight: .semibold))
            Text(title)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .lineLimit(1).minimumScaleFactor(0.75)
        }
        .foregroundStyle(Theme.ink())
        .frame(width: 148, height: 46)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private func pickerButton(title: String, icon: String) -> some View {
        HStack {
            Image(systemName: icon)
            Text(title).fontWeight(.semibold)
            Spacer()
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).opacity(0.4)
        }
        .foregroundStyle(Theme.ink())
        .frame(maxWidth: .infinity).frame(height: 46).padding(.horizontal, 16)
        .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 13))
    }

    private func primaryButton(_ title: String) -> some View {
        Text(title).font(.headline.weight(.bold)).foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 50).background(Color(red: 0.12, green: 0.47, blue: 1), in: RoundedRectangle(cornerRadius: 13))
    }

    private func secondaryButton(_ title: String, color: Color, icon: String? = nil) -> some View {
        HStack(spacing: 8) {
            if let icon { Image(systemName: icon) }
            Text(title).font(.subheadline.weight(.semibold))
        }
        .foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 48).background(color, in: RoundedRectangle(cornerRadius: 13))
    }
}
