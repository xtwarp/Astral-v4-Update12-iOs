import SwiftUI
import UIKit

/// Animaciones y vibraciones suaves de la interfaz. Todas respetan «Reducir movimiento» de iOS.

/// Vibraciones ligeras al tocar y al terminar un proceso.
enum Haptics {
    static func tap() { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
    static func success() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
}

/// Aparición con fundido, pequeño desplazamiento hacia arriba y resorte. `delay` permite escalonar varios elementos.
private struct RevealModifier: ViewModifier {
    let visible: Bool
    let delay: Double
    let scale: CGFloat
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private var animation: Animation {
        if reduceMotion { return Animation.easeOut(duration: 0.2) }
        return Animation.spring(response: 0.6, dampingFraction: 0.82).delay(delay)
    }

    func body(content: Content) -> some View {
        content
            .opacity(visible ? 1 : 0)
            .scaleEffect(visible || reduceMotion ? 1 : scale)
            .offset(y: visible || reduceMotion ? 0 : 16)
            .animation(animation, value: visible)
    }
}

extension View {
    func reveal(_ visible: Bool, delay: Double = 0, scale: CGFloat = 1) -> some View {
        modifier(RevealModifier(visible: visible, delay: delay, scale: scale))
    }

    /// Brillo que recorre una barra de progreso.
    func progressShimmer() -> some View {
        modifier(ProgressShimmerModifier())
    }
}

/// Botón con un pulso rápido al tocarlo: se encoge un poco, se agranda un poco y se asienta en su tamaño.
/// El pulso dura menos de medio segundo aunque se mantenga presionado, así que ningún botón queda encogido.
struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        PressableBody(configuration: configuration)
    }

    private struct PressableBody: View {
        let configuration: ButtonStyleConfiguration
        @Environment(\.accessibilityReduceMotion) private var reduceMotion
        @State private var scale: CGFloat = 1

        var body: some View {
            configuration.label
                .scaleEffect(scale)
                .onChange(of: configuration.isPressed) { _, pressed in
                    if pressed { pulse() }
                }
        }

        private func pulse() {
            guard !reduceMotion else { return }
            Task { @MainActor in
                withAnimation(Animation.easeOut(duration: 0.07)) { scale = 0.93 }
                try? await Task.sleep(nanoseconds: 70_000_000)
                withAnimation(Animation.easeOut(duration: 0.10)) { scale = 1.06 }
                try? await Task.sleep(nanoseconds: 100_000_000)
                withAnimation(Animation.spring(response: 0.25, dampingFraction: 0.6)) { scale = 1 }
            }
        }
    }
}

private struct ProgressShimmerModifier: ViewModifier {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var phase: CGFloat = -0.3

    func body(content: Content) -> some View {
        content.overlay {
            if !reduceMotion {
                GeometryReader { proxy in
                    LinearGradient(colors: [Color.clear, Color.white.opacity(0.35), Color.clear],
                                   startPoint: .leading, endPoint: .trailing)
                        .frame(width: proxy.size.width * 0.3)
                        .offset(x: proxy.size.width * phase)
                        .onAppear {
                            withAnimation(Animation.linear(duration: 1.4).repeatForever(autoreverses: false)) { phase = 1.0 }
                        }
                }
                .clipShape(Capsule())
                .allowsHitTesting(false)
            }
        }
    }
}

/// Palomita con un destello suave al terminar un resultado.
struct SuccessBurst: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var appear = false

    var body: some View {
        ZStack {
            Circle()
                .stroke(LocalStyle.mint.opacity(0.55), lineWidth: 3)
                .frame(width: 92, height: 92)
                .scaleEffect(appear ? 1.9 : 0.7)
                .opacity(appear ? 0 : 0.9)
            ZStack {
                Circle()
                    .fill(LocalStyle.gradient)
                    .frame(width: 84, height: 84)
                    .shadow(color: LocalStyle.mint.opacity(0.5), radius: 18)
                Image(systemName: "checkmark")
                    .font(.system(size: 38, weight: .heavy))
                    .foregroundStyle(Theme.onAccent)
            }
            .scaleEffect(appear ? 1 : 0.4)
            .opacity(appear ? 1 : 0)
        }
        .onAppear {
            let animation: Animation? = reduceMotion ? nil : Animation.spring(response: 0.5, dampingFraction: 0.62)
            withAnimation(animation) { appear = true }
        }
        .accessibilityHidden(true)
    }
}
