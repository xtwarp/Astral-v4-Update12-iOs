import SwiftUI

/// Créditos y licencias de los modelos incluidos (CC BY 4.0 y BSD-3-Clause exigen mostrarlos).
struct CreditsView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var themeStore = ThemeStore.shared

    private struct Entry: Identifiable {
        let id = UUID()
        let name: String
        let model: String
        let author: String
        let license: String
        let note: String?
    }

    private var entries: [Entry] {
        [
            Entry(name: "Anime · General · Plus · Anime 6B",
                  model: "Real-ESRGAN (AnimeVideo v3, General x4v3, x4plus, x4plus anime 6B)",
                  author: "xinntao", license: "BSD-3-Clause", note: nil),
            Entry(name: "Aurora ×2", model: "2xHFA2kCompact",
                  author: "Philip Hofmann (Phhofm), " + tr("entrenado con el dataset HFA2k de musl", "trained on musl's HFA2k dataset"),
                  license: "CC BY 4.0 (creativecommons.org/licenses/by/4.0)",
                  note: tr("Se convirtió a Core ML (fp16) para usarlo en esta app.", "Converted to Core ML (fp16) for use in this app.")),
            Entry(name: "Aurora ×4", model: "animerd v1", author: "musl", license: "CC0-1.0", note: nil),
            Entry(name: "Vega ×2", model: "2xHFA2kAVCCompact", author: "Philip Hofmann (Phhofm)",
                  license: "CC BY 4.0 (creativecommons.org/licenses/by/4.0)",
                  note: tr("Se convirtió a Core ML (fp16) para usarlo en esta app.", "Converted to Core ML (fp16) for use in this app.")),
            Entry(name: "Vega ×4", model: "4xLSDIRCompactC", author: "Philip Hofmann (Phhofm)",
                  license: "CC BY 4.0 (creativecommons.org/licenses/by/4.0)",
                  note: tr("Se convirtió a Core ML (fp16) para usarlo en esta app.", "Converted to Core ML (fp16) for use in this app.")),
            Entry(name: tr("Interpolación de frames", "Frame interpolation"), model: "RIFE 4.25",
                  author: "hzwer (Practical-RIFE)", license: "MIT", note: nil),
            Entry(name: tr("Código de referencia", "Reference code"), model: "real-esrgan-coreml",
                  author: "hanxiao", license: "MIT", note: nil)
        ]
    }

    var body: some View {
        ZStack {
            NeonBackground().ignoresSafeArea()
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text(tr("CRÉDITOS Y LICENCIAS", "CREDITS & LICENSES"))
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(Theme.ink(0.6))
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(Theme.ink(0.7))
                            .frame(width: 34, height: 34)
                            .background(Theme.fill(0.055), in: Circle())
                    }
                    .accessibilityLabel(tr("Cerrar", "Close"))
                }
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 10) {
                        ForEach(entries) { entry in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(entry.name).font(.system(size: 14, weight: .bold, design: .rounded)).foregroundStyle(Theme.ink())
                                Text(entry.model).font(.caption).foregroundStyle(Theme.ink(0.7))
                                Text(tr("Autor", "Author") + ": " + entry.author).font(.caption).foregroundStyle(Theme.ink(0.55))
                                Text(tr("Licencia", "License") + ": " + entry.license).font(.caption).foregroundStyle(LocalStyle.mint)
                                if let note = entry.note {
                                    Text(note).font(.caption2).foregroundStyle(Theme.ink(0.45))
                                }
                            }
                            .padding(14)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Theme.fill(0.055), in: RoundedRectangle(cornerRadius: 14))
                        }
                    }
                }
            }
            .padding(16)
        }
        .preferredColorScheme(themeStore.theme.palette.scheme)
    }
}
