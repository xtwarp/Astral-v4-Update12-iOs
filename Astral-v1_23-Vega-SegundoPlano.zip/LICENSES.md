# Licencias

## Modelos de IA incluidos

| Nombre en la app | Modelo | Autor | Licencia | Fuente |
|---|---|---|---|---|
| Anime / General / Plus / Anime (6B) | Real-ESRGAN (AnimeVideo v3, General x4v3, x4plus, x4plus anime 6B) | xinntao | BSD-3-Clause | https://github.com/xinntao/Real-ESRGAN |
| Aurora (×2) | 2xHFA2kCompact | Philip Hofmann (Phhofm), entrenado con el dataset HFA2k de musl | CC BY 4.0 | https://github.com/Phhofm/models/releases/tag/2xHFA2kCompact |
| Aurora (×4) | animerd v1 | musl | CC0-1.0 | https://openmodeldb.info/models/4x-animerd-v1 |
| Vega (×2) | 2xHFA2kAVCCompact | Philip Hofmann (Phhofm) | CC BY 4.0 | https://github.com/Phhofm/models/releases/tag/2xHFA2kAVCCompact |
| Vega (×4) | 4xLSDIRCompactC | Philip Hofmann (Phhofm) | CC BY 4.0 | https://github.com/Phhofm/models/releases/tag/4xLSDIRCompactC |
| Interpolación de frames | RIFE 4.25 | hzwer (Practical-RIFE) | MIT | https://github.com/hzwer/Practical-RIFE |

Los modelos Aurora ×2, Aurora ×4, Vega ×2 y Vega ×4 se convierten a Core ML (fp16) con el workflow `convert-sr.yml`.
Aurora ×2, Vega ×2 y Vega ×4 son adaptaciones (conversión de formato) de 2xHFA2kCompact, 2xHFA2kAVCCompact y 4xLSDIRCompactC: CC BY 4.0 exige dar crédito al autor, enlazar la licencia e indicar que se hicieron cambios (los tres se indican en Ajustes › Créditos y licencias).

## Código de referencia

- La implementación Core ML usada como referencia: MIT — hanxiao/real-esrgan-coreml.

## Contenido de ejemplo

La pantalla de bienvenida incluye contenido de ejemplo en `Astral/Resources/Demo`:

| Archivo | Uso | Licencia |
|---|---|---|
| `real-antes.jpg`, `real-despues.jpg` | Comparativa «Foto real» | Gratuita, de uso comercial (comprobada por el desarrollador) |
| `anime-antes.jpg`, `anime-despues.jpg` | Comparativa «Anime» | Gratuita, de uso comercial (comprobada por el desarrollador) |
| `interpolacion-antes.mp4` (30 fps), `interpolacion-despues.mp4` (60 fps) | Comparativa «Interpolación» | Gratuita, de uso comercial (comprobada por el desarrollador) |

Las imágenes y los videos «después» son resultados de la propia app. Los videos de prueba del usuario deben ser aportados por él y tener los derechos correspondientes.

## Antes de publicar comercialmente

- Conservar los textos de licencia y mostrar los créditos de los modelos dentro de la app (CC BY 4.0 y BSD-3-Clause lo requieren).
- Revisar los términos vigentes de cada repositorio/modelo.
- Conservar la fuente y la licencia de cada imagen y video de `Resources/Demo`.
