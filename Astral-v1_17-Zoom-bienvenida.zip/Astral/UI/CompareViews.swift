import SwiftUI
import AVFoundation

// MARK: - Divisor compartido (línea + asa) que se arrastra en ambos sentidos

struct CompareDivider: View {
    @Binding var position: CGFloat
    let size: CGSize

    var body: some View {
        ZStack {
            Rectangle().fill(LocalStyle.gradient).frame(width: 2.5, height: size.height)
                .shadow(color: LocalStyle.mint.opacity(0.6), radius: 5)
            Circle().fill(LocalStyle.gradient).frame(width: 34, height: 34)
                .shadow(color: LocalStyle.mint.opacity(0.5), radius: 8)
                .overlay(
                    Image(systemName: "chevron.left.chevron.right")
                        .font(.system(size: 11, weight: .bold)).foregroundStyle(Theme.onAccent)
                )
        }
        .frame(width: 52, height: size.height)
        .contentShape(Rectangle())
        .position(x: size.width * position, y: size.height / 2)
        // El gesto usa el espacio de coordenadas del contenedor: así la posición es absoluta
        // y el divisor responde en los dos sentidos.
        .highPriorityGesture(
            DragGesture(minimumDistance: 0, coordinateSpace: .named("compare"))
                .onChanged { value in
                    position = min(max(value.location.x / max(size.width, 1), 0.02), 0.98)
                }
        )
    }
}

private struct CompareLabel: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(0.8)
            .foregroundStyle(.white)
            .padding(.horizontal, 9).padding(.vertical, 5)
            .background(.black.opacity(0.55), in: Capsule())
    }
}

// MARK: - Zoom y desplazamiento (pellizcar, arrastrar, doble toque para restablecer)

struct ZoomState {
    var zoom: CGFloat = 1
    var lastZoom: CGFloat = 1
    var offset: CGSize = .zero
    var lastOffset: CGSize = .zero
    static let maxZoom: CGFloat = 6

    var isZoomed: Bool { zoom > 1.01 }

    mutating func clampOffset(in size: CGSize) {
        let maxX = size.width * (zoom - 1) / 2
        let maxY = size.height * (zoom - 1) / 2
        offset.width = min(max(offset.width, -maxX), maxX)
        offset.height = min(max(offset.height, -maxY), maxY)
    }
}

/// Superficie transparente que recibe los gestos de zoom. Va detrás del divisor y de los controles.
struct ZoomGestureSurface: View {
    @Binding var state: ZoomState
    let size: CGSize
    /// Toque simple opcional (por ejemplo, reproducir/pausar en las vistas previas iniciales).
    var onTap: (() -> Void)? = nil
    /// Con zoom activo, el arrastre tiene prioridad sobre otros gestos de la pantalla (por ejemplo, el
    /// deslizamiento entre páginas de la bienvenida). Sin zoom nunca interfiere.
    var prioritizeDrag: Bool = false

    private var magnification: some Gesture {
        MagnificationGesture()
            .onChanged { value in
                state.zoom = min(max(state.lastZoom * value, 1), ZoomState.maxZoom)
                state.clampOffset(in: size)
            }
            .onEnded { _ in
                state.lastZoom = state.zoom
                if !state.isZoomed { state = ZoomState() }
            }
    }

    private var pan: some Gesture {
        DragGesture()
            .onChanged { value in
                state.offset = CGSize(
                    width: state.lastOffset.width + value.translation.width,
                    height: state.lastOffset.height + value.translation.height
                )
                state.clampOffset(in: size)
            }
            .onEnded { _ in state.lastOffset = state.offset }
    }

    var body: some View {
        let base = Color.clear
            .contentShape(Rectangle())
            .simultaneousGesture(magnification)
        // Solo se desplaza con zoom activo; sin zoom la página sigue haciendo scroll.
        Group {
            if prioritizeDrag {
                base.highPriorityGesture(pan, including: state.isZoomed ? .all : .subviews)
            } else {
                base.simultaneousGesture(pan, including: state.isZoomed ? .all : .subviews)
            }
        }
        .onTapGesture(count: 2) {
            withAnimation(.easeOut(duration: 0.2)) { state = ZoomState() }
        }
        .onTapGesture { onTap?() }
    }
}

struct ZoomBadge: View {
    @Binding var state: ZoomState
    var body: some View {
        if state.isZoomed {
            Button {
                withAnimation(.easeOut(duration: 0.2)) { state = ZoomState() }
            } label: {
                HStack(spacing: 5) {
                    Text(String(format: "%.1f×", Double(state.zoom)))
                    Image(systemName: "xmark.circle.fill")
                }
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(Theme.onAccent)
                .padding(.horizontal, 10).padding(.vertical, 5)
                .background(LocalStyle.gradient, in: Capsule())
            }
        }
    }
}

/// Contenedor con zoom (pellizcar), desplazamiento y doble toque para restablecer, igual que los comparadores.
/// Se usa en las vistas previas iniciales, antes de procesar.
struct ZoomablePreview<Content: View>: View {
    var resetToken: Int = 0
    var onTap: (() -> Void)? = nil
    @ViewBuilder var content: () -> Content
    @State private var zoomState = ZoomState()

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                content()
                    .scaleEffect(zoomState.zoom).offset(zoomState.offset)
                ZoomGestureSurface(state: $zoomState, size: proxy.size, onTap: onTap)
                VStack {
                    ZoomBadge(state: $zoomState)
                    Spacer()
                }
                .padding(.top, 10)
            }
            .clipped()
        }
        .onChange(of: resetToken) { _, _ in zoomState = ZoomState() }
    }
}

/// Control sencillo de reproducción para la vista previa inicial de un video (play/pausa y barra de progreso).
final class PreviewPlayerController: ObservableObject {
    let player: AVPlayer
    @Published var isPlaying = false
    @Published var progress: Double = 0
    @Published var isMuted = false
    @Published var hasAudio = true
    /// Segundos transcurridos y duración del tramo visible (el recorte, o el video entero si no hay recorte).
    @Published var elapsed: Double = 0
    @Published var span: Double = 0
    var scrubbing = false
    private var rangeStart: Double = 0
    private var rangeEnd: Double = 0   // 0 = hasta el final del video

    private var fullDuration: Double {
        let total = CMTimeGetSeconds(player.currentItem?.duration ?? .zero)
        return total.isFinite ? max(total, 0) : 0
    }
    private var effectiveEnd: Double {
        let total = fullDuration
        return rangeEnd > rangeStart ? min(rangeEnd, total > 0 ? total : rangeEnd) : total
    }

    /// La barra y los tiempos de la preview siguen el recorte elegido.
    func setRange(start: Double, end: Double) {
        rangeStart = max(start, 0)
        rangeEnd = end
        refreshProgress(at: CMTimeGetSeconds(player.currentTime()))
    }

    private func refreshProgress(at seconds: Double) {
        let length = effectiveEnd - rangeStart
        span = max(length, 0)
        guard length > 0, seconds.isFinite else { progress = 0; elapsed = 0; return }
        let local = min(max(seconds - rangeStart, 0), length)
        elapsed = local
        progress = local / length
    }
    private var timeObserver: Any?
    private var statusObserver: NSKeyValueObservation?

    init(player: AVPlayer) {
        self.player = player
        player.isMuted = false
        if let asset = player.currentItem?.asset {
            Task { [weak self] in
                let tracks = (try? await asset.loadTracks(withMediaType: .audio)) ?? []
                await MainActor.run { self?.hasAudio = !tracks.isEmpty }
            }
        }
        timeObserver = player.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 0.05, preferredTimescale: 600), queue: .main
        ) { [weak self] time in
            guard let self, !self.scrubbing else { return }
            self.refreshProgress(at: CMTimeGetSeconds(time))
        }
        statusObserver = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] player, _ in
            DispatchQueue.main.async { self?.isPlaying = player.timeControlStatus != .paused }
        }
    }

    deinit {
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        statusObserver?.invalidate()
    }

    func toggleMute() {
        isMuted.toggle()
        player.isMuted = isMuted
    }

    func toggle() {
        if player.timeControlStatus != .paused { player.pause(); return }
        let current = CMTimeGetSeconds(player.currentTime())
        var end = 0.0
        if let item = player.currentItem {
            end = CMTimeGetSeconds(item.forwardPlaybackEndTime.isValid ? item.forwardPlaybackEndTime : item.duration)
        }
        if end.isFinite, end > 0, current >= end - 0.06 {
            // Al final del video (o del recorte): vuelve al inicio del tramo y reproduce.
            let startTime = CMTime(seconds: rangeStart, preferredTimescale: 600)
            player.seek(to: startTime, toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] _ in self?.player.play() }
        } else {
            player.play()
        }
    }

    func seek(to fraction: Double) {
        let length = effectiveEnd - rangeStart
        guard length > 0 else { return }
        let tolerance = CMTime(seconds: 0.1, preferredTimescale: 600)
        let target = rangeStart + min(max(fraction, 0), 1) * length
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600), toleranceBefore: tolerance, toleranceAfter: tolerance)
        progress = fraction
        elapsed = fraction * length
    }

    /// m:ss para los tiempos de la barra.
    static func clock(_ seconds: Double) -> String {
        let whole = Int(seconds.rounded())
        return String(format: "%d:%02d", whole / 60, whole % 60)
    }
}

/// Vista previa inicial de un video con zoom: toque para reproducir/pausar, pellizcar para ampliar.
struct ZoomableVideoPreview: View {
    @StateObject private var controller: PreviewPlayerController

    var trimStart: Double = 0
    var trimEnd: Double = 0

    init(player: AVPlayer, trimStart: Double = 0, trimEnd: Double = 0) {
        _controller = StateObject(wrappedValue: PreviewPlayerController(player: player))
        self.trimStart = trimStart
        self.trimEnd = trimEnd
    }

    var body: some View {
        ZStack {
            ZoomablePreview(resetToken: ObjectIdentifier(controller.player).hashValue, onTap: { controller.toggle() }) {
                PlayerLayerView(player: controller.player).allowsHitTesting(false)
            }
            if !controller.isPlaying {
                Image(systemName: "play.fill")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 58, height: 58)
                    .background(.black.opacity(0.45), in: Circle())
                    .allowsHitTesting(false)
            }
            VStack {
                Spacer()
                HStack(spacing: 14) {
                    Button { controller.toggle() } label: { Image(systemName: controller.isPlaying ? "pause.fill" : "play.fill") }
                    Text(PreviewPlayerController.clock(controller.elapsed))
                        .font(.system(size: 12, weight: .semibold, design: .rounded)).monospacedDigit()
                        .frame(minWidth: 32, alignment: .trailing)
                    Slider(
                        value: Binding(get: { controller.progress }, set: { controller.seek(to: $0) }),
                        in: 0...1,
                        onEditingChanged: { editing in controller.scrubbing = editing }
                    )
                    .tint(LocalStyle.mint)
                    Text(PreviewPlayerController.clock(controller.span))
                        .font(.system(size: 12, weight: .semibold, design: .rounded)).monospacedDigit()
                        .frame(minWidth: 32, alignment: .leading)
                    if controller.hasAudio {
                        Button { controller.toggleMute() } label: {
                            Image(systemName: controller.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                                .frame(width: 24)
                        }
                    }
                }
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 16).padding(.vertical, 8)
                .background(.black.opacity(0.6), in: Capsule())
                .padding(.horizontal, 10).padding(.bottom, 10)
            }
        }
        .clipped()
        .onAppear { controller.setRange(start: trimStart, end: trimEnd) }
        .onChange(of: trimStart) { _, _ in controller.setRange(start: trimStart, end: trimEnd) }
        .onChange(of: trimEnd) { _, _ in controller.setRange(start: trimStart, end: trimEnd) }
        .onDisappear { controller.player.pause() }
    }
}

// MARK: - Reproductores

struct PlayerLayerView: UIViewRepresentable {
    let player: AVPlayer
    func makeUIView(context: Context) -> PlayerContainer {
        let view = PlayerContainer()
        view.playerLayer.player = player
        view.playerLayer.videoGravity = .resizeAspect
        return view
    }
    func updateUIView(_ uiView: PlayerContainer, context: Context) { uiView.playerLayer.player = player }
}

final class PlayerContainer: UIView {
    override static var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}

/// Controla dos reproductores sincronizados: resultado (maestro) y original (sigue al maestro).
final class VideoCompareController: ObservableObject {
    let before: AVPlayer
    let after: AVPlayer
    private let beforeOffset: CMTime
    /// 1 = normal. Si es mayor (cámara lenta ×N), el resultado dura N veces más: el "antes" se muestra a su
    /// velocidad y con todos sus frames originales, repitiéndose mientras el resultado avanza lento.
    private let slowFactor: Int
    @Published var isPlaying = false
    @Published var progress: Double = 0
    var scrubbing = false
    private var duration: Double = 0
    private var timeObserver: Any?
    private var endObserver: NSObjectProtocol?

    init(beforeURL: URL, afterURL: URL, beforeStart: Double, slowFactor: Int = 1) {
        before = AVPlayer(url: beforeURL)
        after = AVPlayer(url: afterURL)
        beforeOffset = CMTime(seconds: beforeStart, preferredTimescale: 600)
        self.slowFactor = max(slowFactor, 1)
        before.isMuted = true
        before.seek(to: beforeOffset, toleranceBefore: .zero, toleranceAfter: .zero)

        timeObserver = after.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 0.05, preferredTimescale: 600), queue: .main
        ) { [weak self] time in
            guard let self else { return }
            let total = CMTimeGetSeconds(self.after.currentItem?.duration ?? .zero)
            if total.isFinite, total > 0 {
                self.duration = total
                if !self.scrubbing { self.progress = min(max(CMTimeGetSeconds(time) / total, 0), 1) }
            }
            if self.isPlaying {
                let target = self.beforeTarget(for: time)
                let drift = CMTimeGetSeconds(CMTimeSubtract(self.before.currentTime(), target))
                if abs(drift) > 0.12 {
                    self.before.seek(to: target, toleranceBefore: .zero, toleranceAfter: .zero)
                    if self.slowFactor > 1 { self.before.play() }
                }
            }
        }
        endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime, object: after.currentItem, queue: .main
        ) { [weak self] _ in
            self?.pauseBoth()
            self?.progress = 1
        }
    }

    deinit {
        if let timeObserver { after.removeTimeObserver(timeObserver) }
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        before.pause(); after.pause()
    }

    /// Instante del original que corresponde al instante `time` del resultado.
    /// Normal: el mismo instante. Cámara lenta: el original se repite en bucle a velocidad real.
    private func beforeTarget(for time: CMTime) -> CMTime {
        guard slowFactor > 1, duration > 0 else { return CMTimeAdd(beforeOffset, time) }
        let sourceDuration = duration / Double(slowFactor)
        let seconds = CMTimeGetSeconds(time)
        guard sourceDuration > 0.05, seconds.isFinite else { return beforeOffset }
        let looped = seconds.truncatingRemainder(dividingBy: sourceDuration)
        return CMTimeAdd(beforeOffset, CMTime(seconds: looped, preferredTimescale: 600))
    }

    func pauseBoth() {
        before.pause(); after.pause()
        isPlaying = false
    }

    func toggle() {
        if isPlaying { pauseBoth(); return }
        if progress >= 0.99 { seek(to: 0, precise: true) }
        let time = after.currentTime()
        before.seek(to: beforeTarget(for: time), toleranceBefore: .zero, toleranceAfter: .zero)
        before.play(); after.play()
        isPlaying = true
    }

    func restart() {
        pauseBoth()
        seek(to: 0, precise: true)
    }

    func seek(to fraction: Double, precise: Bool = false) {
        guard duration > 0 || fraction == 0 else { return }
        let time = CMTime(seconds: fraction * duration, preferredTimescale: 600)
        let tolerance = precise ? CMTime.zero : CMTime(seconds: 0.1, preferredTimescale: 600)
        after.seek(to: time, toleranceBefore: tolerance, toleranceAfter: tolerance)
        before.seek(to: beforeTarget(for: time), toleranceBefore: tolerance, toleranceAfter: tolerance)
        progress = fraction
    }
}

/// Comparación antes/después con vídeo: dentro de la misma vista previa principal.
struct VideoCompareView: View {
    @StateObject private var controller: VideoCompareController
    @State private var position: CGFloat = 0.5
    @State private var zoomState = ZoomState()

    private let slowFactor: Int

    init(beforeURL: URL, afterURL: URL, beforeStart: Double, slowFactor: Int = 1) {
        self.slowFactor = max(slowFactor, 1)
        _controller = StateObject(wrappedValue: VideoCompareController(beforeURL: beforeURL, afterURL: afterURL, beforeStart: beforeStart, slowFactor: slowFactor))
    }

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black
                PlayerLayerView(player: controller.after).allowsHitTesting(false)
                    .scaleEffect(zoomState.zoom).offset(zoomState.offset)
                PlayerLayerView(player: controller.before).allowsHitTesting(false)
                    .scaleEffect(zoomState.zoom).offset(zoomState.offset)
                    .mask(alignment: .leading) { Rectangle().frame(width: proxy.size.width * position) }

                ZoomGestureSurface(state: $zoomState, size: proxy.size)

                CompareDivider(position: $position, size: proxy.size)

                VStack {
                    HStack {
                        CompareLabel(text: L.beforeLabel.text)
                        Spacer()
                        CompareLabel(text: L.afterLabel.text)
                    }
                    .padding(10)
                    .allowsHitTesting(false)
                    ZoomBadge(state: $zoomState)
                    Spacer()
                    controls
                }
            }
            .coordinateSpace(name: "compare")
            .clipped()
        }
        .onDisappear { controller.pauseBoth() }
    }

    private var controls: some View {
        HStack(spacing: 14) {
            Button { controller.restart() } label: { Image(systemName: "backward.end.fill") }
            Button { controller.toggle() } label: { Image(systemName: controller.isPlaying ? "pause.fill" : "play.fill") }
            Slider(
                value: Binding(get: { controller.progress }, set: { controller.seek(to: $0) }),
                in: 0...1,
                onEditingChanged: { editing in
                    controller.scrubbing = editing
                }
            )
            .tint(LocalStyle.mint)
        }
        .font(.system(size: 16, weight: .bold))
        .foregroundStyle(.white)
        .padding(.horizontal, 16).padding(.vertical, 8)
        .background(.black.opacity(0.6), in: Capsule())
        .padding(.horizontal, 10).padding(.bottom, 10)
    }
}

// MARK: - Comparación de imágenes

struct ImageComparisonView: View {
    let before: CGImage
    let after: CGImage
    @State private var position: CGFloat = 0.5
    @State private var zoomState = ZoomState()

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black
                Image(decorative: after, scale: 1, orientation: .up)
                    .resizable().scaledToFit()
                    .scaleEffect(zoomState.zoom).offset(zoomState.offset)
                Image(decorative: before, scale: 1, orientation: .up)
                    .resizable().scaledToFit()
                    .scaleEffect(zoomState.zoom).offset(zoomState.offset)
                    .mask(alignment: .leading) { Rectangle().frame(width: proxy.size.width * position) }

                ZoomGestureSurface(state: $zoomState, size: proxy.size)

                CompareDivider(position: $position, size: proxy.size)

                VStack {
                    HStack {
                        CompareLabel(text: L.beforeLabel.text)
                        Spacer()
                        CompareLabel(text: L.afterLabel.text)
                    }
                    .padding(10)
                    .allowsHitTesting(false)
                    ZoomBadge(state: $zoomState)
                    Spacer()
                }
            }
            .coordinateSpace(name: "compare")
            .clipped()
        }
    }
}
